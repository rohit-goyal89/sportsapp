$(document).ready(function() {
		$('#dataTables-example').DataTable({
				responsive: true, 
				 pageLength : 50,
				order: [[ 4, "asc" ]]
		});
		$('#dataTables-example-n').DataTable({
				responsive: true, 
				 pageLength : 20,
				  scrollX: true,
				order: [[ 4, "asc" ]]
		});
		$('#dataTables-example3').DataTable({
				responsive: true, 
				 pageLength : 50,
				order: [[ 5, "asc" ]]
		});
		$('#dataTables-example2').DataTable({
				responsive: true, 
			 	pageLength : 50,
				order: [[ 3, "asc" ]]
		});
		$('#dataTables-example4').DataTable({
				responsive: true, 
			 	pageLength : 50,
				order: [[ 2, "desc" ]]
		});
		$('#dataTables-fandemand').DataTable({
				responsive: true, 
			 	pageLength : 50,
				order: [[ 1, "desc" ]]
		});
		$('#category').on('change', function(e){
		   $('#date').val('');
		 });
		$('#date').on('change', function(e){
		   $('#category').val('');
		 });
		setTimeout(function(){ $('.alert').slideUp('slow'); }, 3000);
		$(".category_change").on('change', function(e){
			
			$(this).closest('form')[0].submit();
		});
		$(".sg-mean-price").on('change', function(e){
			
			$(this).closest('form')[0].submit();
		})
	});