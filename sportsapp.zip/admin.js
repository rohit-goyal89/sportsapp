 /**
 * Module dependencies.
 */

var express = require('express'), 
	routes = require('./routes'), 
	http = require('http'), 
	path = require('path'), 
	bodyParser = require('body-parser'), 
	favicon = require('serve-favicon'), 
	logger = require('morgan'), 
	methodOverride = require('method-override'), 
	flash = require('connect-flash'),	
	bcrypt = require('bcrypt'),
	passport = require('passport'),
	nodemailer = require('nodemailer'),
	smtpTransport = require('nodemailer-smtp-transport'),
	dt = require('./lib/function');


const session = require('express-session'),
	mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);
mongoose.connect('mongodb://172.31.14.103:27017/sportsapp', { useNewUrlParser: true,useCreateIndex: true });
//mongoose.set('debug', true);


var app = express();
// add & configure middleware
app.use(session({
    secret: '2C44-4D44-WppQ38S',
    resave: true,
    saveUninitialized: true
}));

var User = require('./models/user');
var contact = require('./routes/contact');
var product = require('./routes/product');
var user = require('./routes/user');
var category = require('./routes/category');
var size = require('./routes/size');
var comment = require('./routes/comment');
var demands = require('./routes/demands');
var teams = require('./routes/team');
var news = require('./routes/news');
var games = require('./routes/games');
var leagues = require('./routes/leagues');
var sportradars = require('./routes/sportradars');
var leaders = require('./routes/leaders');
var players = require('./routes/player');
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(favicon(__dirname + '/public/images/favicon.png'));
app.use(logger('dev'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(methodOverride('_method'));
app.use(require('stylus').middleware(__dirname + '/public'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session()); 

if (app.get('env') == 'development') {
	var d = new Date();
	app.locals.currentyear = d.getFullYear();
	app.locals.pretty = true;
	app.locals.siteName = 'Sports Site';
	app.locals.userrole =	[{
        key : 1,
        value : 'Admin'
    },
    {
        key : 2,
        value : 'Public'
    },
    {
    	key : 3 ,
    	value:'Fans'
    }]		  
}

app.get('/', function (req, res) {
	console.log(dt.myDateTime());
	res.locals.message = req.flash();
	if (req.session.user) {
		res.redirect('/dashboard');
	}else{
		res.render('login');
	}
   
});

app.get('/forgot_password',function (req, res) {
	res.locals.message = req.flash();
	if (req.session.user) {
		res.redirect('/dashboard');
	}else{
		res.render('forgot_password');
	}   
});


app.get('/change_password',function (req, res) {
		res.locals.message = req.flash();
	res.render('change_password',{errorMsg: ''});
});
app.post('/update_password',function (req, res) {
	
	User.findOne({ email: 'admin@admin.com'}, function(err, userData) {
		
		if(err){
			req.flash('error', 'Something wrong');
				res.redirect('/change_password');
		}
		bcrypt.compare(req.body.old_password, userData.password,function(error, cresult) {
			
			if (error){
				req.flash('error', 'Something went wrong');
				res.redirect('/change_password');
				return false;
			}else{
				req.flash('error', 'Old password is wrong');
				res.redirect('/change_password');
				return false;

			}
			
		});
		
		if(req.body.new_password != req.body.confirm_new_password){
			
			req.flash('error', 'Password and confirm password not matched.');
			res.redirect('/change_password');
			return false;
		}
		bcrypt.genSalt(10, function(err, salt) {
			if (err) {
				console.log(err);
			}
			
			var new_password	=	bcrypt.hash(req.body.new_password, salt);
			console.log(new_password);
			User.where({email: 'admin@admin.com'}).updateMany({password: new_password }).exec((err, updatePassword) => {
					if(err)throw err;
					console.log(updatePassword);
					req.flash('success', 'You have update password successfully. Thank you');
					//res.redirect('/dashboard');
			});
			
		})
		 
		
	})
});
app.get('/reset_password/:code', routes.reset_password);
app.get('/register',function (req, res) {
	res.render('register',{errorMsg: ''});
});	

app.use('/comment', comment);

app.post('/save_user',function (req, res) {
	user = new User(req.body);
    user.save(function(err, user) {
		if (err) {
			res.render('register',{ errorMsg: err.errors});
		}else{
			req.flash('success', 'You have registered successfully. Thank you');
			res.redirect('/');
		}
    });	
});

app.post('/send_email_request',function (req, res) {
	var user = new User(req.body);
    user.save(function(err, user) {
        if (err) throw err;
		req.flash('success', 'You have register on our online recruitment portal successfully. Thank you');
		res.redirect('/');
    });	
});


app.post('/login',function (req, res) {
	if (req.body.email) {
		User.findOne({ email: req.body.email}, function(err, userData) {
			if (err) throw err;
			if(userData){
				bcrypt.compare(req.body.password, userData.password,function(error, res) {
					if (error) throw error;
					
				});
				req.session.user = {
					email: userData.email,
					username: userData.username,
					id: userData._id
				}; 
				req.session.authenticated = true;
				req.flash('success', 'welcome to our online recruitment portal');
				res.redirect('/dashboard');
			}else{
				req.flash('error', 'Username and password are incorrect');
				res.redirect('/');
			}
			
		})
			
	} else {
		req.flash('error', 'Username and password are incorrect');
		res.redirect('/');
	}
});
app.use('/demands', demands);
app.use('/teams', teams);
app.use('/news', news);
app.use('/games', games);
app.use('/leagues', leagues);
app.use('/sportradars', sportradars);
app.use('/leader', leaders);
app.use('/player', players);
app.use(function(req, res, next){
	res.locals.message = req.flash();
    if (req.session.user) {
		next();
	} else {
		req.flash('error', 'Authrization failed! Please login');
		res.redirect('/');
	}
});

app.get('/dashboard',routes.dashboard);
app.use('/contact', contact);
app.use('/user', user);
app.use('/product', product);
app.use('/category', category);
app.use('/size', size);


app.get('/logout', function (req, res) {
	delete req.session.user;
	req.logout();
	 req.flash('success', "You have logged out");
	res.redirect('/');
});

http.createServer(app).listen(app.get('port'), function(){
  console.log("Express server listening on port " + app.get('port'));
});
