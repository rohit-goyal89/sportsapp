var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var categorySchema = new Schema({
	name: { type: String, required: [true, 'Name is required'], unique: [true, 'Name already used'] },
	post: [{ type: Schema.Types.ObjectId, ref: 'Post' }],
	description: { type: String },
	filetoupload: { type: String},
	status: Boolean,
	created_at: Date,
	updated_at: Date
});	
categorySchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Category = mongoose.model('Category', categorySchema);

// make this available to our users in our Node applications
module.exports = Category;