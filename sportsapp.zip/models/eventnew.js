var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
// create a schema
var eventnewSchema = new Schema({
	event_id: String,
	event_type: String,
	title: { type: String, required: [true, 'Title is required']},
	type: String,
	date: Date,
	dateutc: Date,
	datetime: String,
	venue_id: String,
	venue_city: String,
	average_price_old: { type: Number, default:null},
	average_price: { type: Number},
	min_price: { type: Number},
	max_price: { type: Number},
	max_price_old: { type: Number, default:null},
	min_price_old: { type: Number, default:null},
	created_at: Date,
	updated_at: Date
});	
eventnewSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var EventNew = mongoose.model('EventNew', eventnewSchema);

// make this available to our users in our Node applications
module.exports = EventNew;