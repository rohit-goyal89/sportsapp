var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var venueSchema = new Schema({
	league: {type: String},
	asset_id: { type: String},
	title: { type: String},
	description: { type: String},
	venue_id: {type: String},
	links: [],
	ref: [],
	created: Date
});	
venueSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Venue = mongoose.model('Venue', venueSchema);

// make this available to our users in our Node applications
module.exports = Venue;