var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
// create a schema
var demandSchema = new Schema({
	title: { type: String, required: [true, 'Title is required']},
	type: String,
	venue: String,
	venue_location: { type: String, default:null},
	venue_image: { type: String, default:null},
	seatmap: { type: String, default:null},
	dateutc: Date,
	datetime: Date,
	average_price_old: { type: Number, default:0},
	average_price: { type: Number, default:0},
	min_price: { type: Number, default:0},
	max_price: { type: Number, default:0},
	max_price_old: { type: Number, default:0},
	min_price_old: { type: Number, default:0},
	demand: { type: Number, default:0},
	change_demand: { type: Number, default:0},
	status: { type: String, default:0},
	created_at: Date,
	updated_at: Date
});	
demandSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Demand = mongoose.model('Demand', demandSchema);

// make this available to our users in our Node applications
module.exports = Demand;