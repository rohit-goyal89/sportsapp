var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
// create a schema
var productSchema = new Schema({
	name: { type: String, required: [true, 'Name is required'], unique: [true, 'Name already used'] },
	category: [{ type: Schema.Types.ObjectId, ref: 'Category'}],
	description: { type: String },
	filetoupload: { type: String},
	price: Number,
	discount: Number,
	size: Number,
	status: Boolean,
	created_at: Date,
	updated_at: Date
});	
productSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Post = mongoose.model('Post', productSchema);

// make this available to our users in our Node applications
module.exports = Post;