var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var gameSchema = new Schema({
	league_name: { type: String},
	league_season: { type: String},	
	game_id: { type: String},
	team1: { type: String, required: [true, 'Team1 is required'] },
	team2: { type: String, required: [true, 'Team2 is required']},
	status: { type: String},
	created: Date
});	
gameSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Games = mongoose.model('Games', gameSchema);

// make this available to our users in our Node applications
module.exports = Games;