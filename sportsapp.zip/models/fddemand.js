var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
// create a schema
var fddemandSchema = new Schema({
	home_team:{type: String},
	home_id:{type: String},
	away_team:{type: String},
	away_id:{type: String},
	venue: String,
	venue_location: { type: String, default:null},
	demand: { type: Number},
	change_demand: { type: Number},
	dateutc: { type: Date},
	type: { type: String},
	datetime: Date,
	created_at: Date,
	updated_at: Date
});	
fddemandSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Fddemand = mongoose.model('Fddemand', fddemandSchema);

// make this available to our users in our Node applications
module.exports = Fddemand;