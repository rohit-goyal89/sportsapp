var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var playerimageSchema = new Schema({
	asset: { type: String},
	league: { type: String},
	asset_id: { type: String,unique:true},
	player_id: { type: String},
	player_name: { type: String},
	created_at: Date,
	updated_at: Date
});	
playerimageSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var PlayerImage = mongoose.model('PlayerImage', playerimageSchema);

// make this available to our users in our Node applications
module.exports = PlayerImage;