var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var scoreSchema = new Schema({
	game_id: {type: String},
	status: {type: String},
	home_id: {type: String},
	home_name: { type: String, required: [true, 'Title is required']},
	league: { type: String}, 
	season: { type: String}, 
	home_alias: { type: String},
	home_points: { type: Number},
	home_color: { type: String,default:null},
	away_id: {type: String},
	away_name: { type: String, required: [true, 'Title is required'] },
	away_market: { type: String},
	away_color: { type: String,default:null},
	away_alias: { type: String},
	away_points: { type: Number},
	home_logo: { type: String,default: null},
	away_logo: { type: String,default: null},
	venue_id: {type: String},
	venue: {type: String},
	venue_logo: {type: String}, 
	timezone: {type: String,default: null}, 
	dateutc: {type: String,default: null}, 
	created: Date
});	
/* scoreSchema.virtual('home_logo_path').get(function() {  
    return  window.location.hostname + this.home_logo;
});
scoreSchema.virtual('away_logo_path').get(function() {  
    return  window.location.hostname + this.away_logo;
});
scoreSchema.set('toJSON', { virtuals: true }); */
scoreSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Score = mongoose.model('Score', scoreSchema);

// make this available to our users in our Node applications
module.exports = Score;