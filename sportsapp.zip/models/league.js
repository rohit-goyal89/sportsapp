var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var leagueSchema = new Schema({
	name: { type: String, required: [true, 'Title is required'], unique: [true, 'Title already used'] },
	key:{ type: String },
	feed_url: { type: String},
	created: Date,
	updated: Date
});	
leagueSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Leagues = mongoose.model('Leagues', leagueSchema);

// make this available to our users in our Node applications
module.exports = Leagues;