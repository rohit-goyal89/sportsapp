var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var newsSchema = new Schema({
	sport_id: {type: String},
	title: { type: String, required: [true, 'Title is required']},
	byline:{ type: String },
	league:{ type: String },
	content: { type: String},
	image_file_url: { type: String,default:null},
	created: Date,
	updated: Date
});	
newsSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var News = mongoose.model('News', newsSchema);

// make this available to our users in our Node applications
module.exports = News;