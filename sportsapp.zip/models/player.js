var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var playersSchema = new Schema({
	title: { type: String},
	player_id: { type: String},
	profile_image_90: { type: String},
	profile_image_60: { type: String},
	created_at: Date,
	updated_at: Date
});	
playersSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Players = mongoose.model('Players', playersSchema);

// make this available to our users in our Node applications
module.exports = Players;