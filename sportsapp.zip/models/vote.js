var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
// create a schema
var voteSchema = new Schema({
	game_id: { type: String },
	type: { type: String },
	team: { type: String },
	message: { type: String },
	filepath: { type: String },
	demand: { type: Number, default:0},
	change_demand: { type: Number, default:0},
	user_id: { type: Schema.Types.ObjectId, ref: 'User', unique: false },
	created_at: { type: Date, required: true, default: Date.now },
  	updated_at: { type: Date, required: true, default: Date.now },
});	
// the schema is useless so far
// we need to create a model using it
var Vote = mongoose.model('Vote', voteSchema);

// make this available to our users in our Node applications
module.exports = Vote;