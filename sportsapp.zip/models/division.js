var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var divisionSchema = new Schema({
	season: { type: String},
	league: { type: String},
	conferences_name: { type: String},
	conferences_alias: { type: String},
	teams: [],
	created_at: Date,
	updated_at: Date
});	
divisionSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Division = mongoose.model('Division', divisionSchema);

// make this available to our users in our Node applications
module.exports = Division;