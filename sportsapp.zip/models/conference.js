var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var conferenceSchema = new Schema({
	season: { type: String},
	league: { type: String},
	conferences_name: { type: String},
	conferences_alias: { type: String},
	divisions: [],
	created_at: Date,
	updated_at: Date
});	
conferenceSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Conference = mongoose.model('Conference', conferenceSchema);

// make this available to our users in our Node applications
module.exports = Conference;