var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
// create a schema
var postSchema = new Schema({
	title: { type: String, required: [true, 'Title is required'] },
	comment_id: [{ type: Schema.Types.ObjectId, ref: 'Comment', unique: false }],
	likes: [{ type: Schema.Types.ObjectId, ref: 'User', unique: false }],
	owner: Object,
	status: { type: Boolean, default: 1},
	created_at: Date,
	updated_at: Date
});	
postSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Post = mongoose.model('Post', postSchema);

// make this available to our users in our Node applications
module.exports = Post;