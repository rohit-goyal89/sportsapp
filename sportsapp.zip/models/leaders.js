var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var leadersSchema = new Schema({
	season: { type: String},
	league: { type: String},
	categories_name: { type: String},
	categories_type: { type: String},
	rank: { type: Number},
	score: { type: Number},
	primary_position: { type: String},
	player_id: { type: Object},
	player_name: { type: String},
	player_pic: [],
	team_market: { type: String},
	team_name: { type: String},
	games_played: { type: Number},
	games_started: { type: Number},
	minutes: { type: Number},
	fgm: { type: Number},
	fga: { type: Number},
	avg_minutes: { type: Number},
	avg_points: { type: Number},
	created_at: Date,
	updated_at: Date
});	
leadersSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Leaders = mongoose.model('Leaders', leadersSchema);

// make this available to our users in our Node applications
module.exports = Leaders;