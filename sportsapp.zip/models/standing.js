var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var standingsSchema = new Schema({
	standingData: [],
	league: {type: String},
	season: {type: String},
	/*home_name: { type: String, required: [true, 'Title is required'], unique: [true, 'Title already used'] },
	league: { type: String}, 
	home_alias: { type: String},
	home_points: { type: Number},
	away_id: {type: String},
	away_name: { type: String, required: [true, 'Title is required'], unique: [true, 'Title already used'] },
	away_market: { type: String},
	away_alias: { type: String},
	away_points: { type: Number},
	hometeamicon: { type: String,default: null},
	awayteamicon: { type: String,default: null},*/
	created: Date
});	
standingsSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Standings = mongoose.model('Standings', standingsSchema);

// make this available to our users in our Node applications
module.exports = Standings;