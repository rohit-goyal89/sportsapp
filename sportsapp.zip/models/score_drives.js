var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var scoreDriveSchema = new Schema({
	game_id: { type: String},
	league: { type: String},
	home_team_name: { type: String, required: [true, 'Home Team is required'], default : null },
	home_team_point: { type: String, default : null},
	home_team_market: { type: String, default : null },
	home_team_alias: { type: String, default : null},
	home_team_timeout: { type: String, default : null},
	away_team_name: { type: String, default : null, required: [true, 'Away Team is required']},
	away_team_point: { type: String, default : null },
	away_team_alias: { type: String, default : null},
	away_team_market: { type: String, default : null},
	away_team_timeout: { type: String, default : null},
	status: { type: String, default : null,},
	schedule:  { type: Date, default : null},
	quarter:  { type: Number, default : null},
	description: { type: String, default : null},
	situtation_clock: { type: String, default : null},
	scores:[{
		home_points : { type: Number, default : null},
		away_points : { type: Number, default : null}
	}],
	drives:[{
		sequence : { type: Number, default : null},
		quarter : { type: Number, default : null},
		start_reason : { type: String, default : null},
		end_reason : { type: String, default : null},
		duration : { type: String, default : null},
		team_name : { type: String, default : null},
		plays	: [{
			start_time: { type: String, default : null},
			down : { type: Number, default : null},
			yfd:  { type: Number, default : null},
			location_name: { type: String, default : null},
			description: { type: String, default : null}
		}]

	}]
});
scoreDriveSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var ScoreDrives = mongoose.model('ScoreDrives', scoreDriveSchema);

// make this available to our users in our Node applications
module.exports = ScoreDrives;