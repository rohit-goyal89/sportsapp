var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var sizeSchema = new Schema({
	name: { type: String, required: [true, 'Name is required'], unique: [true, 'Name already used'] },
	short_name:{ type: String, required: [true, 'Short Name is required']},
	status: Boolean,
	created_at: Date,
	updated_at: Date
});	
sizeSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Size = mongoose.model('Size', sizeSchema);

// make this available to our users in our Node applications
module.exports = Size;