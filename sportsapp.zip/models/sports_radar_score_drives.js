var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var sportsRadarDriveSchema = new Schema({
	game_id: { type: String},
	league: { type: String},
	gameData: {},
});
sportsRadarDriveSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var SportsRadarDrive = mongoose.model('SportsRadarDrive', sportsRadarDriveSchema);

// make this available to our users in our Node applications
module.exports = SportsRadarDrive;