var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt'),
SALT_WORK_FACTOR = 10;
var uniqueValidator = require('mongoose-unique-validator');
// create a schema
var userSchema = new Schema({
  fname:  { type: String, required: [true, 'Firstname is required']},
  lname: { type: String, required: [true, 'Lastname is required']},
  address: { type: String },
  role: { type: Number, required: [true, 'Role is required']},
  username: { type: String, required: [true, 'Username is required'], unique: [true, 'Username already used'] },
  email: { type: String, required: [true, 'Email is required'], unique: [true, 'Email already used'] },
  password: { type: String, required: true },
  post_id: [{ type: Schema.Types.ObjectId, ref: 'Post' }],
  phone: String,
  gender: Number,
  profile_photo: String,
  created_at: { type: Date, required: true, default: Date.now },
  updated_at: { type: Date, required: true, default: Date.now },
});
userSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
userSchema.pre('save', function(next) {
    var user = this;

    // only hash the password if it has been modified (or is new)
    if (!user.isModified('password')) return next();

    // generate a salt
    bcrypt.genSalt(SALT_WORK_FACTOR, function(err, salt) {
        if (err) return next(err);

        // hash the password using our new salt
        bcrypt.hash(user.password, salt, function(err, hash) {
            if (err) return next(err);

            // override the cleartext password with the hashed one
            user.password = hash;
            next();
        });
    });
});
userSchema.methods.comparePassword = function(candidatePassword, cb) {
    bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
        if (err) return cb(err);
        cb(null, isMatch);
    });
  }	
// the schema is useless so far
// we need to create a model using it
var User = mongoose.model('User', userSchema);

// make this available to our users in our Node applications
module.exports = User;