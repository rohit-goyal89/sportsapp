var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
// create a schema
var replySchema = new Schema({
	content: { type: String },
	user: [{ type: Schema.Types.ObjectId, ref: 'User', unique: false }],
	comments: [{ type: Schema.Types.ObjectId, ref: 'Comment', unique: false }],
	created_at: { type: Date, required: true, default: Date.now },
  	updated_at: { type: Date, required: true, default: Date.now },
});	
// the schema is useless so far
// we need to create a model using it
var Reply = mongoose.model('Reply', replySchema);

// make this available to our users in our Node applications
module.exports = Reply;