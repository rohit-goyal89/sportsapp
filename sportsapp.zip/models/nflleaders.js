var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
var nflleadersSchema = new Schema({
	week: { type: Number},
	nfl_type: { type: String},
	nfl_type_slug: { type: String},
	player_id: { type: String},
	player_name: { type: String},
	position: { type: String},
	att: { type: Number,default:null},
	made: { type: Number,default:null},
	pct: { type: Number,default:null},
	cmp: { type: Number,default:null},
	yds: { type: Number,default:null},
	yac: { type: Number,default:null},
	lg: { type: Number,default:null},
	blk: { type: Number,default:null},
	sk: { type: Number,default:null},
	sk_yds: { type: Number,default:null},
	td: { type: Number,default:null},
	int: { type: Number,default:null},
	int_td: { type: Number,default:null},
	fd: { type: Number,default:null},
	sfty: { type: Number,default:null},
	rz_att: { type: Number,default:null},
	rz_tar: { type: Number,default:null},
	fum: { type: Number,default:null},
	rating: { type: Number,default:null},
	avg: { type: Number,default:null},
	cmp_pct: { type: Number,default:null},
	cmp_avg: { type: Number,default:null},
	tar: { type: Number,default:null},
	rec: { type: Number,default:null},
	td_pct: { type: Number,default:null},
	fd_pct: { type: Number,default:null},
	int_pct: { type: Number,default:null},
	yds_10_pls: { type: Number,default:null},
	yds_20_pls: { type: Number,default:null},
	yds_30_pls: { type: Number,default:null},
	yds_40_pls: { type: Number,default:null},
	yds_50_pls: { type: Number,default:null},
	team_name: { type: String,default:null},
	team_market: { type: String,default:null},
	created_at: Date,
	updated_at: Date
});	

nflleadersSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var NflLeaders = mongoose.model('NflLeaders', nflleadersSchema);

// make this available to our users in our Node applications
module.exports = NflLeaders;