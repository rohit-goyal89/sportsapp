var mongoose = require('mongoose');
var Schema = mongoose.Schema;
bcrypt = require('bcrypt');
var uniqueValidator = require('mongoose-unique-validator');
// create a schema
var eventSchema = new Schema({
	event_id:{type : String,required : true,unique : true}, 
	event_type: String,
	title: { type: String, required: [true, 'Title is required']},
	type: String,
	date: String,
	dateutc: String,
	datetime: String,
	venue_id: String,
	venue_city: String,
	average_price_old: { type: Number, default:null},
	average_price: { type: Number},
	min_price: { type: Number},
	max_price: { type: Number},
	seatmap: { type: String, default:null},
	max_price_old: { type: Number, default:null},
	max_price_old: { type: Number, default:null},
	timezone: {type: String}, 
	created_at: Date,
	updated_at: Date
});	
eventSchema.plugin(uniqueValidator ,{ message: '{PATH} already used.' });
// the schema is useless so far
// we need to create a model using it
var Event = mongoose.model('Event', eventSchema);

// make this available to our users in our Node applications
module.exports = Event;