var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment'),
	SportsRadarScore = require('../models/sports_radar_score'),
	// /Score = require('../models/score'),
	FUNC = require('../lib/function'),
	async = require('async'),
	SportsRadarDrive = require('../models/sports_radar_score_drives');
var formidable = require('formidable');
var fs = require('fs');	
var dt = require('../lib/function');
/* GET Demands page. */
router.get('/sports_radar_score/:league', function(req, res) {
	SportsRadarScore.find({league:req.params.league}, function (err, scores) {
		if(req.params.league == 'NFL'){
			res.render('sports_radar_score/score_nfl', { title: 'Sports Radar NFL Games',gamesScore:scores,moment:moment });
		}else if(req.params.league == 'NHL'){
			res.render('sports_radar_score/score_nhl', { title: 'Sports Radar NHL Games',gamesScore:scores,moment:moment });
		}else if(req.params.league == 'NBA'){
			res.render('sports_radar_score/score_nba', { title: 'Sports Radar NBA Games',gamesScore:scores,moment:moment });
		}else if(req.params.league == 'MLB'){
			res.render('sports_radar_score/score_mlb', { title: 'Sports Radar MLB Games',gamesScore:scores,moment:moment });
		}
	    
    });
	
});
router.get('/updatescore/:name/:season', function(req, res) {
	var leagueName	=	req.params.name;
	var leagueSeason	=	req.params.season;
	if(leagueName	==	'NFL'){
		request("http://api.sportradar.us/nfl/official/trial/v5/en/games/2018/"+leagueSeason+"/schedule.json?api_key=cnfswcsaqcvtvs2sxst2s68m", { json: true }, (err, response, childbody) => {
			
			(childbody.weeks).forEach(function(element) {
				(element.games).forEach(function(gloop){
					req.body.leagueData	=	gloop;
					req.body.league=leagueName;
					req.body.season=leagueSeason;
					/*var  scheduledate = new Date(gloop.scheduled);
					var dd = scheduledate.getDate();
					var mm = scheduledate.getMonth() + 1; 
					var yyyy = scheduledate.getFullYear();
					var dateOne = new Date(2019, 01, 23); 
					var dateTwo = new Date(2019, 02, 02);
					var rescheduledate	=	new Date(yyyy, mm, dd);*/
					//if(rescheduledate	>	dateOne && rescheduledate	<	dateTwo){
						/*req.body.game_id=gloop.id;
						req.body.status=gloop.status;
						req.body.league=leagueName;
						req.body.home_id=gloop.home.id;
						req.body.home_name=gloop.home.name;
						req.body.home_alias=gloop.home.alias;
						if(typeof gloop.scoring != "undefined" && typeof gloop.scoring.home_points != "undefined"){
							req.body.home_points=gloop.scoring.home_points;
						}
						req.body.away_id=gloop.away.id;
						req.body.away_name=gloop.away.name;
						req.body.away_alias=gloop.away.alias;
						if(typeof gloop.scoring != "undefined" && typeof gloop.scoring.away_points != "undefined"){
							req.body.away_points=gloop.scoring.away_points;
						}
						req.body.created=gloop.scheduled;	*/
						
						var score = new SportsRadarScore(req.body);
						score.save(function(err, scores) {
							
							
						});
					//}
					
				})
			})
		});
			res.redirect('/sportradars/sports_radar_score/NFL');				
	}else if(leagueName	==	'NHL'){
		request("https://api.sportradar.us/nhl/trial/v6/en/games/2018/"+leagueSeason+"/schedule.json?api_key=a7c4he3du9b5c833qpnuks9r", { json: true }, (err, response, childbody) => {
						
			if(typeof(childbody.games) != "undefined" || childbody.games != null){
				(childbody.games).forEach(function(gloop) {
					req.body.leagueData	=	gloop;
					req.body.league=leagueName;
					req.body.season=leagueSeason;
					var score = new SportsRadarScore(req.body);
					score.save(function(err, scores) {
						
						
					});
					/*var  scheduledate = new Date(gloop.scheduled);
					var dd = scheduledate.getDate();
					var mm = scheduledate.getMonth() + 1; 
					var yyyy = scheduledate.getFullYear();
					var dateOne = new Date(2019, 01, 23); 
					var dateTwo = new Date(2019, 01, 27);
					var rescheduledate	=	new Date(yyyy, mm, dd);
					if(rescheduledate	>	dateOne && rescheduledate	<	dateTwo){
						req.body.game_id=gloop.id;
						req.body.status=gloop.status;
						req.body.league=leagueName;
						req.body.home_id=gloop.home.id;
						req.body.home_name=gloop.home.name;
						req.body.home_alias=gloop.home.alias;
						req.body.home_points=gloop.home_points;
						req.body.away_id=gloop.away.id;
						req.body.away_name=gloop.away.name;
						req.body.away_alias=gloop.away.alias;
						req.body.away_points=gloop.away_points;
						req.body.created=gloop.scheduled;	
						
						
					}*/
					
				})
			}
			
		});
		res.redirect('/sportradars/sports_radar_score/NHL');			
	}else if(leagueName	==	'MLB'){
		request("https://api.sportradar.us/mlb/trial/v6.5/en/games/2018/"+leagueSeason+"/schedule.json?api_key=3h4d3zjgcw8m53dsxbqphdzk", { json: true }, (err, response, childbody) => {
			if(typeof(childbody.games) != "undefined" || childbody.games != null){
				(childbody.games).forEach(function(gloop) {
					req.body.leagueData	=	gloop;
					req.body.league=leagueName;
					req.body.season=leagueSeason;
					var score = new SportsRadarScore(req.body);
					score.save(function(err, scores) {
						
						
					});
					/*var  scheduledate = new Date(gloop.scheduled);
					var dd = scheduledate.getDate();
					var mm = scheduledate.getMonth() + 1; 
					var yyyy = scheduledate.getFullYear();
					var dateOne = new Date(2019, 01, 23); 
					var dateTwo = new Date(2019, 01, 26);
					var rescheduledate	=	new Date(yyyy, mm, dd);*/
				//if(rescheduledate	>	dateOne && rescheduledate	<	dateTwo){
					/*req.body.game_id=gloop.id;
					req.body.status=gloop.status;
					req.body.league=leagueName;
					req.body.home_id=gloop.home.id;
					req.body.home_name=gloop.home.name;
					req.body.home_alias=gloop.home.alias;
					req.body.home_points=gloop.home_points;
					req.body.away_id=gloop.away.id;
					req.body.away_name=gloop.away.name;
					req.body.away_alias=gloop.away.alias;
					req.body.away_points=gloop.away_points;
					req.body.created=gloop.scheduled;	
					var score = new SportsRadarScore(req.body);
					score.save(function(err, scores) {
						
						
					});	*/
				//}
			});
			}
		});
		res.redirect('/sportradars/sports_radar_score/MLB');	
	}else if(leagueName	==	'NBA'){
		request("https://api.sportradar.us/nba/trial/v5/en/games/2018/"+leagueSeason+"/schedule.json?api_key=rxnwvw4myu6xd488basdrenn", { json: true }, (err, response, childbody) => {
			
			(childbody.games).forEach(function(gloop) {
				req.body.leagueData	=	gloop;
				req.body.league=leagueName;
				req.body.season=leagueSeason;
				var score = new SportsRadarScore(req.body);
				score.save(function(err, scores) {
					
					
				});
				/*var  scheduledate = new Date(gloop.scheduled);
				var dd = scheduledate.getDate();
				var mm = scheduledate.getMonth() + 1; 
				var yyyy = scheduledate.getFullYear();
				var dateOne = new Date(2019, 01, 23); 
				var dateTwo = new Date(2019, 01, 26);
				var rescheduledate	=	new Date(yyyy, mm, dd);
				if(rescheduledate	>	dateOne && rescheduledate	<	dateTwo){
					req.body.game_id=gloop.id;
					req.body.status=gloop.status;
					req.body.league=leagueName;
					req.body.home_id=gloop.home.id;
					req.body.home_name=gloop.home.name;
					req.body.home_alias=gloop.home.alias;
					req.body.home_points=gloop.home_points;
					req.body.away_id=gloop.away.id;
					req.body.away_name=gloop.away.name;
					req.body.away_alias=gloop.away.alias;
					req.body.away_points=gloop.away_points;
					req.body.created=gloop.scheduled;	
					var score = new SportsRadarScore(req.body);
					score.save(function(err, scores) {
						
						
					});	
				}*/
			});
		});
		res.redirect('/sportradars/sports_radar_score/NBA');	
	}
	
});

router.get('/add', function(req, res, next) {
	res.render('sports_radar_score/add',{ title: 'Games',errorMsg: '' });		
});
router.post('/save', function(req, res, next) {
	
});
router.get('/edit/:id', function(req, res, next) {
	SportsRadarScore.findById(req.params.id, function (err, score) {
		res.render('sports_radar_score/edit', { title: 'Score',scoredata:score,errorMsg: ''});
	});	
});

router.post('/update/:id',function(req, res, next) {
	var currentPath = process.cwd();
	var form = new formidable.IncomingForm();
	form.parse(req, function (err, fields, files) {
		
		var oldpath = files.hometeamicon.path;
		var newpath = currentPath +"/public/upload/games/"+ files.hometeamicon.name;
		var oldawaypath = files.awayteamicon.path;
		var newawaypath = currentPath +"/public/upload/games/"+ files.awayteamicon.name;
		var body={};
		if(files.hometeamicon.name !=''){
		  fs.rename(oldpath, newpath, function (err) {
			if (err) throw err;
			body.hometeamicon=files.hometeamicon.name;
			
		  });
		}
		
		if(files.awayteamicon.name !=''){
		  fs.rename(oldawaypath, newawaypath, function (err) {
			if (err) throw err;
			body.awayteamicon=files.awayteamicon.name;
			
		  });
		}
		SportsRadarScore.findOneAndUpdate(
			{ _id: req.params.id },
			body,
			{ runValidators: true, context: 'query' },
			(err, score) => {
				
				if (err) {
					SportsRadarScore.findById(req.params.id, function (errdata, scoreupdate) {
						res.render('sports_radar_score/edit',{scoredata:scoreupdate, errorMsg: err.errors});
					});
					
				}else{
					req.flash('success', 'You have update category successfully. Thank you');
					res.redirect('/sportradars/score');	
				}
			}
		)
		
	
			
	 });
		
});
router.get('/games_score/:league/:id', function(req, res, next) {

	SportsRadarScore.findOne({_id:req.params.id}, function (err, scores) {
		
		/* if(scores){
			
			res.render('games/view_score', { title: 'Games Score',scoredata:scores});
		}else{ */
			
			//Game.findOne({_id:req.params.id}, function (err, game1) {
				if(req.params.league=="NFL"){
					game_feed_url	=	"http://api.sportradar.us/nfl/official/trial/v5/en/games/"+scores.game_id+"/statistics.json?api_key=cnfswcsaqcvtvs2sxst2s68m";
				}else if(req.params.league=="NHL"){
					game_feed_url	=	"http://api.sportradar.us/nhl/trial/v6/en/games/"+scores.game_id+"/summary.json?api_key=a7c4he3du9b5c833qpnuks9r";
				}else if(req.params.league=="NBA"){
					game_feed_url	=	"http://api.sportradar.us/nba/trial/v5/en/games/"+scores.game_id+"/summary.json?api_key=rxnwvw4myu6xd488basdrenn";
				}else if(req.params.league=="MLB"){
					game_feed_url	=	"http://api.sportradar.us/mlb/trial/v6.5/en/games/"+scores.game_id+"/summary.json?api_key=3h4d3zjgcw8m53dsxbqphdzk";
				}				
				request(game_feed_url, { json: true }, (err, response, body) => {
					
					if (err) {
						return console.log(err+'ssdaas'); 
					}else{
						var home_points	=	0;
						var away_points	=	0;
						console.log(scores.league);
						if(scores.league=='NFL'){
							
							/* req.body.game_id=scores.game_id;
							req.body.status=body.status;
							req.body.home_id=body.summary.home.id;
							req.body.home_name=body.summary.home.name;
							req.body.home_market=body.summary.home.market;
							req.body.home_alias=body.summary.home.alias;
							req.body.home_points=body.summary.home.points;
							req.body.away_id=body.summary.away.id;
							req.body.away_name=body.summary.away.name;
							req.body.away_market=body.summary.away.market;
							req.body.away_alias=body.summary.away.alias;
							req.body.away_points=body.summary.away.points;
							req.body.created=body.scheduled; */
							home_points =	body.home.points;
							away_points =	body.away.points;
						}else if(scores.league=='NHL' || scores.league=='NBA'){
							/* req.body.game_id=scores.game_id;
							req.body.status=body.status;
							req.body.home_id=body.home.id;
							req.body.home_name=body.home.name;
							req.body.home_market=body.home.market;
							req.body.home_alias=body.home.alias;
							req.body.home_points=body.home.points;
							req.body.away_id=body.away.id;
							req.body.away_name=body.away.name;
							req.body.away_market=body.away.market;
							req.body.away_alias=body.away.alias;
							req.body.away_points=body.away.points;
							req.body.created=body.scheduled; */
							home_points =	body.home.points;
							away_points =	body.away.points;
						}else if(scores.league=='MLB'){
							
							if(body.game.home.win && body.game.home.loss){
								home_points =	body.game.home.win + body.game.home.loss;
							}else{
								home_points =	0;
							}
							if(body.game.away.win && body.game.away.loss){
								away_points =	body.game.away.win + body.game.away.loss;
							}else{
								away_points = 0;
							}
							/* req.body.game_id	=	scores.game_id;
							req.body.status		=	body.game.status;
							req.body.home_id	=	body.game.home.id;
							req.body.home_name	=	body.game.home.name;
							req.body.home_market	=body.game.home.market;
							req.body.home_alias=body.game.home.abbr;
							req.body.home_points=home_points;
							req.body.away_id=body.game.away.id;
							req.body.away_name=body.game.away.name;
							req.body.away_market=body.game.away.market;
							req.body.away_alias=body.game.away.abbr;
							req.body.away_points=away_points;
							req.body.created=body.game.scheduled; */

						}
						
						SportsRadarScore.findOneAndUpdate({_id: req.params.id }, { $set: { away_points: away_points, home_points: home_points}}).exec(function(err, scoreDta){
							if(err){
								console.log(err);
								return false;
							}else{
								res.render('sports_radar_score/view_score', { title: 'Games Score',scoredata:scores});
							}
							
						})	
						
					}
					
				})
			//});	
		 	
		//}
    });
	
		
});

router.get('/games_score_drive/:league/:id', function(req, res, next) {
		
		SportsRadarDrive.findOne({game_id:req.params.id}, function (err, scoreDrive) {
			if(scoreDrive){
				res.redirect('/games/score?league='+req.params.league);	
				//	res.render('sports_radar_score/view_score', { title: 'Score Drive',scoreDrivedata:scoreDrive});
			}else if(err){
				return console.log(err); 
			}else{
				if(req.params.league=="NFL"){
					game_feed_url	=	"https://api.sportradar.us/nfl/official/trial/v5/en/games/"+req.params.id+"/boxscore.json?api_key=cnfswcsaqcvtvs2sxst2s68m";	
				}else if(req.params.league=="NBA"){
					game_feed_url	=	"http://api.sportradar.us/nba/trial/v5/en/games/"+req.params.id+"/boxscore.json?api_key=rxnwvw4myu6xd488basdrenn";	
				}else if(req.params.league=="NHL"){
					game_feed_url	=	"http://api.sportradar.us/nhl/trial/v6/en/games/"+req.params.id+"/boxscore.json?api_key=a7c4he3du9b5c833qpnuks9r";
				}
						
				request(game_feed_url, { json: true }, (err, response, body) => {

					if (err) {
						return console.log(err+'ssdaas'); 
					}else{ 
						req.body.game_id 	= req.params.id;
						req.body.gameData	=	body;
						 
					 	var sportsradarDrive = new SportsRadarDrive(req.body);
						sportsradarDrive.save(function(err, scores) {
							if(err){
								console.log(err);
								return false;
							}else{
								res.redirect('/games/score?league='+req.params.league);	
							}
							
							
						});	 
					}
					
				})
			}
			
		});	
		
		
});
router.get('/update_score_detail/:league',function(req,res,next){
	Score.find({league:req.params.league,status:'closed'}, function (err, scores) {

		dt.processArray(scores,req.params.league);
		

	})
})
module.exports = router;