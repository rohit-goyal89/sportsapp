var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
var Size = require('../models/size');
var formidable = require('formidable');
var fs = require('fs');

/* GET home page. */
router.get('/', function(req, res) {
	
	Size.find({}, function (err, size) {
        res.render('size/index', { title: 'Size',sizedata:size });
    });
  
});
router.get('/add', function(req, res, next) {
	res.render('size/add',{ title: 'Size',errorMsg: ''});
	
});
router.get('/edit/:id', function(req, res, next) {
	Size.findById(req.params.id, function (err, size) {
		res.render('size/edit', { title: 'Size',sizedata:size,errorMsg: ''});
	});	
});
router.post('/save', function(req, res, next) {
	var size = new Size(req.body);
    size.save(function(err, size) {
        if (err) throw err;
		
		req.flash('success', 'You have created size successfully.');
		res.redirect('/size');	
	})	
});

router.post('/update/:id', function(req, res, next) {
	Size.findByIdAndUpdate(
		req.params.id,
		req.body,
		{new: true},
		(err, group) => {
			if (err) throw err;
			
			req.flash('success', 'You have updated size successfully');
			res.redirect('/size');
		}
	)
	
		
});

router.get('/delete/:id', function(req, res, next) {
		
	Size.findOneAndDelete({ _id: req.params.id }, function (err,result) {
			
			if (!result) {
				req.flash('error', 'Invalid Request');
				res.redirect('/size');
			}else{
				req.flash('success', 'Size deleted successfully.');
				res.redirect('/size');
			}	
			
	});

});
module.exports = router;