exports.index = function(req, res){
  res.render('login');
};
exports.register = function(req, res){
  res.render('register');
};
exports.forgot_password = function(req, res){
  res.render('forgot_password');
};
exports.dashboard = function(req, res){
  res.render('index');
};
exports.reset_password = function(req, res){
  res.render('reset_password');
};