var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment'),
	Game = require('../models/game');
	Score = require('../models/score');
	League = require('../models/league');
	FUNC = require('../lib/function');
/* GET Demands page. */
router.get('/', function(req, res) {

	League.find({}, function (err, league) {
		    res.render('leagues/index', { title: 'League',leagues:league,moment:moment });
    });
});

router.get('/add', function(req, res, next) {
	res.render('games/add',{ title: 'Games',errorMsg: '' });		
});
router.post('/save', function(req, res, next) {
	var game = new Game(req.body);
    game.save(function(err, game) {
        if (err) throw err;
		
		req.flash('success', 'You have created game successfully.');
		res.redirect('/games');	
	})	
});

router.get('/games_score/:id', function(req, res, next) {

	Score.findOne({game_id:req.params.id}, function (err, scores) {
		
		if(scores){
			
			res.render('games/view_score', { title: 'Games Score',scoredata:scores});
		}else{
			
			Game.findOne({_id:req.params.id}, function (err, game1) {

				request(game1.feed_url, { json: true }, (err, response, body) => {
					if (err) {
						return console.log(err+'ssdaas'); 
					}else{
						
						if(game1.name=='NFL'){
							req.body.game_id=game1.id;
							req.body.status=body.status;
							req.body.home_id=body.summary.home.id;
							req.body.home_name=body.summary.home.name;
							req.body.home_market=body.summary.home.market;
							req.body.home_alias=body.summary.home.alias;
							req.body.home_points=body.summary.home.points;
							req.body.away_id=body.summary.away.id;
							req.body.away_name=body.summary.away.name;
							req.body.away_market=body.summary.away.market;
							req.body.away_alias=body.summary.away.alias;
							req.body.away_points=body.summary.away.points;
							req.body.created=body.scheduled;
						}else if(game1.name=='NHL' || game1.name=='NBA'){
							req.body.game_id=game1.id;
							req.body.status=body.status;
							req.body.home_id=body.home.id;
							req.body.home_name=body.home.name;
							req.body.home_market=body.home.market;
							req.body.home_alias=body.home.alias;
							req.body.home_points=body.home.points;
							req.body.away_id=body.away.id;
							req.body.away_name=body.away.name;
							req.body.away_market=body.away.market;
							req.body.away_alias=body.away.alias;
							req.body.away_points=body.away.points;
							req.body.created=body.scheduled;
						}else if(game1.name=='MLB'){
							req.body.game_id=game1.id;
							req.body.status=body.game.status;
							req.body.home_id=body.game.home.id;
							req.body.home_name=body.game.home.name;
							req.body.home_market=body.game.home.market;
							req.body.home_alias=body.game.home.alias;
							req.body.home_points=body.game.home.points;
							req.body.away_id=body.game.away.id;
							req.body.away_name=body.game.away.name;
							req.body.away_market=body.game.away.market;
							req.body.away_alias=body.game.away.alias;
							req.body.away_points=body.game.away.points;
							req.body.created=body.game.scheduled;
						}
						
						var score = new Score(req.body);
						score.save(function(err, scores) {
							res.render('games/view_score', { title: 'Games Score',scoredata:scores});
							
						});	
					}
					
				})
			});	
		 	
		}
    });
	
		
});
module.exports = router;