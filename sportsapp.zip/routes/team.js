var express = require('express');
var router = express.Router();
const request = require('request');
var moment = require('moment');
/* GET Demands page. */
router.get('/', function(req, res) {
	
	request('https://api.seatgeek.com/2/performers?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ&per_page=10&q=fifa', { json: true }, (err, response, body) => {
		  if (err) { return console.log(err+'ssdaas'); }
		  console.log(body);
		  res.render('teams/index', { title: 'Teams',teams:body.performers });
	});
	
	
  
});
module.exports = router;
