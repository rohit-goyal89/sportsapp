var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment-timezone'),
	Game = require('../models/game'),
	Score = require('../models/score'),
	FUNC = require('../lib/function'),
	async = require('async'),
	ScoreDrives = require('../models/score_drives');
	Leaders = require('../models/leaders');
	Players = require('../models/player');
	Venues = require('../models/venue');
	Standing = require('../models/standing');
	Conference = require('../models/conference');
	Division = require('../models/division');
var formidable = require('formidable');
var fs = require('fs');	
var mongoose = require('mongoose');
var dt = require('../lib/function');
mongoose.set('debug', true);
/* GET Demands page. */
router.get('/score', function(req, res) {
	if(req.query.league){
		var dateobj = new Date();
		var yy  =  dateobj.getFullYear(); 
		var mm  = (dateobj.getMonth()+1) ; 
		var dd  = dateobj.getDate();
		if(dd <	10){
				dd	=	"0"+dd;
		}
		if(mm < 10){
			mm	=	"0"+mm;
		}
		Score.find({league:req.query.league}, function (err, scores) {
		    res.render('games/score', { title: 'Games Score',gamesScore:scores,moment:moment });
		});
	}else{
		Score.find({}, function (err, scores) {
		    res.render('games/score', { title: 'Games Score',gamesScore:scores,moment:moment });
		});
	}
	
	
});
router.get('/updatescore/:name/:season', function(req, res) {
	var leagueName	=	req.params.name;
	var leagueSeason	=	req.params.season;
	console.log(leagueName+"----------------"+leagueSeason);
	if(leagueName	==	'NFL'){
		Score.remove({league:leagueName,season:leagueSeason}).then((scoredel) => { 
		request("http://api.sportradar.us/nfl/official/trial/v5/en/games/2018/"+leagueSeason+"/schedule.json?api_key=cnfswcsaqcvtvs2sxst2s68m", { json: true }, (err, response, childbody) => {
			
			(childbody.weeks).forEach(function(element) {
				(element.games).forEach(function(gloop){
					
					/* var  scheduledate = new Date(gloop.scheduled);
					var dd = scheduledate.getDate();
					var mm = scheduledate.getMonth() + 1; 
					var yyyy = scheduledate.getFullYear();
					var dateOne = new Date(2019, 01, 23); 
					var dateTwo = new Date(2019, 02, 02);
					var rescheduledate	=	new Date(yyyy, mm, dd); */
					//if(rescheduledate	>	dateOne && rescheduledate	<	dateTwo){
						req.body.game_id=gloop.id;
						req.body.status=gloop.status;
						req.body.league=leagueName;
						req.body.season=leagueSeason;
						req.body.home_id=gloop.home.id;
						req.body.home_name=gloop.home.name;
						req.body.home_alias=gloop.home.alias;
						if(typeof gloop.scoring != "undefined" && typeof gloop.scoring.home_points != "undefined"){
							req.body.home_points=gloop.scoring.home_points;
						}
						req.body.away_id=gloop.away.id;
						req.body.away_name=gloop.away.name;
						req.body.away_alias=gloop.away.alias;
						if(typeof gloop.scoring != "undefined" && typeof gloop.scoring.away_points != "undefined"){
							req.body.away_points=gloop.scoring.away_points;
						}
						req.body.created	= gloop.scheduled;	
						req.body.dateutc	= gloop.scheduled;	
						req.body.venue_id = gloop.venue.id;
						req.body.venue=gloop.venue.name;
						
						req.body.home_logo	= "/upload/teams/"+dt.nameUnderscore(gloop.home.name)+'.png';
						req.body.away_logo	=	 "/upload/teams/"+dt.nameUnderscore(gloop.away.name)+'.png';
						
						var score = new Score(req.body);
						score.save(function(err, scores) {
							
							
						});  
						
						
						/* Score.findOneAndUpdate(
							{ game_id: gloop.id },
							req.body,
							(err, score) => {
								
								if (err) {
									console.log(err)
									
								}
							}
						) */
					//}
					
				})
			})
		});
				
		res.redirect('/games/score');	
		})
	}else if(leagueName	==	'NHL'){
		Score.remove({league:leagueName,season:leagueSeason}).then((scoredel) => { 
		 request("https://api.sportradar.us/nhl/production/v6/en/games/2018/"+leagueSeason+"/schedule.json?api_key=p43cve7ruzvm62w63vym8vyf", { json: true }, (err, response, childbody) => {
						
			if(typeof(childbody.games) != "undefined" || childbody.games != null){
				(childbody.games).forEach(function(gloop) {
						 req.body.game_id=gloop.id;
						req.body.status=gloop.status;
						req.body.league=leagueName;
						req.body.season=leagueSeason;
						req.body.home_id=gloop.home.id;
						req.body.home_name=gloop.home.name;
						req.body.home_alias=gloop.home.alias;
						req.body.home_points=gloop.home_points;
						req.body.away_id=gloop.away.id;
						req.body.away_name=gloop.away.name;
						req.body.away_alias=gloop.away.alias;
						req.body.away_points=gloop.away_points;
						req.body.home_logo="/upload/teams/"+dt.mlbnameUnderscore(gloop.home.name)+'.png';
						req.body.away_logo= "/upload/teams/"+dt.mlbnameUnderscore(gloop.away.name)+'.png';
						req.body.created=gloop.scheduled;	
						req.body.dateutc=gloop.scheduled;	
						req.body.venue_id=gloop.venue.id;
						req.body.venue=gloop.venue.name;
						req.body.timezone=gloop.venue.time_zone;
						var score = new Score(req.body);
						score.save(function(err, scores) {
							
							
						});
					
				})
			}
			
		}); 
				
		res.redirect('/games/score');	
		});
	}else if(leagueName	==	'MLB'){
		Score.remove({league:'MLB',season:leagueSeason}).then((scoredel) => { 
		request("https://api.sportradar.us/mlb/production/v6.5/en/games/2019/"+leagueSeason+"/schedule.json?api_key=jqk7vyqb86xtjb74p4v3jedz", { json: true }, (err, response, childbody) => {
			if(typeof(childbody.games) != "undefined" || childbody.games != null){
				
				(childbody.games).forEach(function(gloop) {
			
					req.body.game_id=gloop.id;
					req.body.status=gloop.status;
					req.body.league=leagueName;
					req.body.season=leagueSeason;
					req.body.home_id=gloop.home.id;
					req.body.home_name=gloop.home.name;
					req.body.home_alias=gloop.home.alias;
					req.body.home_points=gloop.home_points;
					req.body.away_id=gloop.away.id;
					req.body.away_name=gloop.away.name;
					req.body.away_alias=gloop.away.alias;
					req.body.away_points=gloop.away_points;
					req.body.home_logo="/upload/teams/"+dt.mlbnameUnderscore(gloop.home.market+" "+gloop.home.name)+'.png';
					req.body.away_logo= "/upload/teams/"+dt.mlbnameUnderscore(gloop.away.market+" "+gloop.away.name)+'.png';
					req.body.created=gloop.scheduled;	
					req.body.dateutc=gloop.scheduled;
					req.body.venue_id=gloop.venue.id;
					req.body.venue=gloop.venue.name;
				req.body.timezone="";
					req.body.venue_logo="";
					var score = new Score(req.body);
					score.save(function(err, scores) {
						if(err){
							console.log(err);
						}
						
					});	
			});
			}
		});
		
		res.redirect('/games/score?league=MLB');	
		});
	}else if(leagueName	==	'NBA'){
		Score.remove({league:'NBA',season:leagueSeason}).then((sc) => { 
			request("https://api.sportradar.us/nba/production/v5/en/games/2018/"+leagueSeason+"/schedule.json?api_key=3grt5re47ywmaj3k96q2gp3f", { json: true }, (err, response, childbody) => {
			
			(childbody.games).forEach(function(gloop) {
				req.body.game_id=gloop.id;
				req.body.status=gloop.status;
				req.body.league=leagueName;
				req.body.season=leagueSeason;
				req.body.home_id=gloop.home.id;
				req.body.home_name=gloop.home.name;
				req.body.home_alias=gloop.home.alias;
				req.body.home_points=gloop.home_points;
				req.body.away_id=gloop.away.id;
				req.body.away_name=gloop.away.name;
				req.body.away_alias=gloop.away.alias;
				req.body.away_points=gloop.away_points;
				req.body.home_logo	= "/upload/teams/"+dt.nameUnderscore(gloop.home.name)+'.png';
				req.body.away_logo	=	 "/upload/teams/"+dt.nameUnderscore(gloop.away.name)+'.png';
				req.body.created	=	gloop.scheduled;	
				req.body.dateutc=gloop.scheduled;
				req.body.venue_id=gloop.venue.id;
				req.body.venue=gloop.venue.name;
				req.body.timezone=gloop.time_zones.venue;
				req.body.venue_logo="";
				var score = new Score(req.body);
				score.save(function(err, scores) {
					
					
				});	 
				//} 
				
			});
		});
		})
		
		res.redirect('/games/score');	
	}
	
});

router.get('/add', function(req, res, next) {
	res.render('games/add',{ title: 'Games',errorMsg: '' });		
});
router.post('/save', function(req, res, next) {
	
});
router.get('/edit/:id', function(req, res, next) {
	Score.findById(req.params.id, function (err, score) {
		res.render('games/edit', { title: 'Score',scoredata:score,errorMsg: ''});
	});	
});

router.post('/update/:id',function(req, res, next) {
	var currentPath = process.cwd();
	var form = new formidable.IncomingForm();
	form.parse(req, function (err, fields, files) {
		
		var oldpath = files.hometeamicon.path;
		var newpath = currentPath +"/public/upload/games/"+ files.hometeamicon.name;
		var oldawaypath = files.awayteamicon.path;
		var newawaypath = currentPath +"/public/upload/games/"+ files.awayteamicon.name;
		var body={};
		if(files.hometeamicon.name !=''){
		  fs.rename(oldpath, newpath, function (err) {
			if (err) throw err;
			body.hometeamicon=files.hometeamicon.name;
			
		  });
		}
		
		if(files.awayteamicon.name !=''){
		  fs.rename(oldawaypath, newawaypath, function (err) {
			if (err) throw err;
			body.awayteamicon=files.awayteamicon.name;
			
		  });
		}
		Score.findOneAndUpdate(
			{ _id: req.params.id },
			body,
			{ runValidators: true, context: 'query' },
			(err, score) => {
				
				if (err) {
					Score.findById(req.params.id, function (errdata, scoreupdate) {
						res.render('games/edit',{scoredata:scoreupdate, errorMsg: err.errors});
					});
					
				}else{
					req.flash('success', 'You have update category successfully. Thank you');
					res.redirect('/games/score');	
				}
			}
		)
		
	
			
	 });
		
});
router.get('/games_score/:league/:id', function(req, res, next) {

	Score.findOne({_id:req.params.id}, function (err, scores) {
		
		 if(scores){	
			res.render("/games/score", { title: 'Games Score',scoredata:scores});
		}else{ 
			
			//Game.findOne({_id:req.params.id}, function (err, game1) {
				if(req.params.league=="NFL"){
					game_feed_url	=	"http://api.sportradar.us/nfl/official/trial/v5/en/games/"+req.params.id+"/statistics.json?api_key=cnfswcsaqcvtvs2sxst2s68m";
				}else if(req.params.league=="NHL"){
					game_feed_url	=	"http://api.sportradar.us/nhl/trial/v6/en/games/"+req.params.id+"/summary.json?api_key=a7c4he3du9b5c833qpnuks9r";
				}else if(req.params.league=="NBA"){
					game_feed_url	=	"http://api.sportradar.us/nba/trial/v5/en/games/"+req.params.id+"/summary.json?api_key=rxnwvw4myu6xd488basdrenn";
				}else if(req.params.league=="MLB"){
					game_feed_url	=	"http://api.sportradar.us/mlb/trial/v6.5/en/games/"+req.params.id+"/summary.json?api_key=3h4d3zjgcw8m53dsxbqphdzk";
				}				
				request(game_feed_url, { json: true }, (err, response, body) => {
					
					if (err) {
						return console.log(err+'ssdaas'); 
					}else{
						var home_points	=	0;
						var away_points	=	0;
						if(req.params.league=='NFL'){
							
							req.body.game_id=req.params.id;
							req.body.status=body.status;
							req.body.league=req.params.league;
							req.body.home_id=body.summary.home.id;
							req.body.home_team_name=body.summary.home.name;
							req.body.home_team_market=body.summary.home.market;
							req.body.home_team_alias=body.summary.home.alias;
							req.body.home_team_point=body.summary.home.points;
							req.body.away_id=body.summary.away.id;
							req.body.away_team_name=body.summary.away.name;
							//req.body.away_market=body.summary.away.market;
							req.body.away_alias=body.summary.away.alias;
							req.body.away_points=body.summary.away.points;
							req.body.created=body.scheduled; 
							/* home_points =	body.home.points;
							away_points =	body.away.points; */
						}else if(req.params.league=='NHL' || req.params.league=='NBA'){
							 req.body.game_id=req.params.id;
							req.body.status=body.status;
							req.body.league=req.params.league;
							req.body.home_id=body.home.id;
							req.body.home_team_name=body.home.name;
							req.body.home_team_market=body.home.market;
							req.body.home_team_alias=body.home.alias;
							req.body.home_team_point=body.home.points;
							//req.body.away_id=body.away.id;
							req.body.away_team_name=body.away.name;
							//req.body.away_market=body.away.market;
							req.body.away_alias=body.away.alias;
							req.body.away_points=body.away.points;
							req.body.created=body.scheduled; 
							/* home_points =	body.home.points;
							away_points =	body.away.points; */
						}else if(req.params.league=='MLB'){
							
							/* if(body.game.home.win && body.game.home.loss){
								home_points =	body.game.home.win + body.game.home.loss;
							}else{
								home_points =	0;
							}
							if(body.game.away.win && body.game.away.loss){
								away_points =	body.game.away.win + body.game.away.loss;
							}else{
								away_points = 0;
							} */
							 req.body.game_id	=	req.params.id;
							req.body.status		=	body.game.status;
							req.body.league=req.params.league;
							req.body.home_id	=	body.game.home.id;
							req.body.home_team_name	=	body.game.home.name;
							req.body.home_team_market	=body.game.home.market;
							req.body.home_team_alias=body.game.home.abbr;
							req.body.home_team_point=home_points;
							req.body.away_id=body.game.away.id;
							req.body.away_name=body.game.away.name;
							//req.body.away_market=body.game.away.market;
							req.body.away_alias=body.game.away.abbr;
							req.body.away_points=away_points;
							req.body.created=body.game.scheduled; 

						}
						var scoreDrive = new ScoreDrives(req.body);
						scoreDrive.save(function(err, scores) {
							if(err){
								console.log(err);
								return false;
							}else{
								res.redirect('/games/score?league='+req.params.league);	
							}
							
							
						});
					/* 	Score.findOneAndUpdate({_id: req.params.id }, { $set: { away_points: away_points, home_points: home_points}}).exec(function(err, scoreDta){
							if(err){
								console.log(err);
								return false;
							}else{
								res.redirect('/games/score?league=MLB');
							}
							
						})	 */
						
					}
					
				})
			//});	
		 	
		}
    });
	
		
});

router.get('/games_score_drive/:league/:id', function(req, res, next) {
		
		ScoreDrives.findOne({game_id:req.params.id}, function (err, scoreDrive) {
			if(scoreDrive){
				res.redirect('/games/score?league='+req.params.league);	
				//	res.render('games/view_score', { title: 'Score Drive',scoreDrivedata:scoreDrive});
			}else if(err){
				return console.log(err); 
			}else{
				if(req.params.league=="NFL"){
					game_feed_url	=	"http://api.sportradar.us/nfl/official/trial/v5/en/games/"+req.params.id+"/boxscore.json?api_key=cnfswcsaqcvtvs2sxst2s68m";
				}else if(req.params.league=="NHL"){
					game_feed_url	=	"http://api.sportradar.us/nhl/trial/v6/en/games/"+req.params.id+"/summary.json?api_key=a7c4he3du9b5c833qpnuks9r";
				}else if(req.params.league=="NBA"){
					game_feed_url	=	"http://api.sportradar.us/nba/trial/v5/en/games/"+req.params.id+"/boxscore.json?api_key=rxnwvw4myu6xd488basdrenn";
				}else if(req.params.league=="MLB"){
					game_feed_url	=	"http://api.sportradar.us/mlb/trial/v6.5/en/games/"+req.params.id+"/summary.json?api_key=3h4d3zjgcw8m53dsxbqphdzk";
				}
				//game_feed_url	=	"https://api.sportradar.us/nfl/official/trial/v5/en/games/"+req.params.id+"/boxscore.json?api_key=cnfswcsaqcvtvs2sxst2s68m";				
				request(game_feed_url, { json: true }, (err, response, body) => {
					if (err) {
						return console.log(err+'ssdaas'); 
					}else{
						if(req.params.league=="NBA"){
							req.body.game_id 	= body.id;
							req.body.league 	= req.params.league;
							req.body.home_team_name 	= body.home.name;
							req.body.home_team_point 	= body.home.points;
							req.body.home_team_timeout 	= 0;
							req.body.home_team_market 	= body.home.market;
							req.body.home_team_alias 	= body.home.alias;
							req.body.away_team_name 	= body.away.name;
							req.body.away_team_point 	= body.away.points;
							req.body.away_team_timeout 	= 0;
							req.body.away_team_market 	= body.away.market;
							req.body.away_team_alias 	= body.away.alias;
							req.body.status 	= body.status;
							req.body.schedule 	= body.scheduled;
							req.body.quarter 	= body.quarter;
							req.body.description 	= 0;
							req.body.situtation_clock 	= body.clock;
							req.body.scores	=	[];
						}else{
							req.body.game_id 	= body.id;
							req.body.league 	= req.params.league;
							req.body.home_team_name 	= body.summary.home.name;
							req.body.home_team_point 	= body.summary.home.points;
							req.body.home_team_timeout 	= body.summary.home.remaining_timeouts;
							req.body.home_team_market 	= body.summary.home.market;
							req.body.home_team_alias 	= body.summary.home.alias;
							req.body.away_team_name 	= body.summary.away.name;
							req.body.away_team_point 	= body.summary.away.points;
							req.body.away_team_timeout 	= body.summary.away.remaining_timeouts;
							req.body.away_team_market 	= body.summary.away.market;
							req.body.away_team_alias 	= body.summary.away.alias;
							req.body.status 	= body.status;
							req.body.schedule 	= body.scheduled;
							req.body.quarter 	= body.quarter;
							req.body.description 	= body.last_event.description;
							req.body.situtation_clock 	= body.clock;
							req.body.scores	=	body.scoring;
							req.body.drives	=	[];
							if(typeof body.scoring_drives != "undefined" && (body.scoring_drives).length>0){
								(body.scoring_drives).forEach(function(bscdrive) {
									bscdriveData	=	{};
									bscdriveData.sequence =	bscdrive.sequence;
									if(typeof bscdrive.quarter != "undefined"){
										bscdriveData.quarter =	bscdrive.quarter.number;
									}
									bscdriveData.start_reason =	bscdrive.start_reason;
									bscdriveData.end_reason =	bscdrive.end_reason;
									bscdriveData.duration =	bscdrive.duration;
									bscdriveData.team_name =	bscdrive.team.name;

									bscdriveData.plays	=	[];
									if(typeof bscdrive.plays != "undefined" && (bscdrive.plays).length >0){
										(bscdrive.plays).forEach(function(bscdriveplay) {
											bscdriveplayData	=	{};
											bscdriveplayData.start_time =	bscdriveplay.clock;
											bscdriveplayData.down =	bscdriveplay.start_situation.down;
											bscdriveplayData.yfd =	bscdriveplay.start_situation.yfd;
											bscdriveplayData.location_name =	bscdriveplay.start_situation.location.alias+' '+ bscdriveplay.start_situation.location.yardline;
											bscdriveplayData.description =	bscdriveplay.description;
											(bscdriveData.plays).push(bscdriveplayData);
										})
										
										
									} 
									(req.body.drives).push(bscdriveData); 
								});
							} 
						}
						
						 var scoreDrive = new ScoreDrives(req.body);
						scoreDrive.save(function(err, scores) {
							if(err){
								console.log(err);
								return false;
							}else{
								res.redirect('/games/score?league='+req.params.league);	
							}
							
							
						});	 
					}
					
				})
			}
			
		});	
		
		
});

router.get('/leaders_nba', (req, res) => {
   var response = {};
	Leaders.remove({league:'NBA'}).then((leaderssync) => {
		request('http://api.sportradar.us/nba/trial/v5/en/seasons/2018/REG/leaders.json?api_key=rxnwvw4myu6xd488basdrenn', { json: true }, (err, response, body) => {
			if (err) {
				
			  response.status = false;
			  res.status(400).send(JSON.stringify(response));
			}else{
				if(typeof body.categories !="undefined"){
					(body.categories).forEach(function(leaders){

						req.body.season	=	body.season.type;
						req.body.league	=	body.name;
						var league_name	=	leaders.name;
						var league_type	=	leaders.type;
						req.body.categories_name	=	leaders.name;
						req.body.categories_type	=	leaders.type;
						console.log(leaders.type);
						if(typeof leaders.ranks !="undefined"){
							(leaders.ranks).forEach(function(rankd){
								req.body.rank	=	rankd.rank;
								req.body.score	=	rankd.score;
								req.body.player_id	=	rankd.player.id;
								req.body.player_name	=	rankd.player.full_name;
								req.body.primary_position	=	rankd.player.primary_position;
								req.body.player_pic	=	"";
								req.body.team_market	=	rankd.teams[0].market;
								req.body.team_name	=	rankd.teams[0].name;
								req.body.games_played	=	rankd.total.games_played;
								req.body.games_started	=	rankd.total.games_started;
								req.body.minutes	=	rankd.total.minutes;
								req.body.fgm	=	rankd.total.field_goals_made;
								req.body.fga	=	rankd.total.field_goals_att;
								req.body.avg_points	=	rankd[league_type][league_name];
								req.body.avg_minutes	=	rankd.average.minutes;
					// 			if(leaders.type !=null){
								// 	req.body.avg_points	=	rankd[leaders.type][leaders.name];
								// }
								

								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							})
						}
					})
				}
			  res.redirect('/leader/NBA');
			}
      
		});
	});
});

router.get('/leaders_mlb', (req, res) => {
   var response = {};
	Leaders.remove({league:'MLB'}).then((leaderssync) => {
		request('http://api.sportradar.us/mlb/trial/v6.5/en/seasons/2018/REG/leaders/statistics.json?api_key=3h4d3zjgcw8m53dsxbqphdzk', { json: true }, (err, response, body) => {
			if (err) {
				
			  response.status = false;
			  res.status(400).send(JSON.stringify(response));
			}else{
				if(typeof body.leagues !="undefined"){
					(body.leagues).forEach(function(league){
					if(league.alias != "MLB"){
						req.body.season	=	body.season.type;
						req.body.league	=	"MLB";
						req.body.categories_name	=	league.name;
						
						req.body.runs_scored	=	[];
						req.body.doubles	=	[];
						req.body.triples	=	[];
						req.body.home_runs	=	[];
						req.body.runs_batted_in	=	[];
						req.body.hits	=	[];
						req.body.stolen_bases	=	[];
						req.body.earned_run_average	=	[];
						req.body.whip	=	[];
						req.body.games_won	=	[];
						req.body.strikeouts	=	[];
						req.body.games_saved	=	[];
						req.body.games_completed	=	[];
						
						if(typeof league.hitting.batting_average.players !="undefined"){
							(league.hitting.batting_average.players).forEach(function(baverage){
								req.body.categories_type	=	"batting_average";
								req.body.player_id	=	baverage.id;
								req.body.rank	=	baverage.rank;
								req.body.player_name	=	baverage.preferred_name +" "+baverage.last_name;
								req.body.primary_position	=	baverage.primary_position;
								req.body.avg_points	=	baverage.avg;
								if(baverage.team != null){
									req.body.team_name	=	baverage.team.name;
									req.body.team_market	=	baverage.team.market;
									req.body.team_id	=	baverage.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							})
						}
						
						if(typeof league.hitting.runs_scored.players !="undefined"){
							(league.hitting.runs_scored.players).forEach(function(runsscored){
								req.body.categories_type	=	"runs_scored";
								req.body.player_id	=	runsscored.id;
								req.body.player_name	=	runsscored.preferred_name +" "+runsscored.last_name;
								req.body.primary_position	=	runsscored.primary_position;
								req.body.rank	=	runsscored.rank;
								req.body.avg_points	=	runsscored.runs;
								if(runsscored.team != null){
									req.body.team_name	=	runsscored.team.name;
									req.body.team_market	=	runsscored.team.market;
									req.body.team_id	=	runsscored.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
								
							})
						}
						
						if(typeof league.hitting.doubles.players !="undefined"){
							(league.hitting.doubles.players).forEach(function(dbl){
								req.body.categories_type	=	"doubles";
								req.body.player_id	=	dbl.id;
								req.body.player_name	=	dbl.preferred_name +" "+dbl.last_name;
								req.body.primary_position	=	dbl.primary_position;
								req.body.rank	=	dbl.rank;
								req.body.avg_points	=	dbl.doubles;
								if(dbl.team != null){
									req.body.team_name	=	dbl.team.name;
									req.body.team_market	=	dbl.team.market;
									req.body.team_id	=	dbl.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
								
							})
						}
						
						if(typeof league.hitting.triples.players !="undefined"){
							(league.hitting.triples.players).forEach(function(tpl){
								req.body.categories_type	=	"triples";
								req.body.player_id	=	tpl.id;
								req.body.player_name	=	tpl.preferred_name +" "+tpl.last_name;
								req.body.primary_position	=	tpl.primary_position;
								req.body.rank	=	tpl.rank;
								req.body.avg_points	=	tpl.triples;
								if(tpl.team != null){
									req.body.team_name	=	tpl.team.name;
									req.body.team_market	=	tpl.team.market;
									req.body.team_id	=	tpl.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							})
						}
						
						if(typeof league.hitting.home_runs.players !="undefined"){
							(league.hitting.home_runs.players).forEach(function(hruns){
								req.body.categories_type	=	"home_runs";
								req.body.player_id	=	hruns.id;
								req.body.player_name	=	hruns.preferred_name +" "+hruns.last_name;
								req.body.primary_position	=	hruns.primary_position;
								req.body.rank	=	hruns.rank;
								req.body.avg_points	=	hruns.hr;
								if(hruns.team != null){
									req.body.team_name	=	hruns.team.name;
									req.body.team_market	=	hruns.team.market;
									req.body.team_id	=	hruns.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
								
							})
						}
						
						if(typeof league.hitting.runs_batted_in.players !="undefined"){
							(league.hitting.runs_batted_in.players).forEach(function(rbl){
								req.body.categories_type	=	"runs_batted_in";
								req.body.player_id	=	rbl.id;
								req.body.player_name	=	rbl.preferred_name +" "+rbl.last_name;
								req.body.primary_position	=	rbl.primary_position;
								req.body.rank	=	rbl.rank;
								req.body.avg_points	=	rbl.rbi;
								if(rbl.team != null){
									req.body.team_name	=	rbl.team.name;
									req.body.team_market	=	rbl.team.market;
									req.body.team_id	=	rbl.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
								
							})
						}
						
						if(typeof league.hitting.hits.players !="undefined"){
							(league.hitting.hits.players).forEach(function(hit){
								req.body.categories_type	=	"hits";
								req.body.player_id	=	hit.id;
								req.body.player_name	=	hit.preferred_name +" "+hit.last_name;
								req.body.primary_position	=	hit.primary_position;
								req.body.rank	=	hit.rank;
								req.body.avg_points	=	hit.h;
								if(hit.team != null){
									req.body.team_name	=	hit.team.name;
									req.body.team_market	=	hit.team.market;
									req.body.team_id	=	hit.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
								
							})
						}
						
						if(typeof league.hitting.stolen_bases.players !="undefined"){
							(league.hitting.stolen_bases.players).forEach(function(sbases){
								req.body.categories_type	=	"stolen_bases";
								req.body.player_id	=	sbases.id;
								req.body.player_name	=	sbases.preferred_name +" "+sbases.last_name;
								req.body.primary_position	=	sbases.primary_position;
								req.body.rank	=	sbases.rank;
								req.body.avg_points	=	sbases.sb;
								if(sbases.team != null){
									req.body.team_name	=	sbases.team.name;
									req.body.team_market	=	sbases.team.market;
									req.body.team_id	=	sbases.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
								
							})
						}
						
						if(typeof league.pitching.earned_run_average.players !="undefined"){
							(league.pitching.earned_run_average.players).forEach(function(erunavg){
								req.body.categories_type	=	"earned_run_average";
								req.body.player_id	=	erunavg.id;
								req.body.player_name	=	erunavg.preferred_name +" "+erunavg.last_name;
								req.body.primary_position	=	erunavg.primary_position;
								req.body.rank	=	erunavg.rank;
								req.body.avg_points	=	erunavg.era;
								if(erunavg.team != null){
									req.body.team_name	=	erunavg.team.name;
									req.body.team_market	=	erunavg.team.market;
									req.body.team_id	=	erunavg.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							})
						}
						
						if(typeof league.pitching.whip.players !="undefined"){
							(league.pitching.whip.players).forEach(function(whipab){
								req.body.categories_type	=	"whip";
								req.body.player_id	=	whipab.id;
								req.body.player_name	=	whipab.preferred_name +" "+whipab.last_name;
								req.body.primary_position	=	whipab.primary_position;
								req.body.rank	=	whipab.rank;
								req.body.avg_points	=	whipab.whip;
								if(whipab.team != null){
									req.body.team_name	=	whipab.team.name;
									req.body.team_market	=	whipab.team.market;
									req.body.team_id	=	whipab.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							})
						}
						
						/* if(typeof league.pitching.games_won.players !="undefined"){
							(league.pitching.games_won.players).forEach(function(gameswon){
								req.body.categories_type	=	"games_won";
								req.body.player_id	=	gameswon.id;
								req.body.player_name	=	gameswon.preferred_name +" "+gameswon.last_name;
								req.body.primary_position	=	gameswon.primary_position;
								req.body.rank	=	baverage.rank;
								req.body.avg_points	=	dbl.whip;
								if(gameswon.team != null){
									req.body.team_name	=	gameswon.team.abbr;
									req.body.team_market	=	gameswon.team.market;
									req.body.team_id	=	gameswon.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							
								
							})
						} */
						
						if(typeof league.pitching.strikeouts.players !="undefined"){
							(league.pitching.strikeouts.players).forEach(function(strikeouts){
								req.body.categories_type	=	"strikeouts";
								req.body.player_id	=	strikeouts.id;
								req.body.player_name	=	strikeouts.preferred_name +" "+strikeouts.last_name;
								req.body.primary_position	=	strikeouts.primary_position;
								req.body.rank	=	strikeouts.rank;
								req.body.avg_points	=	strikeouts.strikeouts;
								if(strikeouts.team != null){
									req.body.team_name	=	strikeouts.team.name;
									req.body.team_market	=	strikeouts.team.market;
									req.body.team_id	=	strikeouts.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							
								
							})
							
						}
						
						if(typeof league.pitching.games_saved.players !="undefined"){
							(league.pitching.games_saved.players).forEach(function(gamessaved){
								req.body.categories_type	=	"games_saved";
								req.body.player_id	=	gamessaved.id;
								req.body.player_name	=	gamessaved.preferred_name +" "+gamessaved.last_name;
								req.body.primary_position	=	gamessaved.primary_position;
								req.body.rank	=	gamessaved.rank;
								req.body.avg_points	=	gamessaved.games_saved;
								if(gamessaved.team != null){
									req.body.team_name	=	gamessaved.team.name;
									req.body.team_market	=	gamessaved.team.market;
									req.body.team_id	=	gamessaved.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							
								
							})
						
						}
						
						if(typeof league.pitching.games_completed.players !="undefined"){
							(league.pitching.games_completed.players).forEach(function(gamescompleted){
								req.body.categories_type	=	"games_completed";
								req.body.player_id	=	gamescompleted.id;
								req.body.player_name	=	gamescompleted.preferred_name +" "+gamescompleted.last_name;
								req.body.primary_position	=	gamescompleted.primary_position;
								req.body.rank	=	gamescompleted.rank;
								req.body.avg_points	=	gamescompleted.games_completed;
								if(gamescompleted.team != null){
									req.body.team_name	=	gamescompleted.team.name;
									req.body.team_market	=	gamescompleted.team.market;
									req.body.team_id	=	gamescompleted.team.id;
								}else{
									req.body.team_name	= req.body.team_market	=	req.body.team_id="";
								}
								
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							
								
							})
						}
					
						
					}	
					})
				}
			  res.redirect('/leader/MLB');
			}
      
		});
	});
});

router.get('/leaders_nhl', (req, res) => {
	var response = {};
	Leaders.remove({league:'NHL'}).then((leaderssync) => {
		request('http://api.sportradar.us/nhl/trial/v6/en/seasons/2018/REG/leaders.json?api_key=a7c4he3du9b5c833qpnuks9r', { json: true }, (err, response, body) => {
			if (err) {
				
			  response.status = false;
			  res.status(400).send(JSON.stringify(response));
			}else{
				
				if(typeof body.categories !="undefined"){
					(body.categories).forEach(function(leaders){
						req.body.season	=	body.season.type;
						req.body.league	=	"NHL";
						req.body.categories_name	=	leaders.category;
						req.body.categories_type	=	"";
						var leader_category	=	leaders.category;
						if(typeof leaders.leaders !="undefined"){
							(leaders.leaders).forEach(function(leader){
								req.body.rank	=	leader.rank;
								if(leader_category=="penaltyminutes"){
									req.body.categories_type	=	"penalty_minutes";
									req.body.score	=	leader.penalty_minutes;
								}else if(leader_category=="shorthandedgoals"){
									req.body.categories_type	=	"shorthanded_goals";
									req.body.score	=	leader.shorthanded_goals;
								}else if(leader_category=="goalsagainstaverage"){
									req.body.categories_type	=	"average";
									req.body.score	=	leader.average;
								}else if(leader_category=="wins"){
									req.body.categories_type	=	"wins";
									req.body.score	=	leader.wins;
									req.body.avg_minutes	=	leader.minutes;
									req.body.losses	=	leader.losses;
									req.body.overtime_losses	=	leader.overtime_losses;
								}else if(leader_category=="savepercentage"){
									req.body.categories_type	=	"save_pct";
									req.body.score	=	leader.save_pct;
								}else if(leader_category=="defensivescoring"){
									req.body.categories_type	=	"goals";
									req.body.score	=	leader.goals;
								
								}else if(leader_category=="rookieassists"){
									req.body.categories_type	=	"assists";
									req.body.score	=	leader.assists;
								}else if(leader_category=="goals"){
									req.body.categories_type	=	"goals";
									req.body.score	=	leader.goals;
								}else if(leader_category=="gamewinninggoals"){
									req.body.categories_type	=	"game_winning_goals";
									req.body.score	=	leader.game_winning_goals;
								}else if(leader_category=="shutouts"){
									req.body.categories_type	=	"shutouts";
									req.body.score	=	leader.shutouts;
								}else if(leader_category=="plusminus"){
									req.body.categories_type	=	"plus_minus";
									req.body.score	=	leader.plus_minus;
								}else if(leader_category=="rookiescoring"){
									req.body.categories_type	=	"points";
									req.body.score	=	leader.points;	
								}else if(leader_category=="assists"){
									req.body.categories_type	=	"assists";
									req.body.score	=	leader.assists;
								}else if(leader_category=="shots"){
									req.body.categories_type	=	"shots";
									req.body.score	=	leader.shots;
								}else if(leader_category=="points"){
									req.body.categories_type	=	"points";
									req.body.score	=	leader.points;
								}else if(leader_category=="rookiegoals"){
									req.body.categories_type	=	"goals";
									req.body.score	=	leader.goals;
								}else if(leader_category=="hits"){
									req.body.categories_type	=	"hits";
									req.body.score	=	leader.hits;
								}else if(leader_category=="powerplaygoals"){
									req.body.categories_type	=	"powerplay_goals";
									req.body.score	=	leader.powerplay_goals;
								}
								req.body.player_name	=	leader.player.full_name;
								req.body.player_id	=	leader.player.id;
								req.body.player_pic	=	"";
								req.body.team_market	=	leader.team.market;
								req.body.team_name	=	leader.team.name;
								req.body.games_played	=	leader.games_played;
								var leaders = new Leaders(req.body);
								leaders.save(function(err, leaders) {
									
									
								});
							})
						}
					})
				}
				res.redirect('/leader/NHL');
			}
      
		});
	});
});

router.get('/update_leader_profile_pic',(req,res) =>{
	response	=	{};
	Leaders.find({}, function (err, leaders) {
		(leaders).forEach(function(leaderData){
			body	=	{};

			Players.findOne({title:leaderData.player_name}, function (err, playe) {
				
					body.player_pic=playe;
					Leaders.where({player_name: leaderData.player_name  }).updateMany({player_pic: playe }).exec((err, updateLeader) => {
							console.log(updateLeader);

					});
				

			})
		})

	})
});

router.get('/update_venue_image',(req,res) =>{
	
	response	=	{};
	Score.find({}, function (err, scores) {
		(scores).forEach(function(scoresData){
			body	=	{};
			if(typeof scoresData.venue_id != "undefined"){
				
				Venues.find({venue_id:scoresData.venue_id}, function (err, venue) {
						if(venue.length>0){
							
							if(venue[0]['league'] == "NBA"){
								
								Score.where({venue_id: scoresData.venue_id  }).updateMany({venue_logo: 'https://api.sportradar.us/nba-images-t3/getty'+venue[0]['links'][2]['href']+"?api_key=s9h4vb8krqv55aemuughuufb" }).exec((err, updateLeader) => {
										console.log(updateLeader);

								});
							}else if(venue[0]['league'] == "NFL"){
								Score.where({venue_id: scoresData.venue_id  }).updateMany({venue_logo: 'https://api.sportradar.us/nfl-images-t3/ap'+venue[0]['links'][2]['href']+"?api_key=dvmbpwwn5z53sq3rs6d9u32h" }).exec((err, updateLeader) => {
										console.log(updateLeader);

								});
							}
							
						}
						
					

				})
			}
			
		})

	})
});

router.get('/update_venue',function(req,res, next){


	request('https://api.sportradar.us/nhl-images-t3/usat/venues/manifest.json?api_key=bfw7wd7f29e4rsrntwmgqb2m', { json: true }, (err, response, body) => {
		(body.assetlist).forEach(function(assest) {
			req.body.league	=	"NHL";
			req.body.asset_id	=	assest.id;
			req.body.title		=	assest.title;
			req.body.description		=	assest.description;
			req.body.venue_id		=	assest.venue_id;
			req.body.links	=	assest.links;
			req.body.refs	=	assest.refs;
			var venue = new Venues(req.body);
			venue.save(function(errLog, eventData) {
			
		  
			}); 
			
		})
		
	 });
})
router.get('/update_score_detail/:league',function(req,res,next){
	var  today = new Date();
	var dd = today.getDate();
	var mm = (today.getMonth()); 
	var yyyy = today.getFullYear();
	if(req.params.league=="NHL"){
		var startDate = new Date(yyyy,mm,dd-30);
		
		var endDate = new Date(yyyy,mm,dd);
	}else{
		var startDate = new Date(yyyy,mm,dd);
		var endDate = new Date(yyyy,mm,dd+1);
	}
	
   Score.find({league:req.params.league,created:{$gte:startDate,$lte:endDate}}).sort({created:1}).exec(function (err, scores) {
			//console.log(scores);
		dt.processScoreDetailArray(scores,req.params.league);
		res.redirect('/games/score');

	})   
})
router.get('/update_mlb_score/:league',function(req,res,next){
	Score.find({league:"MLB",status:'closed'}, function (err, scores) {

		dt.processMlbArray(scores,'MLB');
		res.redirect('/games/score');
	
	})
});

router.get('/update_standing_nba',(req,res) =>{
	Standing.remove({league:'NBA'}).then((leaderssync) => {
  request("http://api.sportradar.us/nba/trial/v5/en/seasons/2018/REG/standings.json?api_key=rxnwvw4myu6xd488basdrenn", { json: true }, (err, response, standingBody) => {
      
      req.body.standingData  =  standingBody.conferences;
      req.body.season=standingBody.season.type;
      req.body.league=standingBody.league.name;
      
      var stand = new Standing(req.body);
      stand.save(function(err, scores) {
        if(err){
          console.log(err);
          return false;
        }
        res.redirect('/leader/NBA');
      });
        
  });
  });
});

router.get('/update_standing_nhl',(req,res) =>{
	Standing.remove({league:'NHL'}).then((leaderssync) => {
	  request("http://api.sportradar.us/nhl/trial/v6/en/seasons/2018/REG/standings.json?api_key=a7c4he3du9b5c833qpnuks9r", { json: true }, (err, response, standingBody) => {
		 
		  req.body.standingData  =  standingBody.conferences;
		  req.body.season=standingBody.season.type;
		  req.body.league=standingBody.league.name;
		  
		  var stand = new Standing(req.body);
		  stand.save(function(err, scores) {
			if(err){
			  console.log(err);
			  return false;
			}
			res.redirect('/leader/NHL');
		  });
			
	  });
  });
});
router.get('/update_conference/:league',(req,res) =>{
	if(req.params.league == "NBA"){
		feed_url  =  "http://api.sportradar.us/nba/trial/v5/en/seasons/2018/REG/standings.json?api_key=rxnwvw4myu6xd488basdrenn";
	}else if(req.params.league == "NFL"){
		feed_url  =  "http://api.sportradar.us/nfl/official/trial/v5/en/seasons/2018/standings.json?api_key=cnfswcsaqcvtvs2sxst2s68m";
	}
	Conference.remove({league:req.params.league}).then((conferencedel) => {
		request(feed_url, { json: true }, (err, response, divisionBody) => {
			  
			if (err) {
			  res.redirect('/leader/'+req.params.league);
			}else{
				
				if(typeof divisionBody.conferences !="undefined"){
				  (divisionBody.conferences).forEach(function(conference){

					req.body.season  =  divisionBody.season.type;
					req.body.league  =  req.params.league;
					req.body.conferences_name  =  conference.name;
					req.body.conferences_alias  =  conference.alias;
					req.body.divisions  =  [];
					if(typeof conference.divisions !="undefined"){
					  (conference.divisions).forEach(function(divisions){
						division_body  =  {};
						division_body['id']  =  divisions.id;
						division_body['name']  =  divisions.name;
						division_body['alias']  =  divisions.alias;
						division_body['teams']  =  [];
						if(typeof divisions.teams !="undefined"){
							(divisions.teams).forEach(function(teams){
								diviteamData=  {};
								diviteamData['team_id']  =  teams.id;
								if(req.params.league == "NBA"){
									diviteamData['team_name']  =  teams.market+' '+teams.name;
								}else{
									if(teams.clinched){
										diviteamData['team_name']  =  teams.market+' '+teams.name+'-'+teams.clinched;
									}else{
										diviteamData['team_name']  =  teams.market+' '+teams.name;
									}
									
								}
								
								diviteamData['wins']  =  teams.wins;
								diviteamData['loses']  =  teams.losses;
								diviteamData['win_pct']  =  teams.win_pct;
								diviteamData['pf']  =  teams.points_for;
								diviteamData['pa']  =  teams.points_against;
								
								if(req.params.league == "NBA"){
									diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
								  diviteamData['diff']  =  teams.point_diff;
								  diviteamData['game_behind_c_f']  =  teams.games_behind.conference +'-'+ teams.games_behind.division;
								  diviteamData['strk']  =  teams.streak.kind +' '+ teams.streak.length;
								  if(typeof teams.records !='undefined'){
									(teams.records).forEach(function(confdivirecdata) {
									  if(confdivirecdata.record_type=='home'){
										  diviteamData['home']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='road'){
										  diviteamData['road']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='division'){
										diviteamData['division']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='conference'){
										 diviteamData['conference']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='last_10'){
										  diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='three_points'){
										 diviteamData['three_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='ten_points'){
										  diviteamData['ten_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='over_500'){
										 diviteamData['over_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='below_500'){
										diviteamData['below_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }else if(confdivirecdata.record_type=='overtime'){
										diviteamData['overtime']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
									  }
									})
								  }
								}else{
									diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
								   diviteamData['ties']  =  teams.ties;
								   diviteamData['diff']  =  teams.points_for - teams.points_against;
								   diviteamData['strk']  =  teams.streak.desc;
									if(typeof teams.records !='undefined'){
										(teams.records).forEach(function(confdivirecdata) {
										  if(confdivirecdata.record.category=='home'){
											  diviteamData['home']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
										  }else if(confdivirecdata.record.category=='road'){
											  diviteamData['away']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
										  }else if(confdivirecdata.record.category=='division'){
											diviteamData['division']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
										  }else if(confdivirecdata.record.category=='conference'){
											 diviteamData['conference']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
										  }
										})
									}
								}
								

								 (division_body['teams'] ).push(diviteamData);

							})
						}
						 (req.body.divisions).push(division_body);
					  })
					}

					 var conference = new Conference(req.body);
					conference.save(function(err, conferences) {
					  if(err){
						console.log(err);
						return false;
					  }
					 //
					});
				  });
				   res.redirect('/leader/'+req.params.league);
				}
				
			}
				
		});
	});
  });

router.get('/update_division/:league',(req,res) =>{
  if(req.params.league == "NBA"){
    feed_url  =  "http://api.sportradar.us/nba/trial/v5/en/seasons/2018/REG/standings.json?api_key=rxnwvw4myu6xd488basdrenn";
  }else if(req.params.league == "NFL"){
    feed_url  =  "http://api.sportradar.us/nfl/official/trial/v5/en/seasons/2018/standings.json?api_key=cnfswcsaqcvtvs2sxst2s68m";
  }else if(req.params.league == "MLB"){
    feed_url  =  "http://api.sportradar.us/mlb/trial/v6.5/en/seasons/2019/PRE/standings.json?api_key=3h4d3zjgcw8m53dsxbqphdzk";
  }
  Division.remove({league:req.params.league}).then((divisiondel) => {
  request(feed_url, { json: true }, (err, response, divisionBody) => {
      
    if (err) {
      response.status = false;
      res.status(400).send(JSON.stringify(response));
    }else{
		if(req.params.league == "MLB"){
			console.log(divisionBody.league.season.spring_leagues);
			if(typeof divisionBody.league.season.spring_leagues !="undefined"){
			  (divisionBody.league.season.spring_leagues).forEach(function(sleagues){
				  	req.body.season  =  divisionBody.league.season.type;
					req.body.league  =  req.params.league;
					req.body.conferences_name  =  sleagues.name;
					req.body.conferences_alias  =  sleagues.alias;
					req.body.teams  =  [];
					if(typeof sleagues.teams !="undefined"){
						(sleagues.teams).forEach(function(teams){
							diviteamData=  {};
							diviteamData['team_id']  =  teams.id;
							diviteamData['team_name']  =  teams.market+' '+teams.name;
							diviteamData['wins']  =  teams.win;
							diviteamData['loses']  =  teams.loss;
							diviteamData['win_pct']  =  teams.win_p;
							diviteamData['strk']  =  teams.streak;
							diviteamData['away']  =  teams.away_win+'-'+teams.away_loss;
							diviteamData['last_10']  =  teams.last_10_won+'-'+teams.last_10_lost;
							diviteamData['home']  =  teams.home_win+'-'+teams.home_loss;
							diviteamData['team_logo'] 	=	"/upload/teams/"+dt.mlbnameUnderscore(teams.market+" "+teams.name)+'.png';
						
							(req.body.teams).push(diviteamData);
						})
					}
				var division = new Division(req.body);
				division.save(function(err, divisions) {
				  if(err){
					console.log(err);
					return false;
				  }
				 
				});					
			  });
			   res.redirect('/leader/'+req.params.league);
			}  
		}else{
			if(typeof divisionBody.conferences !="undefined"){
			  (divisionBody.conferences).forEach(function(conference){

				req.body.season  =  divisionBody.season.type;
				req.body.league  =  req.params.league;
				req.body.conferences_name  =  conference.name;
				req.body.conferences_alias  =  conference.alias;
				req.body.teams  =  [];
				if(typeof conference.divisions !="undefined"){
				  (conference.divisions).forEach(function(divisions){
					division_body  =  {};
					if(typeof divisions.teams !="undefined"){
						(divisions.teams).forEach(function(teams){
							diviteamData=  {};
							diviteamData['team_id']  =  teams.id;
							if(req.params.league == "NBA"){
								diviteamData['team_name']  =  teams.market+' '+teams.name;
							}else{
								if(teams.clinched){
									diviteamData['team_name']  =  teams.market+' '+teams.name+'-'+teams.clinched;
								}else{
									diviteamData['team_name']  =  teams.market+' '+teams.name;
								}
							}
							//diviteamData['team_name']  =  teams.market+' '+teams.name;
							diviteamData['wins']  =  teams.wins;
							diviteamData['loses']  =  teams.losses;
							diviteamData['win_pct']  =  teams.win_pct;
							diviteamData['pf']  =  teams.points_for;
							diviteamData['pa']  =  teams.points_against;
							if(req.params.league == "NBA"){
								diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
							  diviteamData['diff']  =  teams.point_diff;
							  diviteamData['game_behind_c_f']  =  teams.games_behind.conference +'-'+ teams.games_behind.division;
							  diviteamData['strk']  =  teams.streak.kind +' '+ teams.streak.length;
							  if(typeof teams.records !='undefined'){
								(teams.records).forEach(function(confdivirecdata) {
								  if(confdivirecdata.record_type=='home'){
									  diviteamData['home']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='road'){
									  diviteamData['road']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='division'){
									diviteamData['division']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='conference'){
									 diviteamData['conference']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='last_10'){
									  diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='three_points'){
									 diviteamData['three_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='ten_points'){
									  diviteamData['ten_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='over_500'){
									 diviteamData['over_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='below_500'){
									diviteamData['below_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='overtime'){
									diviteamData['overtime']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }
								})
							  }
							}else{
								diviteamData['ties']  =  teams.ties;
								diviteamData['diff']  =  teams.points_for - teams.points_against;
								diviteamData['strk']  =  teams.streak.desc;
								diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
								if(typeof teams.records !='undefined'){
									(teams.records).forEach(function(confdivirecdata) {
									  if(confdivirecdata.record.category=='home'){
										  diviteamData['home']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }else if(confdivirecdata.record.category=='road'){
										  diviteamData['away']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }else if(confdivirecdata.record.category=='division'){
										diviteamData['division']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }else if(confdivirecdata.record.category=='conference'){
										 diviteamData['conference']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }
									})
								}
							}
							

							(req.body.teams).push(diviteamData);

						})
					}
					 
				  })
				}
				
				 var division = new Division(req.body);
				division.save(function(err, divisions) {
				  if(err){
					console.log(err);
					return false;
				  }
				  
				});
			  });
			  res.redirect('/leader/'+req.params.league);
			}
		}	
    }
        
  });
  });
});

module.exports = router;