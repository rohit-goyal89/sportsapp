var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment'),
	Game = require('../models/game'),
	Score = require('../models/score'),
	FUNC = require('../lib/function'),
	async = require('async'),
	ScoreDrives = require('../models/score_drives');
	Leaders = require('../models/leaders');
	PlayerImage = require('../models/playerimage');
	Division = require('../models/division');
	Venues = require('../models/venue');
var formidable = require('formidable');
var fs = require('fs');	
var download = require('image-downloader');
var mongoose = require('mongoose');
var dt = require('../lib/function');
const waitFor = (ms) => new Promise(r => setTimeout(r, ms));
router.get('/getplayer', (req, res) => {
  var assetlist = [
    {
      "id": "f4714170-b466-4949-ade2-31d9a1405bf5",
      "created": "2018-11-07T21:11:20+00:00",
      "updated": "2019-03-05T20:50:22+00:00",
      "title": "Antti Suomela",
      "description": "Oct 20, 2018; San Jose, CA, USA; San Jose Sharks center Antti Suomela (40) controls the puck against the New York Islanders during the second period at SAP Center at San Jose. Mandatory Credit: Neville E. Guard-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/f4714170-b466-4949-ade2-31d9a1405bf5/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "San Jose Sharks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44155909-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44155909-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44155909-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3696",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "28",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "6ee1bfad-c999-4896-a579-4e52e2aa26b7",
      "created": "2018-11-07T21:11:30+00:00",
      "updated": "2018-11-09T02:29:53+00:00",
      "title": "Casey Mittelstadt",
      "description": "NHL: Buffalo Sabres at San Jose Sharks",
      "player_id": "b82e05ea-3df0-4085-88a3-bcc7c1efec83",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/6ee1bfad-c999-4896-a579-4e52e2aa26b7/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Mittelstadt, Casey",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "b82e05ea-3df0-4085-88a3-bcc7c1efec83",
          "sportradar_id": "b82e05ea-3df0-4085-88a3-bcc7c1efec83",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "b82e05ea-3df0-4085-88a3-bcc7c1efec83",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1117335",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479999",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Buffalo Sabres",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416d559-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3678",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "7",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "0bddb958-b979-4764-a9ff-6010c3fe87ec",
      "created": "2018-11-07T21:12:08+00:00",
      "updated": "2019-03-05T20:44:01+00:00",
      "title": "Jesperi Kotkaniemi",
      "description": "NHL: Preseason-Toronto Maple Leafs at Montreal Canadiens",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/0bddb958-b979-4764-a9ff-6010c3fe87ec/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Montreal Canadiens",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441713b7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3690",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "2a7622e0-3faf-4916-a5fc-dcf13458740b",
      "created": "2018-11-07T21:12:01+00:00",
      "updated": "2018-11-09T02:34:11+00:00",
      "title": "Dennis Cholowski",
      "description": "NHL: Columbus Blue Jackets at Detroit Red Wings",
      "player_id": "80722ea0-7df7-4213-9e98-0ec5de853586",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/2a7622e0-3faf-4916-a5fc-dcf13458740b/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Cholowski, Dennis",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "80722ea0-7df7-4213-9e98-0ec5de853586",
          "sportradar_id": "80722ea0-7df7-4213-9e98-0ec5de853586",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "80722ea0-7df7-4213-9e98-0ec5de853586",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:983635",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479395",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Detroit Red Wings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44169bb9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3685",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "17",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e55f18f8-cca8-4603-9f93-1d15a803e243",
      "created": "2018-11-07T21:11:40+00:00",
      "updated": "2019-03-05T20:45:47+00:00",
      "title": "Andrei Svechnikov",
      "description": "NHL: Vancouver Canucks at Carolina Hurricanes",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/e55f18f8-cca8-4603-9f93-1d15a803e243/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Carolina Hurricanes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44182a9d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3680",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "12",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "d647ca1e-71e0-4b27-8754-adf8cc73e859",
      "created": "2018-11-07T21:12:18+00:00",
      "updated": "2019-03-05T20:43:21+00:00",
      "title": "Filip Zadina",
      "description": "NHL: Preseason-Detroit Red Wings at Pittsburgh Penguins",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/d647ca1e-71e0-4b27-8754-adf8cc73e859/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Detroit Red Wings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44169bb9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3685",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "17",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "b29214f2-a9bf-4dec-9f38-b708fa045b2d",
      "created": "2018-11-07T21:11:20+00:00",
      "updated": "2018-11-09T02:28:17+00:00",
      "title": "Mike Hoffman",
      "description": "NHL: Florida Panthers at Washington Capitals",
      "player_id": "42f715ab-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/b29214f2-a9bf-4dec-9f38-b708fa045b2d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Hoffman, Mike",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "42f715ab-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "42f715ab-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "42f715ab-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:755494",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8474884",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Florida Panthers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4418464d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3687",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "13",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "6c5f3a8c-aa98-466b-91e7-273abc751ab2",
      "created": "2018-11-07T21:12:28+00:00",
      "updated": "2019-03-05T20:42:46+00:00",
      "title": "Rasmus Dahlin",
      "description": "NHL: Preseason-Toronto Maple Leafs at Buffalo Sabres",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/6c5f3a8c-aa98-466b-91e7-273abc751ab2/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Buffalo Sabres",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416d559-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3678",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "7",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "7843b4b1-7bfb-4e91-ad5e-1a3046a943f7",
      "created": "2018-11-07T21:11:49+00:00",
      "updated": "2018-11-09T02:31:18+00:00",
      "title": "Elias Pettersson",
      "description": "NHL: Vancouver Canucks at Carolina Hurricanes",
      "player_id": "04396c28-a071-478a-b387-a456fac24415",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/7843b4b1-7bfb-4e91-ad5e-1a3046a943f7/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Pettersson, Elias",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "04396c28-a071-478a-b387-a456fac24415",
          "sportradar_id": "04396c28-a071-478a-b387-a456fac24415",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "04396c28-a071-478a-b387-a456fac24415",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:932824",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480012",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Vancouver Canucks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415b0a7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3692",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "23",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "b8a3c1ce-a641-4055-b281-c51c1fd9d5ca",
      "created": "2018-11-07T21:11:18+00:00",
      "updated": "2018-11-09T02:27:04+00:00",
      "title": "Dominik Simon",
      "description": "Oct 23, 2018; Edmonton, Alberta, CAN; Pittsburgh Penguins forward Dominik Simon (12) skates against the Edmonton Oilers at Rogers Place. Mandatory Credit: Perry Nelson-USA TODAY Sports",
      "player_id": "67187244-e17c-4bb9-bf9e-820d10a35878",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/b8a3c1ce-a641-4055-b281-c51c1fd9d5ca/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Simon, Dominik",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "67187244-e17c-4bb9-bf9e-820d10a35878",
          "sportradar_id": "67187244-e17c-4bb9-bf9e-820d10a35878",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "67187244-e17c-4bb9-bf9e-820d10a35878",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:266317",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478866",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Pittsburgh Penguins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417b7d7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3697",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "5",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "3a682de0-d24b-41dc-af3a-baa4c830b0da",
      "created": "2018-11-07T21:11:59+00:00",
      "updated": "2018-11-09T02:32:52+00:00",
      "title": "Ryan Donato",
      "description": "Oct 4, 2018; Buffalo, NY, USA; Boston Bruins center Ryan Donato (17) during the third period against the Buffalo Sabres at KeyBank Center. Mandatory Credit: Timothy T. Ludwig-USA TODAY Sports",
      "player_id": "69b35311-8876-4c70-9873-c4ad0abb4401",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/3a682de0-d24b-41dc-af3a-baa4c830b0da/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Donato, Ryan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "69b35311-8876-4c70-9873-c4ad0abb4401",
          "sportradar_id": "69b35311-8876-4c70-9873-c4ad0abb4401",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "69b35311-8876-4c70-9873-c4ad0abb4401",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1215358",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477987",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Boston Bruins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416ba1a-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416ba1a-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416ba1a-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3677",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "6",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8188fb37-0b12-4493-bb21-1dec852bcb11",
      "created": "2018-11-07T21:12:38+00:00",
      "updated": "2019-03-05T20:42:04+00:00",
      "title": "Ilya Kovalchuk",
      "description": "NHL: Preseason-Arizona Coyotes at Los Angeles Kings",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8188fb37-0b12-4493-bb21-1dec852bcb11/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Los Angeles Kings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44151f7a-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3688",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "26",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8d8d2cea-9918-469e-a4d7-cf28c1ec0995",
      "created": "2018-11-13T18:52:03+00:00",
      "updated": "2018-11-14T01:08:02+00:00",
      "title": "Ben Bishop",
      "description": "NHL: Nashville Predators at Dallas Stars",
      "player_id": "42d6380f-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8d8d2cea-9918-469e-a4d7-cf28c1ec0995/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Bishop, Ben",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "42d6380f-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "42d6380f-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "42d6380f-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:115640",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8471750",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Dallas Stars",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44157522-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44157522-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44157522-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3684",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "25",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "469bc03b-5bc9-45e9-ae26-84f4370de99d",
      "created": "2018-12-13T21:24:54+00:00",
      "updated": "2018-12-13T21:40:29+00:00",
      "title": "Erik Karlsson",
      "description": "NHL: San Jose Sharks at Dallas Stars",
      "player_id": "42fa3dcd-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/469bc03b-5bc9-45e9-ae26-84f4370de99d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Karlsson, Erik",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "048b882f-3000-45ba-ba46-458f332c138e",
          "sportradar_id": "42fa3dcd-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "42fa3dcd-0f24-11e2-8525-18a905767e44",
              "sport": "nhl",
              "alt_id": "048b882f-3000-45ba-ba46-458f332c138e"
            },
            {
              "origin": "NHL",
              "id": "8476973",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "San Jose Sharks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44155909-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44155909-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44155909-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3696",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "28",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e85d94cb-e788-4a89-87f1-e5ee45952951",
      "created": "2019-02-27T15:17:40+00:00",
      "updated": "2019-02-27T15:33:22+00:00",
      "title": "Mikhail Sergachev",
      "description": "NHL: Tampa Bay Lightning at Buffalo Sabres",
      "player_id": "a82f9092-8190-45da-aba6-0d19cad1ed83",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/e85d94cb-e788-4a89-87f1-e5ee45952951/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Sergachev, Mikhail",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "a82f9092-8190-45da-aba6-0d19cad1ed83",
          "sportradar_id": "a82f9092-8190-45da-aba6-0d19cad1ed83",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "a82f9092-8190-45da-aba6-0d19cad1ed83",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:983675",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479410",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Tampa Bay Lightning",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417d3cb-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3694",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "14",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "bded947c-0393-4fa4-8dcf-12ee6770d016",
      "created": "2019-02-27T15:17:02+00:00",
      "updated": "2019-02-27T15:27:39+00:00",
      "title": "Nathan MacKinnon",
      "description": "NHL: Colorado Avalanche at Tampa Bay Lightning",
      "player_id": "e440e013-e817-11e2-a133-f4ce4684ea4c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/bded947c-0393-4fa4-8dcf-12ee6770d016/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "MacKinnon, Nathan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "e440e013-e817-11e2-a133-f4ce4684ea4c",
          "sportradar_id": "e440e013-e817-11e2-a133-f4ce4684ea4c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "e440e013-e817-11e2-a133-f4ce4684ea4c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:353770",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477492",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Colorado Avalanche",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ce44-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3682",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "21",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4",
      "created": "2019-02-27T15:18:00+00:00",
      "updated": "2019-02-27T23:24:23+00:00",
      "title": "Jacob Trouba",
      "description": "NHL: Winnipeg Jets at Toronto Maple Leafs",
      "player_id": "7482727f-ab9f-11e2-a01b-f4ce4684ea4c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/078a9ef8-1fa8-4ff2-86c6-e713cc4ddad4/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Trouba, Jacob",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "7482727f-ab9f-11e2-a01b-f4ce4684ea4c",
          "sportradar_id": "7482727f-ab9f-11e2-a01b-f4ce4684ea4c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "7482727f-ab9f-11e2-a01b-f4ce4684ea4c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:326125",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476885",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Winnipeg Jets",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44180e55-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44180e55-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44180e55-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3676",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "52",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "879dbbb9-bc7b-49a1-8b41-77349dfebf4e",
      "created": "2019-02-27T15:17:12+00:00",
      "updated": "2019-02-27T15:30:17+00:00",
      "title": "Dylan Strome",
      "description": "NHL: Calgary Flames at Chicago Blackhawks",
      "player_id": "818e24b7-32ae-43c8-b7d1-33ec285ae530",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/879dbbb9-bc7b-49a1-8b41-77349dfebf4e/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Strome, Dylan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "818e24b7-32ae-43c8-b7d1-33ec285ae530",
          "sportradar_id": "818e24b7-32ae-43c8-b7d1-33ec285ae530",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "818e24b7-32ae-43c8-b7d1-33ec285ae530",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:852998",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478440",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Chicago Blackhawks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416272f-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3681",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "16",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "b319b497-f5ad-44e1-8b9c-067ad7b11a3f",
      "created": "2019-02-27T15:18:05+00:00",
      "updated": "2019-02-27T23:25:39+00:00",
      "title": "Josh Anderson",
      "description": "NHL: Chicago Blackhawks at Columbus Blue Jackets",
      "player_id": "176ff74a-1206-49c3-8815-20df861b8ffb",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/b319b497-f5ad-44e1-8b9c-067ad7b11a3f/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Anderson, Josh",
          "type": "profile",
          "sport": "NHL",
          "sportsdata_id": "176ff74a-1206-49c3-8815-20df861b8ffb",
          "sportradar_id": "176ff74a-1206-49c3-8815-20df861b8ffb",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "176ff74a-1206-49c3-8815-20df861b8ffb",
              "sport": "NHL"
            },
            {
              "origin": "SR",
              "id": "sr:player:352190",
              "sport": "NHL"
            },
            {
              "origin": "NHL",
              "id": "8476981",
              "sport": "NHL"
            }
          ]
        },
        {
          "name": "Columbus Blue Jackets",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44167db4-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44167db4-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44167db4-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3683",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "29",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a823a7f2-d40c-45f8-8a46-9f3dcff6f476",
      "created": "2019-02-27T15:17:49+00:00",
      "updated": "2019-03-05T15:46:34+00:00",
      "title": "Pontus Aberg",
      "description": "Nov 9, 2018; Anaheim, CA, USA; Anaheim Ducks left wing Pontus Aberg (20) is congratulated after scoring a second period goal against the Minnesota Wild at Honda Center. Mandatory Credit: Jake Roth-USA TODAY Sports",
      "player_id": "e48cf365-5bde-4268-b13f-17ea80f02e82",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a823a7f2-d40c-45f8-8a46-9f3dcff6f476/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Aberg, Pontus",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "e48cf365-5bde-4268-b13f-17ea80f02e82",
          "sportradar_id": "e48cf365-5bde-4268-b13f-17ea80f02e82",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "e48cf365-5bde-4268-b13f-17ea80f02e82",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:179063",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476857",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Anaheim Ducks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441862de-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441862de-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441862de-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3675",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "24",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9",
      "created": "2019-02-27T15:17:03+00:00",
      "updated": "2019-02-27T15:29:08+00:00",
      "title": "Sidney Crosby",
      "description": "NHL: Pittsburgh Penguins at Ottawa Senators",
      "player_id": "433de553-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/5ffa4bb5-e809-4a4f-a229-1eee3a6d53b9/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Crosby, Sidney",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "433de553-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "433de553-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "433de553-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:31007",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8471675",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Pittsburgh Penguins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417b7d7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3697",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "5",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "77e4ceea-471c-477b-9a2e-c64f586818ac",
      "created": "2019-02-27T15:17:38+00:00",
      "updated": "2019-03-05T15:49:59+00:00",
      "title": "Oskar Lindblom",
      "description": "Nov 15, 2018; Philadelphia, PA, USA; Philadelphia Flyers left wing Oskar Lindblom (23) against the New Jersey Devils during the second period at Wells Fargo Center. Mandatory Credit: Eric Hartline-USA TODAY Sports",
      "player_id": "ca346915-364d-4c60-abb0-70fd4b3e44e8",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/77e4ceea-471c-477b-9a2e-c64f586818ac/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Lindblom, Oskar",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "ca346915-364d-4c60-abb0-70fd4b3e44e8",
          "sportradar_id": "ca346915-364d-4c60-abb0-70fd4b3e44e8",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "ca346915-364d-4c60-abb0-70fd4b3e44e8",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:600002",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478067",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Philadelphia Flyers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44179d47-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44179d47-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44179d47-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3699",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "4",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "64d0ce76-12cc-4dfb-918e-38c8f4848d88",
      "created": "2019-02-27T15:17:43+00:00",
      "updated": "2019-03-05T15:48:48+00:00",
      "title": "Egor Yakovlev",
      "description": "Nov 11, 2018; Winnipeg, Manitoba, CAN;  New Jersey Devils defenseman Egor Yakovlev (74) skates past fans in warm up prior to tonight's game against Winnipeg Jets at Bell MTS Place. Mandatory Credit: James Carey Lauder-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/64d0ce76-12cc-4dfb-918e-38c8f4848d88/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "New Jersey Devils",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44174b0c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3704",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "1",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "162e67a2-de38-478f-bd12-0196e2e285ef",
      "created": "2019-02-27T15:17:58+00:00",
      "updated": "2019-02-27T23:23:49+00:00",
      "title": "Tim Schaller",
      "description": "NHL: Pittsburgh Penguins at Vancouver Canucks",
      "player_id": "6a49255f-af25-40a9-9216-e1053fdfd6c8",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/162e67a2-de38-478f-bd12-0196e2e285ef/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Schaller, Tim",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "6a49255f-af25-40a9-9216-e1053fdfd6c8",
          "sportradar_id": "6a49255f-af25-40a9-9216-e1053fdfd6c8",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "6a49255f-af25-40a9-9216-e1053fdfd6c8",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:780360",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477213",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Vancouver Canucks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415b0a7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3692",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "23",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "7922878a-bade-4f69-acce-0b5cfd19f2c8",
      "created": "2019-02-27T15:17:35+00:00",
      "updated": "2019-02-27T15:32:44+00:00",
      "title": "Lias Andersson",
      "description": "NHL: Dallas Stars at New York Rangers",
      "player_id": "2d04d563-2327-4a12-af6c-309941d732ad",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/7922878a-bade-4f69-acce-0b5cfd19f2c8/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Andersson, Lias",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "2d04d563-2327-4a12-af6c-309941d732ad",
          "sportradar_id": "2d04d563-2327-4a12-af6c-309941d732ad",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "2d04d563-2327-4a12-af6c-309941d732ad",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1021989",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480072",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New York Rangers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441781b9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3701",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "3",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "4a945ec1-8bb1-4cca-a83e-d1eb2e679013",
      "created": "2019-02-27T15:17:24+00:00",
      "updated": "2019-02-27T15:31:53+00:00",
      "title": "Jacob Markstrom",
      "description": "NHL: Vancouver Canucks at Los Angeles Kings",
      "player_id": "43690e31-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/4a945ec1-8bb1-4cca-a83e-d1eb2e679013/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Markstrom, Jacob",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "43690e31-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "43690e31-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "43690e31-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:42478",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8474593",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Los Angeles Kings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44151f7a-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3688",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "26",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "d83cff85-68ca-4102-a380-05aa1c927b5c",
      "created": "2019-02-27T15:17:39+00:00",
      "updated": "2019-03-05T15:49:25+00:00",
      "title": "Joey Anderson",
      "description": "Nov 15, 2018; Philadelphia, PA, USA; New Jersey Devils right wing Joey Anderson (49) celebrates with teammates after scoring a goal against the Philadelphia Flyers during the first period at Wells Fargo Center. Mandatory Credit: Eric Hartline-USA TODAY Sports",
      "player_id": "e886da56-dd59-41f4-8388-6952d4129fbc",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/d83cff85-68ca-4102-a380-05aa1c927b5c/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Anderson, Joey",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "e886da56-dd59-41f4-8388-6952d4129fbc",
          "sportradar_id": "e886da56-dd59-41f4-8388-6952d4129fbc",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "e886da56-dd59-41f4-8388-6952d4129fbc",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:983659",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479315",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New Jersey Devils",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44174b0c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3704",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "1",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "05655f12-826e-42c6-8270-c12e8be84da2",
      "created": "2019-02-27T15:17:54+00:00",
      "updated": "2019-02-27T23:22:22+00:00",
      "title": "Noah Juulsen",
      "description": "NHL: Tampa Bay Lightning at Montreal Canadiens",
      "player_id": "d70eca80-fe30-493a-be08-c8e242a9d87d",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/05655f12-826e-42c6-8270-c12e8be84da2/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Juulsen, Noah",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "d70eca80-fe30-493a-be08-c8e242a9d87d",
          "sportradar_id": "d70eca80-fe30-493a-be08-c8e242a9d87d",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "d70eca80-fe30-493a-be08-c8e242a9d87d",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:852946",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478454",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Montreal Canadiens",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441713b7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3690",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "bbbd5391-7bc9-4421-88b2-cfa9f8c65c89",
      "created": "2019-02-27T15:18:15+00:00",
      "updated": "2019-03-05T15:35:30+00:00",
      "title": "Igor Ozhiganov",
      "description": "Oct 9, 2018; Dallas, TX, USA; Toronto Maple Leafs defenseman Igor Ozhiganov (92) in action during the game between the Maple Leafs and the Stars at the American Airlines Center. Mandatory Credit: Jerome Miron-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/bbbd5391-7bc9-4421-88b2-cfa9f8c65c89/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Toronto Maple Leafs",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441730a9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3693",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "10",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "417f5796-aa9f-4941-af74-4ec176f0f954",
      "created": "2019-02-27T15:18:19+00:00",
      "updated": "2019-02-27T23:26:45+00:00",
      "title": "Filip Chytil",
      "description": "NHL: New York Rangers at Carolina Hurricanes",
      "player_id": "b428aa9b-d2dd-461f-9606-51ed00e1e165",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/417f5796-aa9f-4941-af74-4ec176f0f954/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Chytil, Filip",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "b428aa9b-d2dd-461f-9606-51ed00e1e165",
          "sportradar_id": "b428aa9b-d2dd-461f-9606-51ed00e1e165",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "b428aa9b-d2dd-461f-9606-51ed00e1e165",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1069434",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480078",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New York Rangers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441781b9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3701",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "3",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a506edb7-9b76-4abe-96d7-1efae259b5ef",
      "created": "2019-02-27T15:18:02+00:00",
      "updated": "2019-03-05T15:42:18+00:00",
      "title": "Juho Lammikko",
      "description": "Oct 24, 2018; Brooklyn, NY, USA; Florida Panthers right wing Juho Lammikko (91) plays the puck against the New York Islanders during the first period at Barclays Center. Mandatory Credit: Brad Penner-USA TODAY Sports",
      "player_id": "3465d1b0-9d0d-479f-9514-f7a6ceab2c2b",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a506edb7-9b76-4abe-96d7-1efae259b5ef/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Lammikko, Juho",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "3465d1b0-9d0d-479f-9514-f7a6ceab2c2b",
          "sportradar_id": "3465d1b0-9d0d-479f-9514-f7a6ceab2c2b",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "3465d1b0-9d0d-479f-9514-f7a6ceab2c2b",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Florida Panthers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4418464d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3687",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "13",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8e83e33d-e2eb-4b2a-ab13-1c906074a098",
      "created": "2019-02-27T15:18:03+00:00",
      "updated": "2019-02-27T23:24:52+00:00",
      "title": "Brett Howden",
      "description": "NHL: Calgary Flames at New York Rangers",
      "player_id": "90742eb3-6cba-4ca3-9368-7dc1861e1992",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8e83e33d-e2eb-4b2a-ab13-1c906074a098/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Howden, Brett",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "90742eb3-6cba-4ca3-9368-7dc1861e1992",
          "sportradar_id": "90742eb3-6cba-4ca3-9368-7dc1861e1992",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "90742eb3-6cba-4ca3-9368-7dc1861e1992",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:983727",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479353",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New York Rangers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441781b9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3701",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "3",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "bbd53f08-582f-40b5-8065-795974fefa92",
      "created": "2019-02-27T15:17:52+00:00",
      "updated": "2019-03-05T15:45:24+00:00",
      "title": "Mathieu Joseph",
      "description": "Nov 6, 2018; Tampa, FL, USA; Tampa Bay Lightning right wing Mathieu Joseph (7) skates with the puck during the first period at Amalie Arena. Mandatory Credit: Kim Klement-USA TODAY Sports",
      "player_id": "c6e9aa17-b9da-4671-b802-168bd6386d14",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/bbd53f08-582f-40b5-8065-795974fefa92/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Joseph, Mathieu",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c6e9aa17-b9da-4671-b802-168bd6386d14",
          "sportradar_id": "c6e9aa17-b9da-4671-b802-168bd6386d14",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c6e9aa17-b9da-4671-b802-168bd6386d14",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:904068",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478472",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Tampa Bay Lightning",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417d3cb-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3694",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "14",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "ac1bf16e-3505-4ab1-b537-4432a3aa2769",
      "created": "2019-02-27T15:17:23+00:00",
      "updated": "2019-02-27T15:31:30+00:00",
      "title": "Travis Boyd",
      "description": "NHL: Washington Capitals at New York Islanders",
      "player_id": "e8ac699d-9b5f-4893-9a48-a4ae0f06bcd2",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/ac1bf16e-3505-4ab1-b537-4432a3aa2769/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Boyd, Travis",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "e8ac699d-9b5f-4893-9a48-a4ae0f06bcd2",
          "sportradar_id": "e8ac699d-9b5f-4893-9a48-a4ae0f06bcd2",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "e8ac699d-9b5f-4893-9a48-a4ae0f06bcd2",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1056663",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476329",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Washington Capitals",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417eede-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417eede-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417eede-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3691",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "15",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "08cc2a43-06e9-4114-8b0c-450c7565e300",
      "created": "2019-02-27T15:18:24+00:00",
      "updated": "2019-03-05T15:32:14+00:00",
      "title": "Filip Hronek",
      "description": "Sep 28, 2018; Toronto, Ontario, CAN; Detroit Red Wings defenceman Filip Hronek (17) passes the puck against the Toronto Maple Leafs at Scotiabank Arena. Toronto defeated Detroit. Mandatory Credit: John E. Sokolowski-USA TODAY Sports",
      "player_id": "e8601527-1eaa-4a87-bcb3-3ad9a3a2a5d7",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/08cc2a43-06e9-4114-8b0c-450c7565e300/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Hronek, Filip",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "e8601527-1eaa-4a87-bcb3-3ad9a3a2a5d7",
          "sportradar_id": "e8601527-1eaa-4a87-bcb3-3ad9a3a2a5d7",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "e8601527-1eaa-4a87-bcb3-3ad9a3a2a5d7",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:940388",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479425",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Detroit Red Wings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44169bb9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3685",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "17",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "91886b65-b87b-43f6-b66f-a9b583fe7a7e",
      "created": "2019-02-27T15:17:08+00:00",
      "updated": "2019-03-05T20:18:12+00:00",
      "title": "Josh Mahura",
      "description": "December 5, 2018; Anaheim, CA, USA; Chicago Blackhawks left wing  moves the puck ahead of Anaheim Ducks defenseman Josh Mahura (76) during the first period at Honda Center. Mandatory Credit: Gary A. Vasquez-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/91886b65-b87b-43f6-b66f-a9b583fe7a7e/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Anaheim Ducks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441862de-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441862de-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441862de-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3675",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "24",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "ae9bad39-87df-4b51-8841-fe8da0b8526b",
      "created": "2019-02-27T15:18:25+00:00",
      "updated": "2019-03-05T15:31:32+00:00",
      "title": "Oliver Kylington",
      "description": "Sep 25, 2018; Calgary, Alberta, CAN; Calgary Flames defenseman Oliver Kylington (58) during the warmup period against the San Jose Sharks at Scotiabank Saddledome. Mandatory Credit: Sergei Belski-USA TODAY Sports",
      "player_id": "bbea6f9a-bd8e-4c26-a77b-8f87d60777a4",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/ae9bad39-87df-4b51-8841-fe8da0b8526b/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Kylington, Oliver",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "bbea6f9a-bd8e-4c26-a77b-8f87d60777a4",
          "sportradar_id": "bbea6f9a-bd8e-4c26-a77b-8f87d60777a4",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "bbea6f9a-bd8e-4c26-a77b-8f87d60777a4",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:351046",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478430",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Calgary Flames",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44159241-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44159241-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44159241-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3679",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "20",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "70b1b550-1eb1-4628-857b-f164be12153f",
      "created": "2019-02-27T15:17:06+00:00",
      "updated": "2019-03-05T20:19:21+00:00",
      "title": "Marcus Pettersson",
      "description": "Dec 6, 2018; Pittsburgh, PA, USA;  Pittsburgh Penguins defenseman Marcus Pettersson (28) moves the puck in third period against the New York Islanders at PPG PAINTS Arena. Mandatory Credit: Philip G. Pavely-USA TODAY Sports",
      "player_id": "9df75668-3fa7-4153-b7e4-2ae8787d42a9",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/70b1b550-1eb1-4628-857b-f164be12153f/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Pettersson, Marcus",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "9df75668-3fa7-4153-b7e4-2ae8787d42a9",
          "sportradar_id": "9df75668-3fa7-4153-b7e4-2ae8787d42a9",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "9df75668-3fa7-4153-b7e4-2ae8787d42a9",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:600682",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477969",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Pittsburgh Penguins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417b7d7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3697",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "5",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "34fce89e-1c35-4a89-b786-5858b7ec08eb",
      "created": "2019-02-27T15:17:34+00:00",
      "updated": "2019-03-05T15:51:37+00:00",
      "title": "Drake Batherson",
      "description": "Nov 21, 2018; Saint Paul, MN, USA; Ottawa Senators right wing Drake Batherson (79) and Minnesota Wild defenseman look for the puck during the first period at Xcel Energy Center. Mandatory Credit: Harrison Barden-USA TODAY Sports",
      "player_id": "c0cdd4d3-bd68-4413-8050-11a0e7f08d78",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/34fce89e-1c35-4a89-b786-5858b7ec08eb/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Batherson, Drake",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c0cdd4d3-bd68-4413-8050-11a0e7f08d78",
          "sportradar_id": "c0cdd4d3-bd68-4413-8050-11a0e7f08d78",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c0cdd4d3-bd68-4413-8050-11a0e7f08d78",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1144858",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480208",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Ottawa Senators",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416f5e2-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3700",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "9",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "536f0184-ea8d-4102-b5e2-666a4a5cd244",
      "created": "2019-02-27T15:17:11+00:00",
      "updated": "2019-03-05T20:16:45+00:00",
      "title": "Lukas Radil",
      "description": "Dec 2, 2018; Montreal, Quebec, CAN; San Jose Sharks center Lukas Radil (52) during the warm-up session before the game against Montreal Canadiens at Bell Centre. Mandatory Credit: Jean-Yves Ahern-USA TODAY Sports\r",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/536f0184-ea8d-4102-b5e2-666a4a5cd244/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "San Jose Sharks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44155909-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44155909-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44155909-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3696",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "28",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a0316221-1d61-4775-865b-d36b4bb61561",
      "created": "2019-02-27T15:17:29+00:00",
      "updated": "2019-03-05T20:10:14+00:00",
      "title": "Adam Gaudette",
      "description": "Nov 23, 2018; San Jose, CA, USA; Vancouver Canucks center Adam Gaudette (88) walks out of the locker room on the way to the ice before the game against the San Jose Sharks at SAP Center at San Jose. Mandatory Credit: Darren Yamashita-USA TODAY Sports",
      "player_id": "acd584ef-bc4d-4a65-b2e0-e7b468939d67",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a0316221-1d61-4775-865b-d36b4bb61561/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Gaudette, Adam",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "acd584ef-bc4d-4a65-b2e0-e7b468939d67",
          "sportradar_id": "acd584ef-bc4d-4a65-b2e0-e7b468939d67",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "acd584ef-bc4d-4a65-b2e0-e7b468939d67",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1213022",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478874",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Vancouver Canucks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415b0a7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3692",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "23",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "40c25e82-37fb-441d-96f0-786b3c703c59",
      "created": "2019-02-27T15:18:16+00:00",
      "updated": "2019-02-27T23:26:23+00:00",
      "title": "Frederik Gauthier",
      "description": "NHL: Toronto Maple Leafs at Dallas Stars",
      "player_id": "1e7d8329-a5db-4c98-80b9-8de4041079e8",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/40c25e82-37fb-441d-96f0-786b3c703c59/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Gauthier, Frederik",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "1e7d8329-a5db-4c98-80b9-8de4041079e8",
          "sportradar_id": "1e7d8329-a5db-4c98-80b9-8de4041079e8",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "1e7d8329-a5db-4c98-80b9-8de4041079e8",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:351828",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477512",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Toronto Maple Leafs",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441730a9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3693",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "10",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "9b570db2-6c25-4c03-9f1c-003c8b817deb",
      "created": "2019-02-27T15:18:17+00:00",
      "updated": "2019-03-05T15:34:52+00:00",
      "title": "Christoffer Ehn",
      "description": "October 8, 2018; Anaheim, CA, USA; Detroit Red Wings center Christoffer Ehn (70) moves the puck against the Anaheim Ducks during the first period at Honda Center. Mandatory Credit: Gary A. Vasquez-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/9b570db2-6c25-4c03-9f1c-003c8b817deb/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Detroit Red Wings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44169bb9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3685",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "17",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "3050cd14-3eb4-4017-82d6-946c7966dde1",
      "created": "2019-02-27T15:18:14+00:00",
      "updated": "2019-03-05T15:36:03+00:00",
      "title": "Paul LaDue",
      "description": "Oct 13, 2018; Ottawa, Ontario, CAN; Los Angeles Kings defenseman Paul LaDue (2) shoots the puck in the third period against the Ottawa Senators at Canadian Tire Centre. Mandatory Credit: Marc DesRosiers-USA TODAY Sports",
      "player_id": "a0fd1d04-9f32-4ae8-b18a-e3606db6d79a",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/3050cd14-3eb4-4017-82d6-946c7966dde1/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "LaDue, Paul",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "a0fd1d04-9f32-4ae8-b18a-e3606db6d79a",
          "sportradar_id": "a0fd1d04-9f32-4ae8-b18a-e3606db6d79a",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "a0fd1d04-9f32-4ae8-b18a-e3606db6d79a",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Los Angeles Kings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44151f7a-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3688",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "26",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "fcd22f17-dcc3-4f39-8dc0-f60df419ec62",
      "created": "2019-02-27T15:17:36+00:00",
      "updated": "2019-03-05T15:51:00+00:00",
      "title": "Christian Jaros",
      "description": "Nov 19, 2018; Ottawa, Ontario, CAN; Ottawa Senators defenseman Christian Jaros (83) skates with the puck in the second period against the Florida Panthers at the Canadian Tire Centre. Mandatory Credit: Marc DesRosiers-USA TODAY Sports",
      "player_id": "8640b610-1f30-4aa1-b75e-42406541404d",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/fcd22f17-dcc3-4f39-8dc0-f60df419ec62/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Jaros, Christian",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "8640b610-1f30-4aa1-b75e-42406541404d",
          "sportradar_id": "8640b610-1f30-4aa1-b75e-42406541404d",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "8640b610-1f30-4aa1-b75e-42406541404d",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Ottawa Senators",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416f5e2-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3700",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "9",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "32422c66-7235-4a05-9a70-3482c27dd147",
      "created": "2019-02-27T15:16:53+00:00",
      "updated": "2019-03-05T20:24:39+00:00",
      "title": "Dominik Kahun",
      "description": "Dec 11, 2018; Winnipeg, Manitoba, CAN;  Chicago Blackhawks center Dominik Kahun (24) warms up in front of fans before tonight's game against the Winnipeg Jets at Bell MTS Place. Mandatory Credit: James Carey Lauder-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/32422c66-7235-4a05-9a70-3482c27dd147/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Chicago Blackhawks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416272f-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3681",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "16",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8589fa63-ce92-4ca9-ba8a-083797d93e70",
      "created": "2019-02-27T15:18:01+00:00",
      "updated": "2019-03-05T15:42:57+00:00",
      "title": "Warren Foegele",
      "description": "Oct 26, 2018; Raleigh, NC, USA;  Carolina Hurricanes left wing Warren Foegele (13) skates with the puck against the San Jose Sharks at PNC Arena. The Carolina Hurricanes defeated the San Jose Sharks 4-3 in the shoot out. Mandatory Credit: James Guillory-USA TODAY Sports",
      "player_id": "c4437c0c-b8bd-4574-82d4-7cfd78e13aaa",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8589fa63-ce92-4ca9-ba8a-083797d93e70/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Foegele, Warren",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c4437c0c-b8bd-4574-82d4-7cfd78e13aaa",
          "sportradar_id": "c4437c0c-b8bd-4574-82d4-7cfd78e13aaa",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c4437c0c-b8bd-4574-82d4-7cfd78e13aaa",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:925670",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477998",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Carolina Hurricanes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44182a9d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3680",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "12",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "72be9851-0e23-4664-9a7a-bb199d49d98d",
      "created": "2019-02-27T15:18:22+00:00",
      "updated": "2019-03-05T15:32:47+00:00",
      "title": "Mario Kempe",
      "description": "Oct 4, 2018; Dallas, TX, USA; Arizona Coyotes right wing Mario Kempe (29) skates against the Dallas Stars during the game at American Airlines Center. Mandatory Credit: Jerome Miron-USA TODAY Sports",
      "player_id": "6be7e11b-edb9-44c8-888b-013294a2020f",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/72be9851-0e23-4664-9a7a-bb199d49d98d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Kempe, Mario",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "6be7e11b-edb9-44c8-888b-013294a2020f",
          "sportradar_id": "6be7e11b-edb9-44c8-888b-013294a2020f",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "6be7e11b-edb9-44c8-888b-013294a2020f",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:42551",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8474131",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Arizona Coyotes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44153da1-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3698",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "27",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "c1afbbab-cbde-4bb5-9b29-78705194c832",
      "created": "2019-02-27T15:18:30+00:00",
      "updated": "2019-03-05T15:29:45+00:00",
      "title": "Casey DeSmith",
      "description": "Sep 23, 2018; Pittsburgh, PA, USA;  Pittsburgh Penguins goaltender Casey DeSmith (1) looks on during the national anthem against the Detroit Red Wings at PPG PAINTS Arena. Mandatory Credit: Charles LeClaire-USA TODAY Sports",
      "player_id": "44140209-737a-4a5e-96bf-1a22ecf847c5",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/c1afbbab-cbde-4bb5-9b29-78705194c832/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "DeSmith, Casey",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "44140209-737a-4a5e-96bf-1a22ecf847c5",
          "sportradar_id": "44140209-737a-4a5e-96bf-1a22ecf847c5",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44140209-737a-4a5e-96bf-1a22ecf847c5",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1054635",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479193",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Pittsburgh Penguins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417b7d7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3697",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "5",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "889dc708-fd84-403d-a526-5aab97749dcd",
      "created": "2019-02-27T15:17:50+00:00",
      "updated": "2019-02-27T23:21:43+00:00",
      "title": "Steven Stamkos",
      "description": "NHL: New York Islanders at Tampa Bay Lightning",
      "player_id": "4345603e-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/889dc708-fd84-403d-a526-5aab97749dcd/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Stamkos, Steven",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "4345603e-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4345603e-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4345603e-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:42457",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8474564",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Tampa Bay Lightning",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417d3cb-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3694",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "14",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5",
      "created": "2019-02-27T15:18:45+00:00",
      "updated": "2019-03-05T15:22:12+00:00",
      "title": "Ilya Lyubushkin",
      "description": "Sep 16, 2018; Las Vegas, NV, USA; Vegas Golden Knights right wing takes a swing at Arizona Coyotes defenseman Ilya Lyubushkin (46) during the second period at T-Mobile Arena. Mandatory Credit: Stephen R. Sylvanie-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/e2afb0b3-cdb9-4b6a-8602-2e324cfdb8e5/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Arizona Coyotes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44153da1-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3698",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "27",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "73f4790c-27e9-4faf-9487-d9bb22139b08",
      "created": "2019-02-27T15:17:48+00:00",
      "updated": "2019-03-05T15:47:03+00:00",
      "title": "Joel Hanley",
      "description": "Nov 10, 2018; Dallas, TX, USA; Dallas Stars defenseman Joel Hanley (39) enters the rink during warmups before the game against the Nashville Predators at American Airlines Center. Mandatory Credit: Shanna Lockwood-USA TODAY Sports",
      "player_id": "47f4508c-e59a-4846-8751-00c56610b45b",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/73f4790c-27e9-4faf-9487-d9bb22139b08/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Hanley, Joel",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "47f4508c-e59a-4846-8751-00c56610b45b",
          "sportradar_id": "47f4508c-e59a-4846-8751-00c56610b45b",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "47f4508c-e59a-4846-8751-00c56610b45b",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:854496",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477810",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Dallas Stars",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44157522-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44157522-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44157522-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3684",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "25",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "519328a2-c74c-4bec-a172-b35e31f2217d",
      "created": "2019-02-27T15:17:30+00:00",
      "updated": "2019-02-27T15:32:20+00:00",
      "title": "Juuso Valimaki",
      "description": "NHL: Winnipeg Jets at Calgary Flames",
      "player_id": "6981a907-8e85-4506-8f53-74879c8ce1ee",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/519328a2-c74c-4bec-a172-b35e31f2217d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Valimaki, Juuso",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "6981a907-8e85-4506-8f53-74879c8ce1ee",
          "sportradar_id": "6981a907-8e85-4506-8f53-74879c8ce1ee",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "6981a907-8e85-4506-8f53-74879c8ce1ee",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1088322",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479976",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Calgary Flames",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44159241-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44159241-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44159241-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3679",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "20",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "ebf0d314-7d9d-42ac-ab0a-fae14fad2640",
      "created": "2019-02-27T15:18:29+00:00",
      "updated": "2019-03-05T15:30:30+00:00",
      "title": "Juuso Riikola",
      "description": "Sep 23, 2018; Pittsburgh, PA, USA;  Pittsburgh Penguins defenseman Juuso Riikola (50) at the face-off circle against the Detroit Red Wings during the first period at PPG PAINTS Arena. Mandatory Credit: Charles LeClaire-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/ebf0d314-7d9d-42ac-ab0a-fae14fad2640/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Pittsburgh Penguins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417b7d7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3697",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "5",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "353109c1-fb9b-44c3-9534-515ca948d344",
      "created": "2019-02-27T15:18:09+00:00",
      "updated": "2019-03-05T15:39:49+00:00",
      "title": "NHL: Carolina Hurricanes at Tampa Bay Lightning",
      "description": "Oct 16, 2018; Tampa, FL, USA; Tampa Bay Lightning left wing Adam Erne (73) during the second period at Amalie Arena. Mandatory Credit: Kim Klement-USA TODAY Sports",
      "player_id": "1fb147ff-2d0f-4992-ba99-8446d07ce770",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/353109c1-fb9b-44c3-9534-515ca948d344/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Erne, Adam",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "1fb147ff-2d0f-4992-ba99-8446d07ce770",
          "sportradar_id": "1fb147ff-2d0f-4992-ba99-8446d07ce770",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "1fb147ff-2d0f-4992-ba99-8446d07ce770",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:352836",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477454",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Tampa Bay Lightning",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417d3cb-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3694",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "14",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "559576d4-a3ef-4e24-9c52-5bb36c7f32cd",
      "created": "2019-02-27T15:18:13+00:00",
      "updated": "2019-03-05T15:36:40+00:00",
      "title": "Kiefer Sherwood",
      "description": "Oct 13, 2018; Dallas, TX, USA; Anaheim Ducks right wing Kiefer Sherwood (64) celebrates a goal against the Dallas Stars during the game between the Ducks and the Stars at the American Airlines Center. Mandatory Credit: Jerome Miron-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/559576d4-a3ef-4e24-9c52-5bb36c7f32cd/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Anaheim Ducks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441862de-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441862de-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441862de-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3675",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "24",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "7918a7b2-0802-4b14-a78f-06938b8625fc",
      "created": "2019-02-27T15:17:18+00:00",
      "updated": "2019-03-05T20:14:33+00:00",
      "title": "Pat Maroon",
      "description": "NHL: St. Louis Blues at Colorado Avalanche",
      "player_id": "4277414c-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/7918a7b2-0802-4b14-a78f-06938b8625fc/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Maroon, Patrick",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "4277414c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4277414c-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4277414c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:182321",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8474034",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "St. Louis Blues",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441660ea-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3695",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "19",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "7cd7635f-e9d3-4b97-b130-d41cd950d11d",
      "created": "2019-02-27T15:17:19+00:00",
      "updated": "2019-03-05T20:13:54+00:00",
      "title": "Lawrence Pilut",
      "description": "Nov 29, 2018; Tampa, FL, USA; Buffalo Sabres defenseman Lawrence Pilut (24) works out prior to the game against the Tampa Bay Lightning at Amalie Arena. Mandatory Credit: Kim Klement-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/7cd7635f-e9d3-4b97-b130-d41cd950d11d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Buffalo Sabres",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416d559-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3678",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "7",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "f43f6d60-4de3-4933-a49a-836157ac823d",
      "created": "2019-02-27T15:17:17+00:00",
      "updated": "2019-03-05T20:15:10+00:00",
      "title": "Brett Seney",
      "description": "Dec 1, 2018; Newark, NJ, USA; New Jersey Devils left wing Brett Seney (43) skates with the puck defended by Winnipeg Jets center Jack Roslovic (28) during the first period at Prudential Center. Mandatory Credit: Dennis Schneidler-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/f43f6d60-4de3-4933-a49a-836157ac823d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "New Jersey Devils",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44174b0c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3704",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "1",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "f82d6762-8267-44b3-83d8-16b3456cf9ec",
      "created": "2019-02-27T15:17:59+00:00",
      "updated": "2019-03-05T15:43:38+00:00",
      "title": "Par Lindholm",
      "description": "Oct 27, 2018; Toronto, Ontario, CAN; Toronto Maple Leafs center Par Lindholm (26) during their game against the Winnipeg Jets at Scotiabank Arena. The Maple Leafs beat the Jets 3-2. Mandatory Credit: Tom Szczerbowski-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/f82d6762-8267-44b3-83d8-16b3456cf9ec/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Toronto Maple Leafs",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441730a9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3693",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "10",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "ec0d9124-eacb-4532-9325-e36fd650a25a",
      "created": "2019-02-27T15:18:32+00:00",
      "updated": "2019-03-05T15:29:06+00:00",
      "title": "Justin Holl",
      "description": "Sep 22, 2018; Buffalo, NY, USA; Toronto Maple Leafs defenseman Justin Holl (54) against the Buffalo Sabres at KeyBank Center. Mandatory Credit: Timothy T. Ludwig-USA TODAY Sports",
      "player_id": "84867861-af25-4574-aa3f-2d94855fe3c5",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/ec0d9124-eacb-4532-9325-e36fd650a25a/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Holl, Justin",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "84867861-af25-4574-aa3f-2d94855fe3c5",
          "sportradar_id": "84867861-af25-4574-aa3f-2d94855fe3c5",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "84867861-af25-4574-aa3f-2d94855fe3c5",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:904480",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8475718",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Toronto Maple Leafs",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441730a9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3693",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "10",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7",
      "created": "2019-02-27T15:18:06+00:00",
      "updated": "2019-03-05T15:41:42+00:00",
      "title": "Rourke Chartier",
      "description": "Oct 20, 2018; San Jose, CA, USA; San Jose Sharks center Rourke Chartier (60) controls the puck against the New York Islanders during the second period at SAP Center at San Jose. Mandatory Credit: Neville E. Guard-USA TODAY Sports",
      "player_id": "8fa569fe-f5c9-43b4-9ed8-71989d42f840",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/eac5e55b-2574-4c56-b5b2-bfacb3b3bbd7/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Chartier, Rourke",
          "type": "profile",
          "sport": "NHL",
          "sportsdata_id": "8fa569fe-f5c9-43b4-9ed8-71989d42f840",
          "sportradar_id": "8fa569fe-f5c9-43b4-9ed8-71989d42f840",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "8fa569fe-f5c9-43b4-9ed8-71989d42f840",
              "sport": "NHL"
            },
            {
              "origin": "SR",
              "id": "sr:player:899414",
              "sport": "NHL"
            },
            {
              "origin": "NHL",
              "id": "8478078",
              "sport": "NHL"
            }
          ]
        },
        {
          "name": "San Jose Sharks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44155909-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44155909-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44155909-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3696",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "28",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a372bcd5-5672-473d-a2e4-7da1584a5c65",
      "created": "2019-02-27T15:18:34+00:00",
      "updated": "2019-03-05T15:28:00+00:00",
      "title": "Dylan Sikura",
      "description": "Sep 21, 2018; Ottawa, Ontario, CAN; Chicago Blackhawks Dylan Sikura (95) skates with the puck in the first period against the Ottawa Senators at Canadian Tire Centre. Mandatory Credit: Marc DesRosiers-USA TODAY Sports",
      "player_id": "8f8ef05e-3096-47df-862a-f104fc454c32",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a372bcd5-5672-473d-a2e4-7da1584a5c65/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Sikura, Dylan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "8f8ef05e-3096-47df-862a-f104fc454c32",
          "sportradar_id": "8f8ef05e-3096-47df-862a-f104fc454c32",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "8f8ef05e-3096-47df-862a-f104fc454c32",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1297834",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478106",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Chicago Blackhawks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416272f-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3681",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "16",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc",
      "created": "2019-02-27T15:18:36+00:00",
      "updated": "2019-03-05T15:26:36+00:00",
      "title": "Bogdan Kiselevich",
      "description": "Sep 19, 2018; Montreal, Quebec, CAN; Florida Panthers defenseman Bogdan Kiselevich (55) and Montreal Canadiens center battle for the puck during the second period at Bell Centre. Mandatory Credit: Jean-Yves Ahern-USA TODAY Sports",
      "player_id": "3b4c8677-9f66-4395-a914-5399b47b7c3f",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/cb49b3ad-8b8d-4d05-b6c8-bb9de50724dc/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Kiselevich, Bogdan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "3b4c8677-9f66-4395-a914-5399b47b7c3f",
          "sportradar_id": "3b4c8677-9f66-4395-a914-5399b47b7c3f",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "3b4c8677-9f66-4395-a914-5399b47b7c3f",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:88109",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480955",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Florida Panthers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4418464d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3687",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "13",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "4127bd32-d87a-468a-b974-7a75ef3fab87",
      "created": "2019-02-27T15:18:11+00:00",
      "updated": "2019-02-27T23:26:01+00:00",
      "title": "Ben Street",
      "description": "NHL: Anaheim Ducks at Dallas Stars",
      "player_id": "62b8c7d0-7247-11e2-a3e0-f4ce4684ea4c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/4127bd32-d87a-468a-b974-7a75ef3fab87/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Street, Ben",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "62b8c7d0-7247-11e2-a3e0-f4ce4684ea4c",
          "sportradar_id": "62b8c7d0-7247-11e2-a3e0-f4ce4684ea4c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "62b8c7d0-7247-11e2-a3e0-f4ce4684ea4c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:325463",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476043",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Anaheim Ducks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441862de-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441862de-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441862de-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3675",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "24",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "4c485160-8a6f-4246-9e16-357a548f660d",
      "created": "2019-02-27T15:18:37+00:00",
      "updated": "2019-02-27T23:28:18+00:00",
      "title": "Michael Rasmussen",
      "description": "NHL: Preseason-Pittsburgh Penguins at Detroit Red Wings",
      "player_id": "f8f58c6e-90aa-4127-b59c-3dba9d8a454d",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/4c485160-8a6f-4246-9e16-357a548f660d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Rasmussen, Michael",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "f8f58c6e-90aa-4127-b59c-3dba9d8a454d",
          "sportradar_id": "f8f58c6e-90aa-4127-b59c-3dba9d8a454d",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "f8f58c6e-90aa-4127-b59c-3dba9d8a454d",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1117317",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479992",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Detroit Red Wings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44169bb9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3685",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "17",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "86fc5816-389e-42e1-95be-03bb67522dae",
      "created": "2019-02-27T15:17:44+00:00",
      "updated": "2019-03-05T15:48:13+00:00",
      "title": "Jordan Greenway",
      "description": "Nov 11, 2018; St. Louis, MO, USA; Minnesota Wild left wing Jordan Greenway (18) handles the puck during the second period against the St. Louis Blues at Enterprise Center. Mandatory Credit: Jeff Curry-USA TODAY Sports",
      "player_id": "0cc207c2-d69d-4c56-acbb-3cd9fa01321c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/86fc5816-389e-42e1-95be-03bb67522dae/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Greenway, Jordan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "0cc207c2-d69d-4c56-acbb-3cd9fa01321c",
          "sportradar_id": "0cc207c2-d69d-4c56-acbb-3cd9fa01321c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "0cc207c2-d69d-4c56-acbb-3cd9fa01321c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1088184",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478413",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Minnesota Wild",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416091c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416091c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416091c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3689",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "30",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a43bdc0c-7d32-47cf-96ec-caac65b3c0ac",
      "created": "2019-02-27T15:18:23+00:00",
      "updated": "2019-02-27T23:27:28+00:00",
      "title": "Andreas Johnsson",
      "description": "NHL: Montreal Canadiens at Toronto Maple Leafs",
      "player_id": "c2a31775-185e-4630-9b1e-a7d779864128",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a43bdc0c-7d32-47cf-96ec-caac65b3c0ac/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Johnsson, Andreas",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c2a31775-185e-4630-9b1e-a7d779864128",
          "sportradar_id": "c2a31775-185e-4630-9b1e-a7d779864128",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c2a31775-185e-4630-9b1e-a7d779864128",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1051355",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477341",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Toronto Maple Leafs",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441730a9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3693",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "10",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "6dcd25b0-e471-4e45-9718-8c83120e55a4",
      "created": "2019-02-27T15:17:57+00:00",
      "updated": "2019-03-05T15:44:12+00:00",
      "title": "Henri Jokiharju",
      "description": "Oct 27, 2018; St. Louis, MO, USA; Chicago Blackhawks defenseman Henri Jokiharju (28) reacts after scoring during the second period against the St. Louis Blues at Enterprise Center. Mandatory Credit: Jeff Curry-USA TODAY Sports",
      "player_id": "46ebc2ab-7e0b-4c07-8b5a-9c8fa0509494",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/6dcd25b0-e471-4e45-9718-8c83120e55a4/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Jokiharju, Henri",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "46ebc2ab-7e0b-4c07-8b5a-9c8fa0509494",
          "sportradar_id": "46ebc2ab-7e0b-4c07-8b5a-9c8fa0509494",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "46ebc2ab-7e0b-4c07-8b5a-9c8fa0509494",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1117779",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480035",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Chicago Blackhawks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416272f-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3681",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "16",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "af125356-249b-45f2-8419-d25d2dc8f649",
      "created": "2019-02-27T15:17:45+00:00",
      "updated": "2019-03-05T15:47:35+00:00",
      "title": "Danick Martel",
      "description": "Nov 10, 2018; Tampa, FL, USA; Tampa Bay Lightning center Danick Martel (62) skates on the ice during the first period against the Ottawa Senators at Amalie Arena. Mandatory Credit: Douglas DeFelice-USA TODAY Sports",
      "player_id": "694c6236-4baf-4941-a02b-d034c1eede78",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/af125356-249b-45f2-8419-d25d2dc8f649/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Martel, Danick",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "694c6236-4baf-4941-a02b-d034c1eede78",
          "sportradar_id": "694c6236-4baf-4941-a02b-d034c1eede78",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "694c6236-4baf-4941-a02b-d034c1eede78",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:899384",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478365",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Tampa Bay Lightning",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417d3cb-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3694",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "14",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8c47d230-49c3-4871-b445-93ef4cbb3a4d",
      "created": "2019-02-27T15:18:18+00:00",
      "updated": "2019-03-05T15:34:15+00:00",
      "title": "Brady Tkachuk",
      "description": "NHL: Ottawa Senators at Boston Bruins",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8c47d230-49c3-4871-b445-93ef4cbb3a4d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Ottawa Senators",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416f5e2-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3700",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "9",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "b1cdb8a1-2d15-4da5-a773-91c0222a79cb",
      "created": "2019-02-27T15:17:27+00:00",
      "updated": "2019-03-05T20:11:31+00:00",
      "title": "David Kampf",
      "description": "Nov 23, 2018; Tampa, FL, USA; Chicago Blackhawks center David Kampf (64) skates down ice during the second periodagainst the Tampa Bay Lightning at Amalie Arena. Mandatory Credit: Reinhold Matay-USA TODAY Sports",
      "player_id": "11db2df4-71c0-43f7-ae46-385ccd689ea3",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/b1cdb8a1-2d15-4da5-a773-91c0222a79cb/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Kampf, David",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "11db2df4-71c0-43f7-ae46-385ccd689ea3",
          "sportradar_id": "11db2df4-71c0-43f7-ae46-385ccd689ea3",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "11db2df4-71c0-43f7-ae46-385ccd689ea3",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:350254",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480144",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Chicago Blackhawks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416272f-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416272f-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3681",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "16",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15",
      "created": "2019-02-27T15:17:33+00:00",
      "updated": "2019-03-05T15:52:12+00:00",
      "title": "Dillon Dube",
      "description": "Nov 21, 2018; Calgary, Alberta, CAN; Calgary Flames center Dillon Dube (29) celebrates his goal with teammates against the Winnipeg Jets during the first period at Scotiabank Saddledome. Mandatory Credit: Sergei Belski-USA TODAY Sports",
      "player_id": "a8a1c52d-7f83-4bf4-8d4f-67f4760943d5",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/ce49fd7f-62f4-4c69-a2d9-cbcf4ba32b15/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Dube, Dillon",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "a8a1c52d-7f83-4bf4-8d4f-67f4760943d5",
          "sportradar_id": "a8a1c52d-7f83-4bf4-8d4f-67f4760943d5",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "a8a1c52d-7f83-4bf4-8d4f-67f4760943d5",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Calgary Flames",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44159241-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44159241-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44159241-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3679",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "20",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a994ee9b-85cd-440d-abf5-849c62b7a614",
      "created": "2019-02-27T15:17:22+00:00",
      "updated": "2019-03-05T20:12:46+00:00",
      "title": "Travis Dermott",
      "description": "Nov 26, 2018; Toronto, Ontario, CAN;   Toronto Maple Leafs defenceman Travis Dermott (23) celebrates with teammates after scoring a goal against Boston Bruins in the first period at Scotiabank Arena. Mandatory Credit: Dan Hamilton-USA TODAY Sports",
      "player_id": "29212452-aad3-4af3-987b-4b7f4321f5a8",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a994ee9b-85cd-440d-abf5-849c62b7a614/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Dermott, Travis",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "29212452-aad3-4af3-987b-4b7f4321f5a8",
          "sportradar_id": "29212452-aad3-4af3-987b-4b7f4321f5a8",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "29212452-aad3-4af3-987b-4b7f4321f5a8",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:901260",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478408",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Toronto Maple Leafs",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441730a9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441730a9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3693",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "10",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "72d93022-321f-47a5-88e7-097deb7b1226",
      "created": "2019-02-27T15:18:42+00:00",
      "updated": "2019-03-05T15:24:13+00:00",
      "title": "Conor Garland",
      "description": "Sep 18, 2018; Los Angeles, CA, USA; Arizona Coyotes right wing Conor Garland (83) takes the puck down ice in the first period against the Los Angeles Kings at Staples Center. Mandatory Credit: Jayne Kamin-Oncea-USA TODAY Sports",
      "player_id": "3785ac3d-5771-4342-be09-f4fb22ed84b3",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/72d93022-321f-47a5-88e7-097deb7b1226/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Garland, Conor",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "3785ac3d-5771-4342-be09-f4fb22ed84b3",
          "sportradar_id": "3785ac3d-5771-4342-be09-f4fb22ed84b3",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "3785ac3d-5771-4342-be09-f4fb22ed84b3",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:905242",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478856",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Arizona Coyotes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44153da1-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3698",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "27",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e96adb9b-58bc-4f0e-bdbc-cf850c7192a7",
      "created": "2019-02-27T15:17:14+00:00",
      "updated": "2019-03-05T20:15:49+00:00",
      "title": "Tony DeAngelo",
      "description": "Dec 2, 2018; New York, NY, USA; New York Rangers defenseman Tony DeAngelo (77) brings the puck out from behind the goal defended by Winnipeg Jets left wing during the first period at Madison Square Garden. Mandatory Credit: Dennis Schneidler-USA TODAY Sports",
      "player_id": "71a1c056-e3fc-4b5f-b0f3-d75837560889",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/e96adb9b-58bc-4f0e-bdbc-cf850c7192a7/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "DeAngelo, Anthony",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "71a1c056-e3fc-4b5f-b0f3-d75837560889",
          "sportradar_id": "71a1c056-e3fc-4b5f-b0f3-d75837560889",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "71a1c056-e3fc-4b5f-b0f3-d75837560889",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:837171",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477950",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New York Rangers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441781b9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3701",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "3",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a207970f-46fe-4d29-aaa8-7f44cbbc8633",
      "created": "2019-02-27T15:18:28+00:00",
      "updated": "2019-02-27T23:27:52+00:00",
      "title": "Denis Gurianov",
      "description": "NHL: Preseason-Minnesota Wild at Dallas Stars",
      "player_id": "25bf3bd6-cbfc-4cdf-bf50-64c5ae021b7c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a207970f-46fe-4d29-aaa8-7f44cbbc8633/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Gurianov, Denis",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "25bf3bd6-cbfc-4cdf-bf50-64c5ae021b7c",
          "sportradar_id": "25bf3bd6-cbfc-4cdf-bf50-64c5ae021b7c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "25bf3bd6-cbfc-4cdf-bf50-64c5ae021b7c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:597036",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478495",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Dallas Stars",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44157522-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44157522-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44157522-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3684",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "25",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "3f7caac9-9617-4753-a094-34a8ab65ada6",
      "created": "2019-02-27T15:17:28+00:00",
      "updated": "2019-03-05T20:10:55+00:00",
      "title": "Gavin Bayreuther",
      "description": "Nov 23, 2018; Dallas, TX, USA; Dallas Stars defenseman Gavin Bayreuther (44) celebrates scoring his first career goal during the third period against the Ottawa Senators at the American Airlines Center. Mandatory Credit: Jerome Miron-USA TODAY Sports",
      "player_id": "d2f2bfb6-0377-4102-8e10-8741de978934",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/3f7caac9-9617-4753-a094-34a8ab65ada6/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Bayreuther, Gavin",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "d2f2bfb6-0377-4102-8e10-8741de978934",
          "sportradar_id": "d2f2bfb6-0377-4102-8e10-8741de978934",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "d2f2bfb6-0377-4102-8e10-8741de978934",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Dallas Stars",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44157522-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44157522-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44157522-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3684",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "25",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5",
      "created": "2019-02-27T15:17:56+00:00",
      "updated": "2019-02-27T23:23:13+00:00",
      "title": "Philipp Grubauer",
      "description": "NHL: Colorado Avalanche at Vancouver Canucks",
      "player_id": "d6a16994-80fc-11e2-a3e0-f4ce4684ea4c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/5a2ff5d6-ed89-4434-a6d6-06d38b2fa5c5/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Philipp Grubauer",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "d6a16994-80fc-11e2-a3e0-f4ce4684ea4c",
          "sportradar_id": "d6a16994-80fc-11e2-a3e0-f4ce4684ea4c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "d6a16994-80fc-11e2-a3e0-f4ce4684ea4c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:355146",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8475831",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Colorado Avalanche",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ce44-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3682",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "21",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "505d6073-51d4-44aa-ad51-1889580d2697",
      "created": "2019-02-27T15:18:07+00:00",
      "updated": "2019-03-05T15:41:08+00:00",
      "title": "Urho Vaakanainen",
      "description": "NHL: Boston Bruins at Vancouver Canucks",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/505d6073-51d4-44aa-ad51-1889580d2697/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Boston Bruins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416ba1a-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416ba1a-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416ba1a-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3677",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "6",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e3f1d3d3-8ade-410b-b54e-74a17e22129a",
      "created": "2019-02-27T15:16:50+00:00",
      "updated": "2019-02-27T15:24:02+00:00",
      "title": "Caleb Jones",
      "description": "NHL: Philadelphia Flyers at Edmonton Oilers",
      "player_id": "61420e61-bfaf-4437-8276-03b5b0aa78f4",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/e3f1d3d3-8ade-410b-b54e-74a17e22129a/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Jones, Caleb",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "61420e61-bfaf-4437-8276-03b5b0aa78f4",
          "sportradar_id": "61420e61-bfaf-4437-8276-03b5b0aa78f4",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "61420e61-bfaf-4437-8276-03b5b0aa78f4",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:905296",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478452",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Edmonton Oilers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ea6c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3686",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "22",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "14e58ac0-2f8c-4b88-a4f0-a2db3e587044",
      "created": "2019-02-27T15:17:37+00:00",
      "updated": "2019-03-05T15:50:28+00:00",
      "title": "Clark Bishop",
      "description": "Nov 18, 2018; Raleigh, NC, USA;  Carolina Hurricanes center Clark Bishop (64) skates with the puck against the New Jersey Devils at PNC Arena. The Carolina Hurricanes defeated the New Jersey Devils 2-1. Mandatory Credit: James Guillory-USA TODAY Sports",
      "player_id": "4a3b2bea-9013-4a83-9bee-403769080f7d",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/14e58ac0-2f8c-4b88-a4f0-a2db3e587044/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Bishop, Clark",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "4a3b2bea-9013-4a83-9bee-403769080f7d",
          "sportradar_id": "4a3b2bea-9013-4a83-9bee-403769080f7d",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4a3b2bea-9013-4a83-9bee-403769080f7d",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:904554",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478056",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Carolina Hurricanes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44182a9d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3680",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "12",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "eb144309-7a51-4e16-a4fa-918876ac33ed",
      "created": "2019-02-27T15:17:46+00:00",
      "updated": "2019-02-27T23:19:41+00:00",
      "title": "Miro Heiskanen",
      "description": "NHL: Nashville Predators at Dallas Stars",
      "player_id": "edc6f332-3569-4673-b590-53e8dd1671f2",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/eb144309-7a51-4e16-a4fa-918876ac33ed/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Heiskanen, Miro",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "edc6f332-3569-4673-b590-53e8dd1671f2",
          "sportradar_id": "edc6f332-3569-4673-b590-53e8dd1671f2",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "edc6f332-3569-4673-b590-53e8dd1671f2",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1049985",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480036",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Dallas Stars",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44157522-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44157522-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44157522-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3684",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "25",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "0f354858-3232-4098-b3ae-a90e5c3689dc",
      "created": "2019-02-27T15:18:21+00:00",
      "updated": "2019-03-05T15:33:22+00:00",
      "title": "Nick Seeler",
      "description": "Oct 6, 2018; Saint Paul, MN, USA; Minnesota Wild defenseman Nick Seeler (36) in the first period against Las Vegas Golden Knights at Xcel Energy Center. Mandatory Credit: Brad Rempel-USA TODAY Sports",
      "player_id": "5cc3cbb7-619c-466b-a845-fdce5d0c403d",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/0f354858-3232-4098-b3ae-a90e5c3689dc/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Seeler, Nick",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "5cc3cbb7-619c-466b-a845-fdce5d0c403d",
          "sportradar_id": "5cc3cbb7-619c-466b-a845-fdce5d0c403d",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "5cc3cbb7-619c-466b-a845-fdce5d0c403d",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:978493",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476372",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Minnesota Wild",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416091c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416091c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416091c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3689",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "30",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "4539d0eb-79ba-4c48-8207-c5b00ec7394d",
      "created": "2019-02-27T15:17:05+00:00",
      "updated": "2019-03-05T20:20:49+00:00",
      "title": "Valentin Zykov",
      "description": "Dec 7, 2018; Edmonton, Alberta, CAN; Edmonton Oilers forward Valentin Zykov (73) looks for a loose puck against the Minnesota Wild at Rogers Place. Mandatory Credit: Perry Nelson-USA TODAY Sports",
      "player_id": "7a32b4ef-734a-40b7-8b19-909c1d22d3ce",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/4539d0eb-79ba-4c48-8207-c5b00ec7394d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Zykov, Valentin",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "7a32b4ef-734a-40b7-8b19-909c1d22d3ce",
          "sportradar_id": "7a32b4ef-734a-40b7-8b19-909c1d22d3ce",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "7a32b4ef-734a-40b7-8b19-909c1d22d3ce",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:905264",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477458",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Edmonton Oilers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ea6c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3686",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "22",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "07507d3d-6e7a-4188-b09e-57d4df17ce86",
      "created": "2019-02-27T15:17:10+00:00",
      "updated": "2019-02-27T15:29:48+00:00",
      "title": "Linus Ullmark",
      "description": "NHL: Toronto Maple Leafs at Buffalo Sabres",
      "player_id": "d4dd5956-5c99-4e69-b21f-713b64327eca",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/07507d3d-6e7a-4188-b09e-57d4df17ce86/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Ullmark, Linus",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "d4dd5956-5c99-4e69-b21f-713b64327eca",
          "sportradar_id": "d4dd5956-5c99-4e69-b21f-713b64327eca",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "d4dd5956-5c99-4e69-b21f-713b64327eca",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:350972",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476999",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Buffalo Sabres",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416d559-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416d559-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3678",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "7",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800",
      "created": "2019-02-27T15:16:59+00:00",
      "updated": "2019-02-27T15:26:43+00:00",
      "title": "Radko Gudas",
      "description": "NHL: Philadelphia Flyers at Winnipeg Jets",
      "player_id": "43493300-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8dbea7c7-8fb4-4b2a-99d1-37e44ecd7800/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Gudas, Radko",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "43493300-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "43493300-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "43493300-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:318321",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8475462",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Winnipeg Jets",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44180e55-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44180e55-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44180e55-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3676",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "52",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "ba64f8ab-ad33-43b8-a56f-41e775f0719f",
      "created": "2019-02-27T15:16:46+00:00",
      "updated": "2019-02-27T15:23:31+00:00",
      "title": "Luke Kunin",
      "description": "NHL: Calgary Flames at Minnesota Wild",
      "player_id": "3ff2b7e7-ab4d-4af8-94e0-b226ad56f8cb",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/ba64f8ab-ad33-43b8-a56f-41e775f0719f/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Kunin, Luke",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "3ff2b7e7-ab4d-4af8-94e0-b226ad56f8cb",
          "sportradar_id": "3ff2b7e7-ab4d-4af8-94e0-b226ad56f8cb",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "3ff2b7e7-ab4d-4af8-94e0-b226ad56f8cb",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:983683",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479316",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Minnesota Wild",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416091c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416091c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416091c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3689",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "30",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "48bb3d75-175f-4daf-9ff5-a558bf10f1ed",
      "created": "2019-02-27T15:17:21+00:00",
      "updated": "2019-03-05T20:13:18+00:00",
      "title": "Austin Wagner",
      "description": "Nov 27, 2018; Vancouver, British Columbia, CAN; Los Angeles Kings forward Austin Wagner (51) battles for the puck against Vancouver Canucks forward during the second period at Rogers Arena. Mandatory Credit: Anne-Marie Sorvin-USA TODAY Sports",
      "player_id": "93ffbb8a-826c-418d-b26c-d06ce73ba75f",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/48bb3d75-175f-4daf-9ff5-a558bf10f1ed/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Wagner, Austin",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "93ffbb8a-826c-418d-b26c-d06ce73ba75f",
          "sportradar_id": "93ffbb8a-826c-418d-b26c-d06ce73ba75f",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "93ffbb8a-826c-418d-b26c-d06ce73ba75f",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Los Angeles Kings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44151f7a-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3688",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "26",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5",
      "created": "2019-02-27T15:18:08+00:00",
      "updated": "2019-03-05T15:40:24+00:00",
      "title": "Matthew Peca",
      "description": "Oct 17, 2018; Montreal, Quebec, CAN; Montreal Canadiens center Matthew Peca (63) during the warm-up session before the game against St. Louis Blues at Bell Centre. Mandatory Credit: Jean-Yves Ahern-USA TODAY Sports",
      "player_id": "d5538fae-06f9-4ce8-80b6-49c584cce7a9",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/7bd4bbb0-d10c-4cc3-8e5b-5801f9a34cd5/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Peca, Matthew",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "d5538fae-06f9-4ce8-80b6-49c584cce7a9",
          "sportradar_id": "d5538fae-06f9-4ce8-80b6-49c584cce7a9",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "d5538fae-06f9-4ce8-80b6-49c584cce7a9",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:901222",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476285",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Montreal Canadiens",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441713b7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3690",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "fadd61df-ec54-476a-9bac-6367ff0c38c3",
      "created": "2019-02-27T15:17:32+00:00",
      "updated": "2019-03-05T15:52:44+00:00",
      "title": "Rasmus Andersson",
      "description": "Nov 21, 2018; Calgary, Alberta, CAN; Calgary Flames defenseman Rasmus Andersson (4) skates with the puck against the Winnipeg Jets during the first period at Scotiabank Saddledome. Mandatory Credit: Sergei Belski-USA TODAY Sports",
      "player_id": "19ba927d-c4fe-4501-8c74-9a0e07c521de",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/fadd61df-ec54-476a-9bac-6367ff0c38c3/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Andersson, Rasmus",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "19ba927d-c4fe-4501-8c74-9a0e07c521de",
          "sportradar_id": "19ba927d-c4fe-4501-8c74-9a0e07c521de",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "19ba927d-c4fe-4501-8c74-9a0e07c521de",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:290417",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478397",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Calgary Flames",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44159241-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44159241-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44159241-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3679",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "20",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "0c59640f-0ab9-4e1d-900b-b424aa295ef0",
      "created": "2019-02-27T15:17:54+00:00",
      "updated": "2019-03-05T15:44:43+00:00",
      "title": "Wade Megan",
      "description": "Nov 3, 2018; Detroit, MI, USA; Detroit Red Wings center Wade Megan (left) reacts during the second period against the Edmonton Oilers at Little Caesars Arena. Mandatory Credit: Raj Mehta-USA TODAY Sports",
      "player_id": "2c1a7ba2-b939-40c7-881b-9d39a6fa7ce5",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/0c59640f-0ab9-4e1d-900b-b424aa295ef0/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Megan, Wade",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "2c1a7ba2-b939-40c7-881b-9d39a6fa7ce5",
          "sportradar_id": "2c1a7ba2-b939-40c7-881b-9d39a6fa7ce5",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "2c1a7ba2-b939-40c7-881b-9d39a6fa7ce5",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:904520",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8475263",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Detroit Red Wings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44169bb9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3685",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "17",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8f8708f6-66df-4365-aab0-418b716e0eb7",
      "created": "2019-02-27T15:18:10+00:00",
      "updated": "2019-03-05T15:37:26+00:00",
      "title": "Anthony Cirelli",
      "description": "Oct 16, 2018; Tampa, FL, USA;Tampa Bay Lightning center Anthony Cirelli (71)  during the first period at Amalie Arena. Mandatory Credit: Kim Klement-USA TODAY Sports",
      "player_id": "dffd535e-62c7-44e1-a50a-7b7bccf1ce98",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8f8708f6-66df-4365-aab0-418b716e0eb7/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Cirelli, Anthony ",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "dffd535e-62c7-44e1-a50a-7b7bccf1ce98",
          "sportradar_id": "dffd535e-62c7-44e1-a50a-7b7bccf1ce98",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "dffd535e-62c7-44e1-a50a-7b7bccf1ce98",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Tampa Bay Lightning",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417d3cb-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3694",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "14",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a2e98e86-5107-4aca-af0f-c1885099fc11",
      "created": "2019-02-27T15:16:57+00:00",
      "updated": "2019-03-05T20:22:19+00:00",
      "title": "Tyler Bertuzzi",
      "description": "Dec 10, 2018; Detroit, MI, USA; Detroit Red Wings left wing Tyler Bertuzzi (59) before the game against the Detroit Red Wings at Little Caesars Arena. Mandatory Credit: Tim Fuller-USA TODAY Sports",
      "player_id": "f07ccc44-97c2-49a9-9855-24433ff93c83",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a2e98e86-5107-4aca-af0f-c1885099fc11/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Bertuzzi, Tyler",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "f07ccc44-97c2-49a9-9855-24433ff93c83",
          "sportradar_id": "f07ccc44-97c2-49a9-9855-24433ff93c83",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "f07ccc44-97c2-49a9-9855-24433ff93c83",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Detroit Red Wings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44169bb9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44169bb9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3685",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "17",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "84d8a398-6b1f-4de6-be18-ecb133e4c6fd",
      "created": "2019-02-27T15:16:48+00:00",
      "updated": "2019-03-05T20:25:29+00:00",
      "title": "Janne Kuokkanen",
      "description": "Dec 14, 2018; Raleigh, NC, USA;  Carolina Hurricanes left wing Janne Kuokkanen (59) skates with the puck against the Washington Capitals at PNC Arena. The Capitals defeated the Hurricanes 6-5 in a shootout. Mandatory Credit: James Guillory-USA TODAY Sports",
      "player_id": "4ee009aa-5c88-49b2-98b3-d8cdd3e82800",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/84d8a398-6b1f-4de6-be18-ecb133e4c6fd/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Kuokkanen, Janne",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "4ee009aa-5c88-49b2-98b3-d8cdd3e82800",
          "sportradar_id": "4ee009aa-5c88-49b2-98b3-d8cdd3e82800",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4ee009aa-5c88-49b2-98b3-d8cdd3e82800",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:972103",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479511",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Carolina Hurricanes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44182a9d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3680",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "12",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "5416f2c1-41b6-4bdb-beb0-e138869e4a16",
      "created": "2019-02-27T15:17:15+00:00",
      "updated": "2019-02-27T15:30:57+00:00",
      "title": "Jacob Larsson",
      "description": "NHL: Anaheim Ducks at Washington Capitals",
      "player_id": "173965fc-fe2c-40fe-8b4d-acacbc161d64",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/5416f2c1-41b6-4bdb-beb0-e138869e4a16/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Larsson, Jacob",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "173965fc-fe2c-40fe-8b4d-acacbc161d64",
          "sportradar_id": "173965fc-fe2c-40fe-8b4d-acacbc161d64",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "173965fc-fe2c-40fe-8b4d-acacbc161d64",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:600362",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478491",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Anaheim Ducks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441862de-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441862de-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441862de-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3675",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "24",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e9ab60a8-5ec5-4860-b3f2-807470b576ed",
      "created": "2019-02-27T15:18:46+00:00",
      "updated": "2019-03-05T15:22:57+00:00",
      "title": "Michael Bunting",
      "description": "Sep 16, 2018; Las Vegas, NV, USA; Vegas Golden Knights defenseman tips the puck away from Arizona Coyotes left wing Michael Bunting (58) during the first period at T-Mobile Arena. Mandatory Credit: Stephen R. Sylvanie-USA TODAY Sports",
      "player_id": "cc2294b3-b7ca-4c3f-93d4-2795f85b126f",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/e9ab60a8-5ec5-4860-b3f2-807470b576ed/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Bunting, Michael",
          "type": "profile",
          "sport": "NHL",
          "sportsdata_id": "cc2294b3-b7ca-4c3f-93d4-2795f85b126f",
          "sportradar_id": "cc2294b3-b7ca-4c3f-93d4-2795f85b126f",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "cc2294b3-b7ca-4c3f-93d4-2795f85b126f",
              "sport": "NHL"
            },
            {
              "origin": "SR",
              "id": "sr:player:905212",
              "sport": "NHL"
            },
            {
              "origin": "NHL",
              "id": "8478047",
              "sport": "NHL"
            }
          ]
        },
        {
          "name": "Arizona Coyotes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44153da1-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44153da1-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3698",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "27",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "40c557ac-75eb-4633-8862-6e321ea9e99d",
      "created": "2019-02-27T15:17:07+00:00",
      "updated": "2019-03-05T20:18:51+00:00",
      "title": "Pheonix Copley",
      "description": "Dec 6, 2018; Glendale, AZ, USA; Washington Capitals goaltender Pheonix Copley (1) looks on prior to the game against the Arizona Coyotes at Gila River Arena. Mandatory Credit: Matt Kartozian-USA TODAY Sports",
      "player_id": "0a1a1d3a-7118-4d30-a2bd-a2f95822d22c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/40c557ac-75eb-4633-8862-6e321ea9e99d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Copley, Pheonix",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "0a1a1d3a-7118-4d30-a2bd-a2f95822d22c",
          "sportradar_id": "0a1a1d3a-7118-4d30-a2bd-a2f95822d22c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "0a1a1d3a-7118-4d30-a2bd-a2f95822d22c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:791897",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477831",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Washington Capitals",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417eede-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417eede-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417eede-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3691",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "15",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "4cdff7fe-b193-429e-8a53-3cde032f1bc0",
      "created": "2019-02-27T15:16:45+00:00",
      "updated": "2019-03-05T20:27:57+00:00",
      "title": "Jayce Hawryluk",
      "description": "Dec 15, 2018; Sunrise, FL, USA; Florida Panthers center Jayce Hawryluk (8) skates\rbefore a game against the Toronto Maple Leafs at BB&T Center. Mandatory Credit: Robert Mayer-USA TODAY Sports",
      "player_id": "78298614-3c9f-4c69-928a-4f46b35bb9f1",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/4cdff7fe-b193-429e-8a53-3cde032f1bc0/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Hawryluk, Jayce",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "78298614-3c9f-4c69-928a-4f46b35bb9f1",
          "sportradar_id": "78298614-3c9f-4c69-928a-4f46b35bb9f1",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "78298614-3c9f-4c69-928a-4f46b35bb9f1",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Florida Panthers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4418464d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3687",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "13",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "4c77da1b-2d58-49e6-aa18-0aa220f5692d",
      "created": "2019-02-27T15:17:42+00:00",
      "updated": "2019-02-27T15:33:48+00:00",
      "title": "Nikolay Goldobin",
      "description": "NHL: Vancouver Canucks at New York Rangers",
      "player_id": "a52725c7-a7c5-4f4d-ad09-b162ba43466f",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/4c77da1b-2d58-49e6-aa18-0aa220f5692d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Goldobin, Nikolay",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "a52725c7-a7c5-4f4d-ad09-b162ba43466f",
          "sportradar_id": "a52725c7-a7c5-4f4d-ad09-b162ba43466f",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "a52725c7-a7c5-4f4d-ad09-b162ba43466f",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:606986",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477958",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New York Rangers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441781b9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441781b9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3701",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "3",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "1deda87e-f66a-4440-85ed-5edf8504f272",
      "created": "2019-02-27T15:16:54+00:00",
      "updated": "2019-03-05T20:24:00+00:00",
      "title": "Erik Cernak",
      "description": "Dec 10, 2018; Tampa, FL, USA; Tampa Bay Lightning defenseman Erik Cernak (81) fights New York Rangers left wing during the third period at Amalie Arena. Mandatory Credit: Kim Klement-USA TODAY Sports",
      "player_id": "3d823a1b-f9e4-4bfb-a8c4-641b17c4eecc",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/1deda87e-f66a-4440-85ed-5edf8504f272/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Cernak, Erik",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "3d823a1b-f9e4-4bfb-a8c4-641b17c4eecc",
          "sportradar_id": "3d823a1b-f9e4-4bfb-a8c4-641b17c4eecc",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "3d823a1b-f9e4-4bfb-a8c4-641b17c4eecc",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:895816",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478416",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Tampa Bay Lightning",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417d3cb-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417d3cb-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3694",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "14",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820",
      "created": "2019-02-27T15:17:26+00:00",
      "updated": "2019-03-05T20:12:12+00:00",
      "title": "Kenny Agostino",
      "description": "Nov 24, 2018; Montreal, Quebec, CAN; Montreal Canadiens left wing Kenny Agostino (47) during the warm-up session before the game against Boston Bruins at Bell Centre. Mandatory Credit: Jean-Yves Ahern-USA TODAY Sports",
      "player_id": "c24c315f-dd0e-4bcc-abd7-c037d5cb67ee",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/c0bd1e9a-3ef4-49a8-a4e9-1a14e509b820/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Agostino, Kenny",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c24c315f-dd0e-4bcc-abd7-c037d5cb67ee",
          "sportradar_id": "c24c315f-dd0e-4bcc-abd7-c037d5cb67ee",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c24c315f-dd0e-4bcc-abd7-c037d5cb67ee",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:548612",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8475844",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Montreal Canadiens",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441713b7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441713b7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3690",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "a28830a3-0685-4d64-bd97-a863ce54ca68",
      "created": "2019-02-27T15:16:51+00:00",
      "updated": "2019-02-27T15:24:56+00:00",
      "title": "Mikko Koskinen",
      "description": "NHL: Edmonton Oilers at Colorado Avalanche",
      "player_id": "75f9099e-b1e0-4aef-a754-dc972cece876",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/a28830a3-0685-4d64-bd97-a863ce54ca68/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Koskinen, Mikko",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "75f9099e-b1e0-4aef-a754-dc972cece876",
          "sportradar_id": "75f9099e-b1e0-4aef-a754-dc972cece876",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "75f9099e-b1e0-4aef-a754-dc972cece876",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:42605",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8475156",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Edmonton Oilers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ea6c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3686",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "22",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "bc3c309a-a412-4207-9577-5d99141f3d5e",
      "created": "2019-02-27T15:16:30+00:00",
      "updated": "2019-03-05T20:33:10+00:00",
      "title": "Carter Hart",
      "description": "Jan 5, 2019; Philadelphia, PA, USA; Philadelphia Flyers goaltender Carter Hart (79) in a game against the Calgary Flames at Wells Fargo Center. Mandatory Credit: Bill Streicher-USA TODAY Sports",
      "player_id": "104295a8-ec3a-46c2-bd03-b252d119a5b7",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 1426,
          "width": 1427,
          "href": "/headshots/players/bc3c309a-a412-4207-9577-5d99141f3d5e/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Hart, Carter",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "104295a8-ec3a-46c2-bd03-b252d119a5b7",
          "sportradar_id": "104295a8-ec3a-46c2-bd03-b252d119a5b7",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "104295a8-ec3a-46c2-bd03-b252d119a5b7",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:983671",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479394",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Philadelphia Flyers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44179d47-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44179d47-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44179d47-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3699",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "4",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "178266fb-267e-445a-9e4b-9bbc9184ea8f",
      "created": "2019-02-27T15:18:39+00:00",
      "updated": "2019-03-05T15:23:44+00:00",
      "title": "Thatcher Demko",
      "description": "Sep 19, 2018; Vancouver, British Columbia, CAN; Vancouver Canucks goaltender Thatcher Demko (35) awaits the start of play against the Calgary Flames during the second period at Rogers Arena. Mandatory Credit: Anne-Marie Sorvin-USA TODAY Sports",
      "player_id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 981,
          "width": 982,
          "href": "/headshots/players/178266fb-267e-445a-9e4b-9bbc9184ea8f/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Demko, Thatcher",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
          "sportradar_id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:985225",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477967",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Vancouver Canucks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415b0a7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3692",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "23",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e",
      "created": "2019-02-27T15:17:00+00:00",
      "updated": "2019-03-05T20:21:35+00:00",
      "title": "Jordan Kyrou",
      "description": "Dec 9, 2018; St. Louis, MO, USA; St. Louis Blues center Jordan Kyrou (33) celebrates after scoring his first career goal during the third period against the Vancouver Canucks at Enterprise Center. Mandatory Credit: Jeff Curry-USA TODAY Sports",
      "player_id": "2777030d-6d3c-47f0-92ea-1849f82219c0",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 819,
          "width": 818,
          "href": "/headshots/players/fc16c756-ed17-4fec-a3d1-fbb5a6d8b65e/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Kyrou, Jordan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "2777030d-6d3c-47f0-92ea-1849f82219c0",
          "sportradar_id": "2777030d-6d3c-47f0-92ea-1849f82219c0",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "2777030d-6d3c-47f0-92ea-1849f82219c0",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:983709",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8479385",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "St. Louis Blues",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441660ea-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3695",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "19",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "af50d79e-630f-435d-a743-53cf3801f35d",
      "created": "2019-02-27T15:16:24+00:00",
      "updated": "2019-03-05T20:35:43+00:00",
      "title": "Joseph Gambardella",
      "description": "Jan 12, 2019; Edmonton, Alberta, CAN; Edmonton Oilers forward Joseph Gambardella (45) skates during warmup against the Arizona Coyotes at Rogers Place. Mandatory Credit: Perry Nelson-USA TODAY Sports",
      "player_id": "c7ade79d-d0fe-4c9f-889c-ea47ef8ad2c1",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 1004,
          "width": 1004,
          "href": "/headshots/players/af50d79e-630f-435d-a743-53cf3801f35d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Gambardella, Joe",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c7ade79d-d0fe-4c9f-889c-ea47ef8ad2c1",
          "sportradar_id": "c7ade79d-d0fe-4c9f-889c-ea47ef8ad2c1",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c7ade79d-d0fe-4c9f-889c-ea47ef8ad2c1",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Edmonton Oilers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ea6c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3686",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "22",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "b5678a85-59ed-4743-85d5-f3c8b14b0731",
      "created": "2019-02-27T15:16:23+00:00",
      "updated": "2019-03-05T20:36:50+00:00",
      "title": "Rudolfs Balcers",
      "description": "Jan 12, 2019; San Jose, CA, USA; Ottawa Senators left wing Rudolfs Balcers (38) in the first period at SAP Center at San Jose. Mandatory Credit: John Hefti-USA TODAY Sports",
      "player_id": "1c8194fb-52fe-4edc-afbc-b3aff1f370a3",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 556,
          "width": 556,
          "href": "/headshots/players/b5678a85-59ed-4743-85d5-f3c8b14b0731/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Balcers, Rudolfs",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "1c8194fb-52fe-4edc-afbc-b3aff1f370a3",
          "sportradar_id": "1c8194fb-52fe-4edc-afbc-b3aff1f370a3",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "1c8194fb-52fe-4edc-afbc-b3aff1f370a3",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:907728",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478870",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Ottawa Senators",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416f5e2-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3700",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "9",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "252d65f0-faa5-4818-b340-3b0fbbeee9b9",
      "created": "2019-02-27T15:18:41+00:00",
      "updated": "2019-02-27T23:29:00+00:00",
      "title": "Anders Nilsson",
      "description": "NHL: Edmonton Oilers at Vancouver Canucks",
      "player_id": "432bad7b-0f24-11e2-8525-18a905767e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 962,
          "width": 962,
          "href": "/headshots/players/252d65f0-faa5-4818-b340-3b0fbbeee9b9/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Nilsson, Anders",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "432bad7b-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "432bad7b-0f24-11e2-8525-18a905767e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "432bad7b-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:90755",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8475195",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Vancouver Canucks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415b0a7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3692",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "23",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "25da2f25-1254-4e87-bc76-f51edbf1e19d",
      "created": "2019-02-27T15:16:25+00:00",
      "updated": "2019-03-05T20:36:20+00:00",
      "title": "Devon Toews",
      "description": "Jan 12, 2019; Brooklyn, NY, USA; New York Islanders defenseman Devon Toews (25) during the third period at Barclays Center. Mandatory Credit: Brad Penner-USA TODAY Sports",
      "player_id": "588ccf22-c00e-4248-ac25-990991e08680",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 585,
          "width": 585,
          "href": "/headshots/players/25da2f25-1254-4e87-bc76-f51edbf1e19d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Toews, Devon",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "588ccf22-c00e-4248-ac25-990991e08680",
          "sportradar_id": "588ccf22-c00e-4248-ac25-990991e08680",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "588ccf22-c00e-4248-ac25-990991e08680",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:984023",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478038",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New York Islanders",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441766b9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441766b9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441766b9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3703",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "2",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "c28e83ea-d56e-47a9-b6c5-a9520d9ace48",
      "created": "2019-02-27T15:16:32+00:00",
      "updated": "2019-03-05T20:34:04+00:00",
      "title": "Roope Hintz",
      "description": "Jan 4, 2019; Dallas, TX, USA; Dallas Stars left wing Roope Hintz (24) in action during the game between the Stars and the Capitals at the American Airlines Center. Mandatory Credit: Jerome Miron-USA TODAY Sports",
      "player_id": "2f613430-45b9-462c-bd6a-cded28a7f8af",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 773,
          "width": 773,
          "href": "/headshots/players/c28e83ea-d56e-47a9-b6c5-a9520d9ace48/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Hintz, Roope",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "2f613430-45b9-462c-bd6a-cded28a7f8af",
          "sportradar_id": "2f613430-45b9-462c-bd6a-cded28a7f8af",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "2f613430-45b9-462c-bd6a-cded28a7f8af",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:350640",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478449",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Dallas Stars",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44157522-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44157522-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44157522-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3684",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "25",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "5e88e579-0494-4e03-9baa-cc90a62b9901",
      "created": "2019-02-27T15:18:35+00:00",
      "updated": "2019-03-05T15:27:16+00:00",
      "title": "Sami Niku",
      "description": "Sep 20, 2018; Edmonton, Alberta, CAN; Winnipeg Jets defensemen Sami Niku (83) during the first period at Rogers Place. Mandatory Credit: Perry Nelson-USA TODAY Sports",
      "player_id": "e0d9e044-f942-48ce-b16d-45c32e1bd7df",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 594,
          "width": 594,
          "href": "/headshots/players/5e88e579-0494-4e03-9baa-cc90a62b9901/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Niku, Sami",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "e0d9e044-f942-48ce-b16d-45c32e1bd7df",
          "sportradar_id": "e0d9e044-f942-48ce-b16d-45c32e1bd7df",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "e0d9e044-f942-48ce-b16d-45c32e1bd7df",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:599778",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478915",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Winnipeg Jets",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44180e55-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44180e55-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44180e55-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3676",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "52",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "3504e77f-2479-4c21-8325-142b1d16ee4e",
      "created": "2019-02-27T15:17:51+00:00",
      "updated": "2019-03-05T15:46:00+00:00",
      "title": "Sheldon Dries",
      "description": "Nov 7, 2018; Denver, CO, USA; Colorado Avalanche center Sheldon Dries (15) chases down a loose puck on a breakaway in the second period against the Nashville Predators at the Pepsi Center. Mandatory Credit: Isaiah J. Downing-USA TODAY Sports",
      "player_id": "3268b09c-d07e-494b-bcd7-035fc5982f4a",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 289,
          "width": 289,
          "href": "/headshots/players/3504e77f-2479-4c21-8325-142b1d16ee4e/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Dries, Sheldon",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "3268b09c-d07e-494b-bcd7-035fc5982f4a",
          "sportradar_id": "3268b09c-d07e-494b-bcd7-035fc5982f4a",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "3268b09c-d07e-494b-bcd7-035fc5982f4a",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Colorado Avalanche",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ce44-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3682",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "21",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7",
      "created": "2019-02-27T15:16:40+00:00",
      "updated": "2019-03-05T20:26:01+00:00",
      "title": "Marcus Hogberg",
      "description": "Dec 29, 2018; Ottawa, Ontario, CAN; Ottawa Senators goalie Marcus Hogberg (1) in the first period at the Canadian Tire Centre. Mandatory Credit: Marc DesRosiers-USA TODAY Sports",
      "player_id": "470d563a-f58a-4e0d-b7e8-592cb9fa6b40",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 1376,
          "width": 1376,
          "href": "/headshots/players/e7736c03-cf7d-41a8-830c-b3c7dcf9c7c7/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Hogberg, Marcus",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "470d563a-f58a-4e0d-b7e8-592cb9fa6b40",
          "sportradar_id": "470d563a-f58a-4e0d-b7e8-592cb9fa6b40",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "470d563a-f58a-4e0d-b7e8-592cb9fa6b40",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Ottawa Senators",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416f5e2-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3700",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "9",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "ee159a2e-9475-4083-a0a6-74f9bfe5a49d",
      "created": "2019-02-27T15:18:43+00:00",
      "updated": "2019-02-27T23:29:40+00:00",
      "title": "Michael Dal Colle",
      "description": "NHL: Preseason-New York Islanders at Philadelphia Flyers",
      "player_id": "3a9848b1-a6c4-4f40-9a5f-7e42f9faea76",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 862,
          "width": 861,
          "href": "/headshots/players/ee159a2e-9475-4083-a0a6-74f9bfe5a49d/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Dal Colle, Michael",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "3a9848b1-a6c4-4f40-9a5f-7e42f9faea76",
          "sportradar_id": "3a9848b1-a6c4-4f40-9a5f-7e42f9faea76",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "3a9848b1-a6c4-4f40-9a5f-7e42f9faea76",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:906466",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477936",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New York Islanders",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441766b9-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441766b9-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441766b9-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3703",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "2",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "2ec5cc0f-7652-4ac8-b3a1-2575765549a1",
      "created": "2019-02-27T15:16:29+00:00",
      "updated": "2019-03-05T20:34:37+00:00",
      "title": "Christian Wolanin",
      "description": "Jan 6, 2019; Ottawa, Ontario, CAN; Ottawa Senators defenseman Christian Wolanin (86) skates with the puck in the first period against the Carolina Hurricanes at the Canadian Tire Centre. Mandatory Credit: Marc DesRosiers-USA TODAY Sports",
      "player_id": "4c1b294b-f615-4129-a236-c0cb0722202b",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 251,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 301,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 436,
          "width": 435,
          "href": "/headshots/players/2ec5cc0f-7652-4ac8-b3a1-2575765549a1/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Wolanin, Christian",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "4c1b294b-f615-4129-a236-c0cb0722202b",
          "sportradar_id": "4c1b294b-f615-4129-a236-c0cb0722202b",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4c1b294b-f615-4129-a236-c0cb0722202b",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1214834",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8478846",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Ottawa Senators",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4416f5e2-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4416f5e2-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3700",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "9",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "035ca39e-46b9-4f3a-aedb-f965d19ba4fe",
      "created": "2019-02-27T15:16:33+00:00",
      "updated": "2019-03-05T20:32:30+00:00",
      "title": "Jonas Siegenthaler",
      "description": "Jan 4, 2019; Dallas, TX, USA; Washington Capitals defenseman Jonas Siegenthaler (34) in action during the game between the Stars and the Capitals at the American Airlines Center. Mandatory Credit: Jerome Miron-USA TODAY Sports",
      "player_id": "b2b1b4c3-fe22-4bf9-beb7-49c716b278de",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 1002,
          "width": 1002,
          "href": "/headshots/players/035ca39e-46b9-4f3a-aedb-f965d19ba4fe/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Siegenthaler, Jonas",
          "type": "profile",
          "sport": "NHL",
          "sportsdata_id": "b2b1b4c3-fe22-4bf9-beb7-49c716b278de",
          "sportradar_id": "b2b1b4c3-fe22-4bf9-beb7-49c716b278de",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "b2b1b4c3-fe22-4bf9-beb7-49c716b278de",
              "sport": "NHL"
            },
            {
              "origin": "SR",
              "id": "sr:player:601678",
              "sport": "NHL"
            },
            {
              "origin": "NHL",
              "id": "8478399",
              "sport": "NHL"
            }
          ]
        },
        {
          "name": "Washington Capitals",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417eede-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417eede-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417eede-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3691",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "15",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "3d0744ec-7345-4451-bc32-8c052f8b8735",
      "created": "2019-02-27T15:16:28+00:00",
      "updated": "2019-02-27T15:20:38+00:00",
      "title": "Jordan Binnington",
      "description": "NHL: St. Louis Blues at Philadelphia Flyers",
      "player_id": "f997ad4a-b491-4dbd-be40-4c449e44ce9f",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 809,
          "width": 808,
          "href": "/headshots/players/3d0744ec-7345-4451-bc32-8c052f8b8735/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Binnington, Jordan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "f997ad4a-b491-4dbd-be40-4c449e44ce9f",
          "sportradar_id": "f997ad4a-b491-4dbd-be40-4c449e44ce9f",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "f997ad4a-b491-4dbd-be40-4c449e44ce9f",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:779552",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8476412",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "St. Louis Blues",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441660ea-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3695",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "19",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "074767ce-c74c-451d-b88a-1c6bde0cb438",
      "created": "2019-02-27T15:16:42+00:00",
      "updated": "2019-03-05T20:29:33+00:00",
      "title": "Mackenzie Blackwood",
      "description": "Dec 18, 2018; Newark, NJ, USA; New Jersey Devils goaltender Mackenzie Blackwood (29) during a break in the third period of their game against the Toronto Maple Leafs at Prudential Center. Mandatory Credit: Ed Mulholland-USA TODAY Sports",
      "player_id": "f56821c8-856e-4c72-affd-3dbbba69b379",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 676,
          "width": 676,
          "href": "/headshots/players/074767ce-c74c-451d-b88a-1c6bde0cb438/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Blackwood, Mackenzie",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "f56821c8-856e-4c72-affd-3dbbba69b379",
          "sportradar_id": "f56821c8-856e-4c72-affd-3dbbba69b379",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "f56821c8-856e-4c72-affd-3dbbba69b379",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New Jersey Devils",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44174b0c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3704",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "1",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "c27319be-102a-4d74-addf-730b58a728c1",
      "created": "2019-02-27T15:16:38+00:00",
      "updated": "2019-02-27T15:23:07+00:00",
      "title": "Sean Walker",
      "description": "NHL: Los Angeles Kings at Vegas Golden Knights",
      "player_id": "ac354a49-0807-4179-b0f3-e57bf2af1aa2",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 359,
          "width": 359,
          "href": "/headshots/players/c27319be-102a-4d74-addf-730b58a728c1/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Walker, Sean",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "ac354a49-0807-4179-b0f3-e57bf2af1aa2",
          "sportradar_id": "ac354a49-0807-4179-b0f3-e57bf2af1aa2",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "ac354a49-0807-4179-b0f3-e57bf2af1aa2",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:1213672",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8480336",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Los Angeles Kings",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44151f7a-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44151f7a-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3688",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "26",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8d0ca404-0435-4480-8eeb-1eaa7c47d8fe",
      "created": "2019-02-27T15:18:38+00:00",
      "updated": "2019-03-05T15:25:04+00:00",
      "title": "Thatcher Demko",
      "description": "Sep 19, 2018; Vancouver, British Columbia, CAN; Vancouver Canucks goaltender Thatcher Demko (35) awaits the start of play against the Calgary Flames during the second period at Rogers Arena. Mandatory Credit: Anne-Marie Sorvin-USA TODAY Sports",
      "player_id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 1208,
          "width": 1208,
          "href": "/headshots/players/8d0ca404-0435-4480-8eeb-1eaa7c47d8fe/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Demko, Thatcher",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
          "sportradar_id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4b2e0ce3-a2fd-4a0a-8001-21f599d3d41c",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:985225",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477967",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Vancouver Canucks",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415b0a7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415b0a7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3692",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "23",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "c251d862-0808-4272-a694-4167415faf93",
      "created": "2019-02-27T15:18:33+00:00",
      "updated": "2019-03-05T15:28:33+00:00",
      "title": "Ryan Graves",
      "description": "Sep 22, 2018; Saint Paul, MN, USA; Colorado Avalanche defenseman Ryan Graves (27) defends during the third period against Minnesota Wild at Xcel Energy Center. Mandatory Credit: Brace Hemmelgarn-USA TODAY Sports",
      "player_id": "d1d9d464-b904-49d1-a9ef-9e5b6e312a85",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 548,
          "width": 548,
          "href": "/headshots/players/c251d862-0808-4272-a694-4167415faf93/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Graves, Ryan",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "d1d9d464-b904-49d1-a9ef-9e5b6e312a85",
          "sportradar_id": "d1d9d464-b904-49d1-a9ef-9e5b6e312a85",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "d1d9d464-b904-49d1-a9ef-9e5b6e312a85",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:906454",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477435",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Colorado Avalanche",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ce44-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ce44-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3682",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "21",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "69730554-327e-4364-b0e0-9b3cf5e218fd",
      "created": "2019-02-27T15:16:27+00:00",
      "updated": "2019-03-05T20:35:08+00:00",
      "title": "Saku Maenalanen",
      "description": "Jan 8, 2019; Uniondale, NY, USA; Carolina Hurricanes right wing Saku Maenalanen (8) during the first period at Nassau Veterans Memorial Coliseum. Mandatory Credit: Brad Penner-USA TODAY Sports",
      "player_id": "2c4bc234-569e-47f3-b405-6a0f8b4d7790",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 798,
          "width": 798,
          "href": "/headshots/players/69730554-327e-4364-b0e0-9b3cf5e218fd/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Maenalanen, Saku",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "2c4bc234-569e-47f3-b405-6a0f8b4d7790",
          "sportradar_id": "2c4bc234-569e-47f3-b405-6a0f8b4d7790",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "2c4bc234-569e-47f3-b405-6a0f8b4d7790",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:player:350766",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "8477357",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Carolina Hurricanes",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44182a9d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44182a9d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3680",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "12",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "f6c1b0e8-d448-4c93-9505-7395d7f362f5",
      "created": "2019-02-27T15:16:44+00:00",
      "updated": "2019-03-05T20:31:36+00:00",
      "title": "Mackenzie Blackwood",
      "description": "Dec 18, 2018; Newark, NJ, USA; New Jersey Devils goaltender Mackenzie Blackwood (29) during a break in the third period of their game against the Toronto Maple Leafs at Prudential Center. Mandatory Credit: Ed Mulholland-USA TODAY Sports",
      "player_id": "f56821c8-856e-4c72-affd-3dbbba69b379",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 564,
          "width": 564,
          "href": "/headshots/players/f6c1b0e8-d448-4c93-9505-7395d7f362f5/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Blackwood, Mackenzie",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "f56821c8-856e-4c72-affd-3dbbba69b379",
          "sportradar_id": "f56821c8-856e-4c72-affd-3dbbba69b379",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "f56821c8-856e-4c72-affd-3dbbba69b379",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "New Jersey Devils",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44174b0c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44174b0c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3704",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "1",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "88c8f877-e080-42aa-97aa-c4288e9b19b4",
      "created": "2019-02-27T15:16:22+00:00",
      "updated": "2019-03-05T20:38:14+00:00",
      "title": "Kevin Stenlund",
      "description": "Jan 18, 2019; Columbus, OH, USA; Columbus Blue Jackets center Kevin Stenlund (11) against the Montreal Canadiens during the second period at Nationwide Arena. Mandatory Credit: Russell LaBounty-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 251,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 301,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 319,
          "width": 318,
          "href": "/headshots/players/88c8f877-e080-42aa-97aa-c4288e9b19b4/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Columbus Blue Jackets",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "44167db4-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "44167db4-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "44167db4-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3683",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "29",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "8b88d0f4-3480-4848-8a6a-c4847f7c372c",
      "created": "2019-02-27T15:16:18+00:00",
      "updated": "2019-03-05T20:40:26+00:00",
      "title": "Alex Petrovich",
      "description": "Jan 22, 2019; Edmonton, Alberta, CAN; Edmonton Oilers defensemen Alex Petrovich (15) skates during the first period against the Detroit Red Wings at Rogers Place. Mandatory Credit: Perry Nelson-USA TODAY Sports",
      "player_id": null,
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/8b88d0f4-3480-4848-8a6a-c4847f7c372c/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Edmonton Oilers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4415ea6c-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4415ea6c-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3686",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "22",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "84cc56eb-593d-49cc-8597-0aa5a772d9f2",
      "created": "2019-02-27T15:16:16+00:00",
      "updated": "2019-03-05T20:41:01+00:00",
      "title": "Teddy Blueger",
      "description": "Feb 1, 2019; Pittsburgh, PA, USA;  Pittsburgh Penguins center Teddy Blueger (53) reacts after being named a star of the game against the Ottawa Senators at PPG PAINTS Arena. Mandatory Credit: Charles LeClaire-USA TODAY Sports",
      "player_id": "c3e46622-db0d-4983-9f48-31265dd5d520",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/84cc56eb-593d-49cc-8597-0aa5a772d9f2/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Blueger, Teddy",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c3e46622-db0d-4983-9f48-31265dd5d520",
          "sportradar_id": "c3e46622-db0d-4983-9f48-31265dd5d520",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c3e46622-db0d-4983-9f48-31265dd5d520",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Pittsburgh Penguins",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4417b7d7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4417b7d7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3697",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "5",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "6c677ac9-8d12-49c4-8b65-2c3e799a916a",
      "created": "2019-02-27T15:18:26+00:00",
      "updated": "2019-03-05T15:30:59+00:00",
      "title": "Jake Bischoff",
      "description": "Sep 24, 2018; Las Vegas, NV, USA; Vegas Golden Knights defenseman Jake Bischoff (45) looks on during a third period face off against the Colorado Avalanche at T-Mobile Arena. Mandatory Credit: Stephen R. Sylvanie-USA TODAY Sports",
      "player_id": "fdb7cebb-56f8-4ff3-ba47-b6b3d55cda40",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/6c677ac9-8d12-49c4-8b65-2c3e799a916a/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Bischoff, Jake",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "fdb7cebb-56f8-4ff3-ba47-b6b3d55cda40",
          "sportradar_id": "fdb7cebb-56f8-4ff3-ba47-b6b3d55cda40",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "fdb7cebb-56f8-4ff3-ba47-b6b3d55cda40",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Vegas Golden Knights",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "42376e1c-6da8-461e-9443-cfcf0a9fcc4d",
          "sportradar_id": "42376e1c-6da8-461e-9443-cfcf0a9fcc4d",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "42376e1c-6da8-461e-9443-cfcf0a9fcc4d",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:344158",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "54",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "bd8ddffd-a815-40af-88f0-e1902dc79b6e",
      "created": "2019-02-27T15:16:17+00:00",
      "updated": "2019-02-27T15:19:42+00:00",
      "title": "Josh Brown",
      "description": "NHL: Nashville Predators at Florida Panthers",
      "player_id": "c0160584-e90b-4ee8-a742-a6d166d30f84",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/bd8ddffd-a815-40af-88f0-e1902dc79b6e/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Brown, Josh",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "c0160584-e90b-4ee8-a742-a6d166d30f84",
          "sportradar_id": "c0160584-e90b-4ee8-a742-a6d166d30f84",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "c0160584-e90b-4ee8-a742-a6d166d30f84",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Florida Panthers",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "4418464d-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "4418464d-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3687",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "13",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "fbb16a81-c2e0-459b-abeb-feab84f8a962",
      "created": "2019-02-27T15:16:20+00:00",
      "updated": "2019-03-05T20:39:43+00:00",
      "title": "Colin Blackwell",
      "description": "Jan 21, 2019; Denver, CO, USA; Nashville Predators center Colin Blackwell (42) controls the puck in the second period against the Colorado Avalanche at the Pepsi Center. Mandatory Credit: Ron Chenoy-USA TODAY Sports",
      "player_id": "02e4f5ea-5832-4577-953d-3ad73e64e0e0",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/fbb16a81-c2e0-459b-abeb-feab84f8a962/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "Blackwell, Colin",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "02e4f5ea-5832-4577-953d-3ad73e64e0e0",
          "sportradar_id": "02e4f5ea-5832-4577-953d-3ad73e64e0e0",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "02e4f5ea-5832-4577-953d-3ad73e64e0e0",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "Nashville Predators",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441643b7-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441643b7-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441643b7-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3705",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "18",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    },
    {
      "id": "e5c759ee-3cc1-428d-ad88-52f52aa8987e",
      "created": "2019-02-27T15:16:21+00:00",
      "updated": "2019-03-05T20:39:07+00:00",
      "title": "Mackenzie MacEachern",
      "description": "Jan 19, 2019; St. Louis, MO, USA; St. Louis Blues left wing Mackenzie MacEachern (62) skates with the puck during warmups prior to a game against the Ottawa Senators at Enterprise Center. Mandatory Credit: Joe Puetz-USA TODAY Sports",
      "player_id": "9f03396a-8c50-4716-897f-70fd96ea9e44",
      "copyright": "USA Today Sports Images",
      "posed=": false,
      "links": [
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/250w-resize.jpg"
        },
        {
          "width": 205,
          "height": 205,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/205x205-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/90x90-crop.jpg"
        },
        {
          "width": 250,
          "height": 250,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/250x250-crop.jpg"
        },
        {
          "width": 195,
          "height": 270,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/195x270-crop.jpg"
        },
        {
          "width": 940,
          "height": 940,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/940x940-crop.jpg"
        },
        {
          "width": 200,
          "height": 300,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/200x300-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/160x160-crop.jpg"
        },
        {
          "width": 160,
          "height": 160,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/160x160-crop.jpg"
        },
        {
          "width": 135,
          "height": 135,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/135x135-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/300x300-crop.jpg"
        },
        {
          "width": 600,
          "height": 600,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/600x600-crop.jpg"
        },
        {
          "width": 705,
          "height": 705,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/705x705-crop.jpg"
        },
        {
          "width": 150,
          "height": 150,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/150x150-crop.jpg"
        },
        {
          "width": 820,
          "height": 820,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/820x820-crop.jpg"
        },
        {
          "width": 40,
          "height": 40,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/40x40-crop.jpg"
        },
        {
          "width": 60,
          "height": 60,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/60x60-crop.jpg"
        },
        {
          "width": 615,
          "height": 615,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/615x615-crop.jpg"
        },
        {
          "width": 235,
          "height": 235,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/235x235-crop.jpg"
        },
        {
          "width": 450,
          "height": 450,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/450x450-crop.jpg"
        },
        {
          "width": 470,
          "height": 470,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/470x470-crop.jpg"
        },
        {
          "width": 240,
          "height": 240,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/240x240-crop.jpg"
        },
        {
          "width": 90,
          "height": 90,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/90x90-crop.jpg"
        },
        {
          "width": 120,
          "height": 120,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/120x120-crop.jpg"
        },
        {
          "width": 80,
          "height": 80,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/80x80-crop.jpg"
        },
        {
          "width": 45,
          "height": 45,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/45x45-crop.jpg"
        },
        {
          "width": 180,
          "height": 180,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/180x180-crop.jpg"
        },
        {
          "width": 410,
          "height": 410,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/410x410-crop.jpg"
        },
        {
          "width": 300,
          "height": 300,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/300w-resize.jpg"
        },
        {
          "type": "original",
          "height": 500,
          "width": 500,
          "href": "/headshots/players/e5c759ee-3cc1-428d-ad88-52f52aa8987e/original.jpg"
        }
      ],
      "refs": [
        {
          "name": "MacEachern, Mackenzie",
          "type": "profile",
          "sport": "nhl",
          "sportsdata_id": "9f03396a-8c50-4716-897f-70fd96ea9e44",
          "sportradar_id": "9f03396a-8c50-4716-897f-70fd96ea9e44",
          "primary": true,
          "entity_ids": [
            {
              "origin": "SD",
              "id": "9f03396a-8c50-4716-897f-70fd96ea9e44",
              "sport": "nhl"
            }
          ]
        },
        {
          "name": "St. Louis Blues",
          "type": "organization",
          "sport": "nhl",
          "sportsdata_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "sportradar_id": "441660ea-0f24-11e2-8525-18a905767e44",
          "entity_ids": [
            {
              "origin": "SD",
              "id": "441660ea-0f24-11e2-8525-18a905767e44",
              "sport": "nhl"
            },
            {
              "origin": "SR",
              "id": "sr:team:3695",
              "sport": "nhl"
            },
            {
              "origin": "NHL",
              "id": "19",
              "sport": "nhl"
            }
          ]
        }
      ],
      "links=": [
        
      ]
    }
  ];
	(assetlist).forEach(function(playeData){
		req.body.league	=	"NHL";
		req.body.asset	=	"https://api.sportradar.us/nhl-images-t3/usat"+playeData.links[26]['href']+"?api_key=bfw7wd7f29e4rsrntwmgqb2m";
		req.body.asset_id	=	playeData.id;
		req.body.player_id	=	playeData.player_id;
		req.body.player_name	=	playeData.title;
		console.log(playeData.player_id);
		var playerImage = new PlayerImage(req.body);
		playerImage.save(function(err, player) {
			
			console.log(err);
		});
	});
    
});
router.get('/downloadplayer', (req, res) => {
	PlayerImage.find({league:"NHL"}).exec( function (err, playeData) {
    dt.processPlayerArray(playeData);
		//(leadersList).forEach(function(playeData){

			/*var dir  =  "/sportsApp/public/upload/player/"+playeData.asset_id;
			const options = {
				 // url: 'https://trenogmat.no/img/fd685c36-72a4-4cfe-9e2b-39093afe0ae9-90x90-crop.JPG',
				  url: playeData.asset,
				  dest: dir                  
			}
			if (!fs.existsSync(dir) ) {
	          fs.mkdirSync(dir);
			      dt.downloadimg(options);
 
			}*/
			/*if (!fs.existsSync(dir) ) {
              	fs.mkdirSync(dir);
               var options = {
                  url: "https://trenogmat.no/img/fd685c36-72a4-4cfe-9e2b-39093afe0ae9-90x90-crop.JPG",
                 // url: playeData.asset,
                  dest: dir               
                };
               console.log(options);
	               
            download.image(options)
                .then(({ filename, image }) => {
                  console.log('File saved to', filename);
                })
                .catch((err) => {
                   console.log('File Error',err);
                 // return false;
                })
	                
	                
            }*/
	//	})
		
	})
})
module.exports = router;