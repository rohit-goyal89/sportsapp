var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment'),
	FUNC = require('../lib/function'),
	async = require('async'),
	NflLeaders = require('../models/nflleaders');
var formidable = require('formidable');
var fs = require('fs');	
var download = require('image-downloader');
var mongoose = require('mongoose');
var dt = require('../lib/function');

router.get('/getleaders/:week', (req, res) => {
	var response = {};

 	var feed_url		=	"http://api.sportradar.us/nfl-t1/2018/REG/"+req.params.week+"/leaders.json?api_key=b4e4pxhc5538wgbygfqgz5yt";
	NflLeaders.remove({week:req.params.week}).then((scoredel) => { 
		request(feed_url, { json: true }, (err, response, nflleadBody) => {
			if(nflleadBody.passing){
				nflPassing	=	[];
				(nflleadBody.passing).forEach(function(nfllead){ 
					passingObj	=	{};
					passingObj.week	=	req.params.week;
					passingObj.nfl_type	=	"Passing";
					passingObj.nfl_type_slug	=	"passing";
					passingObj.player_id	=	nfllead.id;
					passingObj.player_name	=	nfllead.name;
					passingObj.position	=	nfllead.position;
					passingObj.att	= nfllead.att;
					passingObj.cmp	= nfllead.cmp;
					passingObj.yds	= nfllead.yds;
					passingObj.lg	= nfllead.lg;
					passingObj.sk	= nfllead.sk;
					passingObj.sk_yds	= nfllead.sk_yds;
					passingObj.td	= nfllead.td;
					passingObj.int	= nfllead.int;
					passingObj.int_td	= nfllead.int_td;
					passingObj.fd	= nfllead.fd;
					passingObj.sfty	= nfllead.sfty;
					passingObj.rz_att	= nfllead.rz_att;
					passingObj.rating	= nfllead.rating;
					passingObj.avg	= nfllead.avg;
					passingObj.cmp_pct	= nfllead.cmp_pct;
					passingObj.cmp_avg	= nfllead.cmp_avg;
					passingObj.td_pct	= nfllead.td_pct;
					passingObj.int_pct	= nfllead.int_pct;
					passingObj.yds_10_pls	= nfllead.yds_10_pls;
					passingObj.yds_20_pls	=nfllead.yds_20_pls;
					passingObj.yds_30_pls	=nfllead.yds_30_pls;
					passingObj.yds_40_pls	=nfllead.yds_40_pls;
					passingObj.yds_50_pls	=nfllead.yds_50_pls;
					passingObj.team_name	=nfllead.team.name;
					passingObj.team_market	=nfllead.team.market;
					nflPassing.push(passingObj);
				});
				try {
				 	NflLeaders.insertMany(nflPassing);
	            } catch (err) {
				   console.log(err);
				}
			}

			if(nflleadBody.rushing){
				nflRushing	=	[];
				(nflleadBody.rushing).forEach(function(nfllead){ 
					rushingObj	=	{};
					rushingObj.week	=	req.params.week;
					rushingObj.nfl_type	=	"Rushing";
					rushingObj.nfl_type_slug	=	"rushing";
					rushingObj.player_id	=	nfllead.id;
					rushingObj.player_name	=	nfllead.name;
					rushingObj.position	=	nfllead.position;
					rushingObj.att	=nfllead.att;
					rushingObj.yds	=nfllead.yds;
					rushingObj.avg	=nfllead.avg;
					rushingObj.lg	=nfllead.lg;
					rushingObj.fd	=nfllead.fd;
					rushingObj.fd_pct	=nfllead.fd_pct;
					rushingObj.sfty	=nfllead.sfty;
					rushingObj.td	=nfllead.td;
					rushingObj.rz_att	=nfllead.rz_att;
					rushingObj.fum	=nfllead.fum;
					rushingObj.yds_10_pls	= nfllead.yds_10_pls;
					rushingObj.yds_20_pls	=nfllead.yds_20_pls;
					rushingObj.yds_30_pls	=nfllead.yds_30_pls;
					rushingObj.yds_40_pls	=nfllead.yds_40_pls;
					rushingObj.yds_50_pls	=nfllead.yds_50_pls;
					rushingObj.team_name	=nfllead.team.name;
					rushingObj.team_market	=nfllead.team.market;
					nflRushing.push(rushingObj);
				});
				try {
				 	NflLeaders.insertMany(nflRushing);
	            } catch (err) {
				   console.log(err);
				}
			}
			
			if(nflleadBody.receiving){
				nflReceiving	=	[];
				(nflleadBody.receiving).forEach(function(nfllead){ 
					receivingObj	=	{};
					receivingObj.week	=	req.params.week;
					receivingObj.nfl_type	=	"Receiving";
					receivingObj.nfl_type_slug	=	"receiving";
					receivingObj.player_id	=	nfllead.id;
					receivingObj.player_name	=	nfllead.name;
					receivingObj.position	=	nfllead.position;
					receivingObj.tar	=nfllead.tar;
					receivingObj.rec	=nfllead.rec;
					receivingObj.yds	=nfllead.yds;
					receivingObj.yac	=nfllead.yac;
					receivingObj.yac	=nfllead.yac;
					receivingObj.fd	=nfllead.fd;
					receivingObj.avg	=nfllead.avg;
					receivingObj.td	=nfllead.td;
					receivingObj.lg	=nfllead.lg;
					receivingObj.fum	=nfllead.fum;
					receivingObj.yds_10_pls	=nfllead.yds_10_pls;
					receivingObj.yds_20_pls	=nfllead.yds_20_pls;
					receivingObj.yds_30_pls	=nfllead.yds_30_pls;
					receivingObj.yds_40_pls	=nfllead.yds_40_pls;
					receivingObj.yds_50_pls	=nfllead.yds_50_pls;
					receivingObj.team_name	=nfllead.team.name;
					receivingObj.team_market	=nfllead.team.market;
					nflReceiving.push(receivingObj);
				});
				try {
				 	NflLeaders.insertMany(nflReceiving);
	            } catch (err) {
				   console.log(err);
				}
			}

			if(nflleadBody.field_goal){
				nflfgoal	=	[];
				(nflleadBody.field_goal).forEach(function(nfllead){ 
					fgoalObj	=	{};
					fgoalObj.week	=	req.params.week;
					fgoalObj.nfl_type	=	"Field Goal";
					fgoalObj.nfl_type_slug	=	"field_goal";
					fgoalObj.player_id	=	nfllead.id;
					fgoalObj.player_name	=	nfllead.name;
					fgoalObj.position	=	nfllead.position;
					fgoalObj.att	=		nfllead.att;
					fgoalObj.made	=		nfllead.made;
					fgoalObj.pct	=		nfllead.pct;
					fgoalObj.lg		=		nfllead.lg;
					fgoalObj.blk	=		nfllead.blk;
					fgoalObj.team_name	=nfllead.team.name;
					fgoalObj.team_market	=nfllead.team.market;
					nflfgoal.push(fgoalObj);
				});
				try {
				 	NflLeaders.insertMany(nflfgoal);
	            } catch (err) {
				   console.log(err);
				}
			}

			if(nflleadBody.extra_point){
				nflepoints	=	[];
				(nflleadBody.extra_point).forEach(function(nfllead){ 
					extra_pointObj			=	{};
					extra_pointObj.week		=	req.params.week;
					extra_pointObj.nfl_type	=	"Extra Point";
					extra_pointObj.nfl_type_slug	=	"extra_point";
					extra_pointObj.player_id	=	nfllead.id;
					extra_pointObj.player_name	=	nfllead.name;
					extra_pointObj.position	=	nfllead.position;
					extra_pointObj.att	=nfllead.att;
					extra_pointObj.made	=nfllead.made;
					extra_pointObj.pct	=nfllead.pct;
					extra_pointObj.blk	=nfllead.blk;
					extra_pointObj.team_name	=nfllead.team.name;
					extra_pointObj.team_market	=nfllead.team.market;
					nflepoints.push(extra_pointObj);
				});
				try {
				 	NflLeaders.insertMany(nflepoints);
	            } catch (err) {
				   console.log(err);
				}
			}

		})
		 res.redirect('/leader/NFL');
	})
	
    
})

router.get('/:league', function(req, res) {
	if(req.params.league=="NFL"){
		NflLeaders.aggregate([ {$project:{week:1,player_name:1,nfl_type:1,nfl_type_slug:1,yds:1,made:1,team_name:1,team_market:1,player_id:1}},{
	        "$lookup": {
	            "from": "playerimages", 
	            "localField": "player_id",
	            "foreignField": "player_id",
	            "as": "playerImage"
	        }
    	},{ $group : {_id: {week:"$week",nfl_type: "$nfl_type"},records: { $push: "$$ROOT" } }}, {$sort:{"_id.week":1}}]).exec( function (err, leadersList) {
		   	var leadersdata  =  [];

      if(leadersList.length>0){
	       var j=0;
	       leadersdata[0]  =  [];
	       leadersdata[1]  =  [];
	       leadersdata[2]  =  [];
	       leadersdata[3]  =  [];
	       leadersdata[4]  =  [];
	       leadersdata[5]  =  [];
	       leadersdata[6]  =  [];
	       leadersdata[7]  =  [];
	       leadersdata[8]  =  [];
	       leadersdata[9]  =  [];
	       leadersdata[10]  =  [];
	       leadersdata[11]  =  [];
	       leadersdata[12]  =  [];
	       leadersdata[13]  =  [];
	       leadersdata[14]  =  [];
	       leadersdata[15]  =  [];
	       leadersdata[16]  =  [];
	        leadersList.forEach(function(leadlist) {
						
	    		if(typeof leadlist.records[0].player_id !="undefined"){
					if((leadlist.records[0]['playerImage']).length > 0){
						var dir  =  "/var/sports/public/upload/player/"+leadlist.records[0]['playerImage'][0]['asset_id']+"/90x90-crop.jpg";
						if (fs.existsSync(dir) ) {
							leadlist.records[0].profile_pic  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/player/"+leadlist.records[0]['playerImage'][0]['asset_id']+"/90x90-crop.jpg";
						}else{
							leadlist.records[0].profile_pic  =  "";
						}
						
					}else{
						leadlist.records[0].profile_pic  =  "";
					}
				 
				}else{
					 leadlist.records[0].profile_pic  =  "";
				}
				leadlist.records[0].home_team_logo =  "";
				delete leadlist.records[0]["playerImage"];
	        	//(leadlist.records[0]).splice('playerImage', 1);
	    		if(leadlist._id.week == 1){
	           		(leadersdata[0]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 2){
	            	(leadersdata[1]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 3){
	            	(leadersdata[2]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 4){
	            	(leadersdata[3]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 5){
	            	(leadersdata[4]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 6){
	            	(leadersdata[5]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 7){
	            	(leadersdata[6]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 8){
	           	 (leadersdata[7]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 9){
		            (leadersdata[8]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 10){
		            (leadersdata[9]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 11){
		            (leadersdata[10]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 12){
		            (leadersdata[11]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 13){
		            (leadersdata[12]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 14){
		            (leadersdata[13]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 15){
		            (leadersdata[14]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 16){
		            (leadersdata[15]).push(leadlist.records[0]);
	          	}else if(leadlist._id.week == 17){
		            (leadersdata[16]).push(leadlist.records[0]);
	          	}
	        })
	    	
	      }
	      console.log(leadersdata);
		    res.render('leaders/index', { title: 'NFL League Leaders',leades:leadersdata,league:"NFL" });
		});
	}else if(req.params.league=="NBA"){
		Leaders.aggregate([{$match:{league:req.params.league,rank:1}},{
	        "$lookup": {
	            "from": "playerimages", 
	            "localField": "player_id",
	            "foreignField": "player_id",
	            "as": "playerImage"
	        }
	 	},{ $group : {_id:{categories_type:"$categories_type"},records: { $push:  {  categories_name: "$categories_name",categories_type: "$categories_type", player_id: "$player_id",team_market: "$team_market" , team_name: "$team_name" ,rank: "$rank" ,  avg_points: "$avg_points" ,player_name: "$player_name" , playerImage:"$playerImage" } }}}]).exec( function (err, leades) {
			var leadersArr	=	[];		
			if (leades) {
					
			   (leades).forEach(function(lead) {
				   (lead.records).forEach(function(leadesdata) {
						leadersData	=	{};
						leadersData['categories_name']  =  dt.camelize((leadesdata.categories_name).split('_').join(' '));
						leadersData['categories_type']  =   dt.camelize(leadesdata.categories_type);
						leadersData['player_id']  =  leadesdata.player_id;
						if(typeof leadesdata.player_id !="undefined"){
							if((leadesdata['playerImage']).length > 0){
								var dir  =  "/var/sports/public/upload/player/nba/"+leadesdata['playerImage'][0]['asset_id']+"/120x120-crop.JPG";
								if (fs.existsSync(dir) ) {
									leadersData['player_pic']  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/player/nba/"+leadesdata['playerImage'][0]['asset_id']+"/120x120-crop.JPG";
								}else{
									leadersData['player_pic']  =  "";
								}
								
							}else{
								leadersData['player_pic']  =  "";
							}
						 
						 }else{
							 leadersData['player_pic'] =  "";
						 }
						delete leadersData["playerImage"];
						leadersData['player_name']  =  leadesdata.player_name;
						leadersData['team_market']  =  leadesdata.team_market;
						leadersData['team_name']  =  leadesdata.team_name;
						leadersData['avg_points']  =  leadesdata.avg_points;
						leadersData['rank']  =  leadesdata.rank;
						(leadersArr).push(leadersData);
					})
				   })
					
			  }
		    res.render('leaders/index', { title: 'NBA League Leaders',leades:leadersArr,league:"NBA"  });
		});
	}else if(req.params.league=="NHL"){
		Leaders.aggregate([{$match:{league:req.params.league}},{
	        "$lookup": {
	            "from": "playerimages", 
	            "localField": "player_name",
	            "foreignField": "player_name",
	            "as": "playerImage"
	        }
		},{ $group : {_id:{categories_name:"$categories_name",rank:"$rank"},records: { $push:  {  player_name: "$player_name",categories_type: "$categories_type", categories_name: "$categories_name",team_name: "$team_name", team_market: "$team_market",rank: "$rank", player_id: "$player_id", playerImage:"$playerImage", avg_points: "$score" } }}}, {$sort:{"_id.rank":1}}]).exec( function (err, leades) {
			 
			  		leadersdata  =  [];
			  		if (leades) { 
			           (leades).forEach(function(lead){
			              leading =  {};
			              if(lead.records[0].rank==1){
			          			lead.records[0].categories_type_slug  =  lead.records[0].categories_name;
				              	lead.records[0].categories_type  =   lead.records[0].categories_type;
				        		if(typeof lead.records[0].player_id !="undefined"){
						
									if((lead.records[0].playerImage).length > 0){
										var dir  =  "/var/sports/public/upload/player/nhl/"+lead.records[0].playerImage[0]['asset_id']+"/180x180-crop.jpg";
										if (fs.existsSync(dir) ) {
											lead.records[0].player_pic  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/player/nhl/"+lead.records[0].playerImage[0]['asset_id']+"/180x180-crop.jpg";
										}else{
											lead.records[0].player_pic  =  "";
										}
										
									}else{
										lead.records[0].player_pic  =  "";
									}
								 
								 }else{
									 lead.records[0].player_pic =  "";
								 }
				              	lead.records[0].player_name  =  lead.records[0].player_name;
				              	lead.records[0].team_name  =  lead.records[0].team_name;
									lead.records[0].team_market  =  lead.records[0].team_market;
				              	lead.records[0].score =  lead.records[0].score;
				              	lead.records[0].rank =  lead.records[0].rank;
				              	lead.records[0].games_played =  lead.records[0].games_played;
				    				
				             	(leadersdata).push(lead.records[0]);
			              }
			              
			           }) 
					}
					res.render('leaders/index', { title: 'NHL League Leaders',leades:leadersdata,league:"NHL" });
				}) 	
			}else if(req.params.league=="MLB"){
					Leaders.aggregate([{$match:{league:req.params.league,rank:1}},{
				        "$lookup": {
				            "from": "playerimages", 
				            "localField": "player_id",
				            "foreignField": "player_id",
				            "as": "playerImage"
				        }
			    	},{ $group : {_id:{categories_type:"$categories_type"},records: { $push:  {  player_name: "$player_name",player_id: "$player_id",  categories_type: "$categories_type", avg_points: "$avg_points", team_name: "$team_name" ,team_market: "$team_market" , rank: "$rank"  ,playerImage:"$playerImage" } }}}, {$sort:{"_id.categories_type":1,"_id.avg_points":-1}}]).exec( function (err, leades) {
						if (leades) { 
							   leadersdata  =  [];
							   (leades).forEach(function(lead){
								  leading =  {};
								  lead.records[0].categories_name  =   dt.camelizeMlb(lead.records[0].categories_type);
							
								   if(typeof lead.records[0].player_id !="undefined"){
									if((lead.records[0]['playerImage']).length > 0){
										var dir  =  "/var/sports/public/upload/player/mlb/"+lead.records[0]['playerImage'][0]['asset_id']+"/original.jpg";
										if (fs.existsSync(dir) ) {
											lead.records[0].player_pic  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/player/mlb/"+lead.records[0]['playerImage'][0]['asset_id']+"/original.jpg";
										}else{
											lead.records[0].player_pic  =  "";
										}
										
									}else{
										lead.records[0].player_pic  =  "";
									}
								 
								}else{
									 lead.records[0].player_pic  =  "";
								}
								delete lead.records[0]["playerImage"];
								  lead.records[0].player_name  =  lead.records[0].player_name;
								  lead.records[0].team_market  =  lead.records[0].team_market;
								  lead.records[0].team_name  =  lead.records[0].team_name;
								  lead.records[0].avg_points =  lead.records[0].avg_points;
								  lead.records[0].rank =  lead.records[0].rank;
								  lead.records[0].home_team_logo  =  "";
										 
								 (leadersdata).push(lead.records[0]);
							   }) 
						}
						res.render('leaders/index', { title: 'MLB League Leaders',leades:leadersdata,league:"MLB" });
					})
		
			}
	
	
});
module.exports = router;