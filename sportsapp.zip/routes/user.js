var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
smtpTransport = require('nodemailer-smtp-transport');
var User = require('../models/user');

var transporter = nodemailer.createTransport(smtpTransport({
    host: "smtp.gmail.com",
    secure: false,
    port: 587,
    auth: {
        user: "rohit08890@gmail.com",
        pass: "missionjob12"
    },
    tls: {
        rejectUnauthorized: false
    }
}));
/* GET home page. */
router.get('/', function(req, res) {

	User.find({role: { $ne: 1 }}, function (err, user) {
		//console.log(user); 
		res.render('user/index', { title: 'User',users:user });
    });
  
});
router.get('/add', function(req, res, next) {
	res.render('user/add',{ errorMsg: ''});
});
router.get('/edit/:id', function(req, res, next) {
	User.findById(req.params.id, function (err, user) {
		res.render('user/edit', { title: 'User',userdata:user,errorMsg: '' });
	});

	
});
router.post('/save', function(req, res, next) {
	let {username, email,fname,lname} = req.body; 
    let userData = {
    	username,
		email,
		role:1,
        password: bcrypt.hashSync('vinay@123', 5), 
        fname,
        lname
    };	
	var user = new User(userData);
    user.save(function(err, user) {
        if (err) {
			res.render('user/add',{ errorMsg: err.errors});
		}else{
			req.flash('success', 'You have create user successfully. Thank you');
			res.redirect('/user');
		}
    });	

});

router.post('/update/:id', function(req, res, next) {
	User.findOneAndUpdate(
		{ _id: req.params.id },
		req.body,
		{ runValidators: true, context: 'query' },
		(err, user) => {
			if (err) {
				
				User.findById(req.params.id, function (errdata, user) {
					
					 /*  console.log(err.errors.username.message);
					  return true; */
					res.render('user/edit', { title: 'User',userdata:user,errorMsg:err.errors});
				});
			//	res.render('user/edit',{ errorMsg: err.errors});
			}else{
				req.flash('success', 'You have update user successfully. Thank you');
				res.redirect('/user');
			}
		}
	)
});

router.get('/delete/:id', function(req, res, next) {
		
	User.findOneAndDelete({ _id: req.params.id }, function (err,result) {
			
			if (!result) {
				req.flash('error', 'Invalid URL');
				res.redirect('/user');
			}else{
				req.flash('success', 'User Delete successfully.');
				res.redirect('/user');
			}	
			
	});

});
module.exports = router;
