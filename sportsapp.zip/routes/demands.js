var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment'),
	mongoose = require('mongoose'),
	Event = require('../models/event');
	EventNew = require('../models/eventnew');
	Demand = require('../models/demand');
	DemandNew = require('../models/demandNew');
	Venue = require('../models/venue');
	Score = require('../models/score');
	TicketMaster = require('../models/ticketmaster');
	Fddemand = require('../models/fddemand');
	dt = require('../lib/function');
	async = require('async');
/* GET Demands page. */
router.get('/', function(req, res) {
	console.log(moment("2019-03-25T19:00:00").format("YYYY-MM-DDTHH:mm:ss"));
	if(req.query.category){
	
		Event.aggregate([ {$match:{ event_type:'seedgreek' }},{ $group : {_id:"$type" }}]).then((eventData) => {
			Event.find({event_type:'seedgreek',type:req.query.category}).sort({dateutc: 1}).exec(function (err, events) {
				res.render('demands/index', { title: 'SeatGeek',seatevents:events,category:eventData,moment:moment,type:"seatevents",selectcategory:req.query.category });
			});  
		}); 
	}else{
		Event.aggregate([ {$match:{ event_type:'seedgreek' }},{ $group : {_id:"$type" }}]).then((eventData) => {
			Event.find({event_type:'seedgreek'}).sort({dateutc: 1}).exec(function (err, events) {
				res.render('demands/index', { title: 'SeatGeek',seatevents:events,category:eventData,moment:moment,type:"seatevents",selectcategory:'' });
			});  
		});  
	}
	
});

router.get('/ticketmaster', function(req, res) {
	if(req.query.category){
	
		TicketMaster.aggregate([ { $group : {_id:"$type" }}]).then((eventData) => {
			TicketMaster.find({event_type:'ticketmaster',type:req.query.category}).sort({dateutc: 1}).exec(function (err, events) {
				console.log(events);
				res.render('demands/index', { title: 'TicketMaster',seatevents:events,category:eventData,moment:moment,type:"ticketmaster",selectcategory:req.query.category});
			});  
		}); 
	}else{
		TicketMaster.aggregate([ { $group : {_id:"$type" }}]).then((eventData) => {
			TicketMaster.find({event_type:'ticketmaster'}).sort({dateutc: 1}).exec(function (err, events) {
				res.render('demands/index', { title: 'TicketMaster',seatevents:events,category:eventData,moment:moment,type:"ticketmaster",selectcategory:'' });
			});  
		});  
	}
	/* Event.aggregate([ { $group : {_id:"$type" }}]).then((eventData) => {
		Event.find({event_type:'ticketmaster'}).sort({dateutc: -1}).exec(function (err, events) {
			 res.render('demands/index', { title: 'TicketMaster',seatevents:events,category:eventData,moment:moment,type:"ticketmaster" });
		});
	}); */  
});

router.get('/tickets', function(req, res, next) {
		if(req.query.category && req.query.sg_mean_price ==1){
			  Event.aggregate([ { $group : {_id:"$type" }}]).then((eventData) => {
				DemandNew.find({ type : req.query.category },{average_price : { $ne: 0 }}).sort({dateutc: -1}).exec(function (err, events) {
					res.render('demands/ticket', { title: 'Fan Demand',seatevents:events,moment:moment,category:eventData,selectcategory:req.query.category,sgMeanPrice:0 });
				});
			});
		 }else if(req.query.sg_mean_price ==1){
			  Event.aggregate([ { $group : {_id:"$type" }}]).then((eventData) => {
				DemandNew.find({average_price : { $ne: 0 }}).sort({dateutc: -1}).exec(function (err, events) {
					res.render('demands/ticket', { title: 'Fan Demand',seatevents:events,moment:moment,category:eventData,selectcategory:'',sgMeanPrice:0 });
				});
			});
		 }else if(req.query.category){
			  Event.aggregate([ { $group : {_id:"$type" }}]).then((eventData) => {
				DemandNew.find({type : req.query.category}).sort({dateutc: -1}).exec(function (err, events) {
					res.render('demands/ticket', { title: 'Fan Demand',seatevents:events,moment:moment,category:eventData,selectcategory:req.query.category,sgMeanPrice:0 });
				});
			});
		 }else{
			 Event.aggregate([ { $group : {_id:"$type" }}]).then((eventData) => {
				DemandNew.find({}).sort({dateutc: -1}).exec(function (err, events) {
					res.render('demands/ticket', { title: 'Fan Demand',seatevents:events,moment:moment,category:eventData,selectcategory:'',sgMeanPrice:0 });
				});
			});
		 }
		
	
	
});
router.get('/teamfandemand', function(req, res, next) {
	Fddemand.find({}).exec( function (err, fandemand) {
		res.render('demands/fandeamnd', { title: 'Standing Fan Demand',seatevents:fandemand,moment:moment });
	})
	
})

router.get('/update_seetgreek/:taxonomy', async function(req,res, next){
	if(req.params.taxonomy){
		var today = new Date();
		var yyyy = today.getFullYear();
		var dd  = today.getDate();
		var mm	=	 today.getMonth();

		var from = new Date(yyyy,mm,dd-2);
		var to = new Date(yyyy,mm,dd+20);
		var startDate =	moment(from).utc().format("YYYY-MM-DD");
		var endDate =	moment(to).utc().format("YYYY-MM-DD");
	
		request('https://api.seatgeek.com/2/events?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ&&taxonomies.name='+req.params.taxonomy+'&datetime_utc.gte='+startDate+'&datetime_utc.lte='+endDate+'&per_page=800&sort=datetime_local.desc', { json: true }, (err, response, body) => {
		  
			if(typeof(body.events) != "undefined" || body.events != null){
	
				async.forEach((body.events),function(gloop) {
						 Event.find({event_id:gloop.id},  function (err, eventData) {
							
							if(eventData.length > 0){
							 
								console.log("Update----"+eventData[0].event_id);
								Event.where({ _id: mongoose.Types.ObjectId(eventData[0]._id)  }).updateMany({
									average_price_old: eventData[0].average_price,
									average_price:gloop.stats.average_price}).exec((err, updateEvent) => {
									console.log(updateEvent);

								});
								
							 
							} else{
							
								req.body.event_id	=	gloop.id;
								req.body.event_type	=	'seedgreek';
								req.body.title		=	gloop.title;
								req.body.type		=	(gloop.type).toUpperCase();
								
								req.body.date		=	gloop.datetime_local;
								req.body.dateutc	=	gloop.datetime_utc;
								req.body.datetime	=	"";
								req.body.venue_id	=	gloop.venue.name;
								req.body.venue_city	=	gloop.venue.city;
								req.body.average_price	=	gloop.stats.average_price;
								req.body.timezone	=	gloop.venue.timezone;
								//console.log(req.body); 
								var event = new Event(req.body);
								event.save(function(errLog, eventData) {
								
									 console.log(errLog);	
								}) 
							}	 				
						}) 
					// await dt.delay1();
					
				});
				 res.redirect('/demands');	
			}else{
				res.redirect('/demands');	
			}

		 });
		
	}
	
})

router.get('/update_ticket_master',function(req,res, next){
	
	if(req.query){
		if(req.query.mm <10){
			month = "0"+req.query.mm;
		}else{
			month = req.query.mm;
		}
		if(req.query.dd <10){
			day = "0"+req.query.dd;
		}else{
			day = req.query.dd;
		}
		startDateTime	= req.query.year+"-"+month+"-"+day+"T00:00:00Z";	
		endDateTime	= req.query.year+"-"+month+"-"+day+"T23:59:00Z";	
		
		request('https://app.ticketmaster.com/discovery/v2/events.json?apikey=XDXfAtXaBpGQDDM0oLbWyFOujjMYc31i&classificationName='+req.query.league+'&startDateTime='+startDateTime+'&endDateTime='+endDateTime, { json: true }, (err, response, body) => {
			if(typeof(body._embedded) != "undefined" || body._embedded != null){
				if(typeof(body._embedded.events) != "undefined" || body._embedded.events != null){
				
					(body._embedded.events).forEach(function(gloop) {
						var gloop_id = (gloop.id).split('_');
						var gloop_id = gloop_id.join('');
						Event.find({event_id:gloop_id}, function (err, eventData) {
							
							if(eventData.length==0){
								console.log("insert---"+ gloop_id);
								req.body.event_id	=	gloop.id;
								req.body.event_type	=	'ticketmaster';
								req.body.title		=	gloop.name;
								req.body.type		=	gloop.classifications[0].subGenre.name;
								req.body.date		=	'';
								req.body.dateutc	=	gloop.dates.start.localDate+'T'+gloop.dates.start.localTime;
								req.body.datetime	=	gloop.dates.start.dateTime;
								req.body.venue_id	=	gloop._embedded.venues[0].name;
								req.body.venue_city	=	gloop._embedded.venues[0].city.name;
								if(typeof(gloop.seatmap) != "undefined"){
									req.body.seatmap	=	gloop.seatmap.staticUrl;
								}
								
								if(typeof(gloop.priceRanges) != "undefined" || gloop.priceRanges != null && (gloop.priceRanges).length>0){
									req.body.min_price	=	gloop.priceRanges[0].min;
									req.body.max_price	=	gloop.priceRanges[0].max;
								}else{
									req.body.min_price	=	0;
									req.body.max_price	=	0;
								}	
								
								 var event = new Event(req.body);
								event.save(function(errLog, eventData) {
								
							  
								}); 
								
							}else{
								
								if(typeof(gloop.priceRanges) != "undefined" || gloop.priceRanges != null && (gloop.priceRanges).length>0){
										req.body.min_price	=	gloop.priceRanges[0].min;
										req.body.max_price	=	gloop.priceRanges[0].max;
								}else{
									req.body.min_price	=	0;
									req.body.max_price	=	0;
								}
								req.body.max_price_old	=	eventData[0].max_price;
								req.body.min_price_old	=	eventData[0].min_price;
								req.body.datetime	=	gloop.dates.start.dateTime;
								Event.findOneAndUpdate(
									{ _id: mongoose.Types.ObjectId(eventData[0]._id) },
									req.body,
									{ runValidators: true, context: 'query' },
									(err, event) => {
										if (err) {
											 console.log(err);	
										}
									}
								)
								
							}

						})
						
					});   
					
				}
				req.flash('success', 'Data saved successfully.');
				res.redirect('/demands/ticketmaster');	
			}else{
				req.flash('error', 'No Data Found!!');
				res.redirect('/demands/ticketmaster');	
			}

		 });
	}
	
})

router.get('/update_ticket_master_bulk/:taxonomy',async function(req,res, next){
	if(req.params.taxonomy){
		var today = new Date();
		var yyyy = today.getFullYear();
		var dd  = today.getDate();
		var mm	=	 today.getMonth();
		var from = new Date(yyyy,mm,dd-2);
		var to = new Date(yyyy,mm,dd+20);
		for (var day = from; day <= to; day.setDate(day.getDate() + 1)) {
			await dt.delay1();
	      	var ticketMasterDate =	moment(day).utc().format("YYYY-MM-DD");
	      	var startDate = ticketMasterDate+"T00:00:00Z";
	      	var endDate = ticketMasterDate+"T23:59:00Z";
		  	request('https://app.ticketmaster.com/discovery/v2/events.json?apikey=XDXfAtXaBpGQDDM0oLbWyFOujjMYc31i&classificationName='+req.params.taxonomy+'&startDateTime='+startDate+'&endDateTime='+endDate, { json: true }, (err, response, body) => {
				if(typeof(body._embedded) != "undefined" || body._embedded != null){
					if(typeof(body._embedded.events) != "undefined" || body._embedded.events != null){
				
					(body._embedded.events).forEach(function(gloop) {

						var gloop_id = (gloop.id).split('_');
						var gloop_id = gloop_id.join('');
						TicketMaster.find({event_id:gloop_id}, function (err, eventData) {
							
							if(eventData.length==0){
								req.body.event_id	=	gloop_id;
								req.body.event_type	=	'ticketmaster';
								req.body.title		=	gloop.name;
								req.body.type		=	gloop.classifications[0].subGenre.name;
								req.body.date		=	'';
								req.body.dateutc	=	gloop.dates.start.localDate+'T'+gloop.dates.start.localTime;
								if(gloop.dates.start.dateTime){
									req.body.datetime	=	(gloop.dates.start.dateTime).replace("Z","");
								}
								
								req.body.venue_id	=	gloop._embedded.venues[0].name;
								req.body.venue_city	=	gloop._embedded.venues[0].city.name;
								if(typeof(gloop.seatmap) != "undefined"){
									req.body.seatmap	=	gloop.seatmap.staticUrl;
								}
								if(typeof(gloop.priceRanges) != "undefined" || gloop.priceRanges != null && (gloop.priceRanges).length>0){
									req.body.min_price	=	gloop.priceRanges[0].min;
									req.body.max_price	=	gloop.priceRanges[0].max;
								}else{
									req.body.min_price	=	0;
									req.body.max_price	=	0;
								}	
								
								 var ticketmaster = new TicketMaster(req.body);
								ticketmaster.save(function(errLog, eventData) {
								
							  
								}); 
								
							}else{
								
								 if(typeof(gloop.priceRanges) != "undefined" || gloop.priceRanges != null && (gloop.priceRanges).length>0){
										min_price	=	gloop.priceRanges[0].min;
										max_price	=	gloop.priceRanges[0].max;
								}else{
									min_price	=	0;
									max_price	=	0;
								} 
								TicketMaster.where({ _id: mongoose.Types.ObjectId(eventData[0]._id)  }).updateMany({max_price_old: eventData[0].max_price,min_price_old:eventData[0].min_price,max_price: max_price,min_price:min_price,datetime:gloop.dates.start.dateTime }).exec((err, updateEvent) => {
									console.log(updateEvent);

								});
								
							}

						})
						
					});   
					
				}	
			}

		  });
		   
		}
		req.flash('success', 'Data saved successfully.');
		res.redirect('/demands/ticketmaster');
		 
	}
	
})

router.get('/syncdemand/:league',function(req,res, next){
	var response = {};
	Demand.remove({type:req.params.league}).then((sc) => { 
		Event.aggregate([{$match:{type : req.params.league}},{ $group : {_id:{venue_city:"$venue_city",dateutc:"$dateutc"},records: { $push: "$$ROOT" } }}, {$sort:{"_id.dateutc":1}}]).exec( function (err, events) { 
		objEvent	=	[];
		if(events.length>0){
			i=0;
			async.forEach(events,function(demand) {
					eventData	=	{};
					eventData['title']	=	demand.records[0].title;
					
					eventData['type']	=	req.params.league;
					eventData['venue']	=	demand.records[0].venue_city;
					venue_location = (demand.records[0].venue_id).split("-");
					eventData['venue_location']	=	(venue_location[0]).trim();
					eventData['dateutc']	=	moment(demand.records[0].dateutc).format("YYYY-MM-DD HH:mm");
					eventData['description']	=	"";
					changeDemand=0;
					if((demand.records).length>1){
						if(demand.records[0].event_type =="ticketmaster"){
							eventData['seatmap']	=	demand.records[0].seatmap;
							if(demand.records[0].datetime !=""){
								eventData['datetime']	=	moment(demand.records[0].datetime).format("YYYY-MM-DD HH:mm");
							}else{
								eventData['datetime']	=	0;
							}
							
							if(typeof demand.records[1].average_price != "undefined"){
								eventData['average_price']	=	demand.records[1].average_price;
								eventData['average_price_old']	=	demand.records[1].average_price_old;
								if(typeof demand.records[0].max_price != "undefined" && typeof demand.records[0].min_price != "undefined"){
									eventData['max_price']	=	demand.records[0].max_price;
									eventData['min_price']	=	demand.records[0].min_price;
									eventData['max_price_old']	=	demand.records[0].max_price_old;
									eventData['min_price_old']	=	demand.records[0].min_price_old;
									eventData['demand']	= demand.records[1].average_price - ((demand.records[0].max_price + demand.records[0].min_price)/2);
									changeDemand = 	 eventData['demand'] - (demand.records[1].average_price_old - ((demand.records[0].max_price_old + demand.records[0].min_price_old)/2));
									if(changeDemand != eventData['demand']){
										if (isNaN(changeDemand)) {
											eventData['change_demand']	= 0;
										}else{
											eventData['change_demand']	= Number(changeDemand);
										}
										
									}else{
										eventData['change_demand']	= 0;
									}
									
									if(changeDemand < 0){
										eventData['status']	= 'negative'; 
									}else{
										eventData['status']	= 'positive';
									}
								}else{
									eventData['average_price']	=	demand.records[0].average_price;
									eventData['average_price_old']	=	demand.records[0].average_price_old;
									eventData['demand']	= demand.records[0].average_price;
									changeDemand = 	demand.records[0].average_price - demand.records[0].average_price_old
									if(changeDemand != eventData['demand']){
										if (isNaN(changeDemand)) {
											eventData['change_demand']	= 0;
										}else{
											eventData['change_demand']	= Number(changeDemand);
										}
									}else{
										eventData['change_demand']	= 0;
									}
									if(changeDemand < 0){
										eventData['status']	= 'negative'; 
									}else{
										eventData['status']	= 'positive';
									}
								}	
							}else{
								if(typeof demand.records[1].max_price != "undefined" && typeof demand.records[1].min_price != "undefined"){
									eventData['max_price']	=	demand.records[1].max_price;
									eventData['min_price']	=	demand.records[1].min_price;
									eventData['max_price_old']	=	demand.records[1].max_price_old;
									eventData['min_price_old']	=	demand.records[1].min_price_old;
									eventData['demand']	=  0 - ((demand.records[1].max_price + demand.records[1].min_price)/2);
									changeDemand = eventData['demand']-(0 - ((demand.records[1].max_price_old + demand.records[1].min_price_old)/2));
									if(changeDemand != eventData['demand']){
										if (isNaN(changeDemand)) {
											eventData['change_demand']	= 0;
										}else{
											eventData['change_demand']	= Number(changeDemand);
										}
									}else{
										eventData['change_demand']	= 0;
									}
									if(changeDemand < 0){
										eventData['status']	= 'negative'; 
									}else{
										eventData['status']	= 'positive';
									}
								}else{
									eventData['max_price']	=	0;
									eventData['min_price']	=	0;
									eventData['max_price_old']	=	0;
									eventData['min_price_old']	=	0;
									eventData['average_price']	=	0;
									eventData['average_price_old']	=	0;
									eventData['demand']	= 0;
									eventData['change_demand']	= 0;
									eventData['status']	= 'positive';
								}	
							}
						}else{
							eventData['seatmap']	=	demand.records[1].seatmap;
							if(demand.records[1].datetime !=""){
								eventData['datetime']	=	moment(demand.records[1].datetime).format("YYYY-MM-DD HH:mm");
							}else{
								eventData['datetime']	=	0;
							}
							
							if(typeof demand.records[0].average_price != "undefined"){
								eventData['average_price']	=	demand.records[0].average_price;
								eventData['average_price_old']	=	demand.records[0].average_price_old;
								if(typeof demand.records[1].max_price != "undefined" && typeof demand.records[1].min_price != "undefined"){
									eventData['max_price']	=	demand.records[1].max_price;
									eventData['min_price']	=	demand.records[1].min_price;
									eventData['max_price_old']	=	demand.records[1].max_price_old;
									eventData['min_price_old']	=	demand.records[1].min_price_old;
									eventData['demand']	= demand.records[0].average_price - ((demand.records[1].max_price + demand.records[1].min_price)/2);
									changeDemand = 	 eventData['demand'] - (demand.records[0].average_price_old - ((demand.records[1].max_price_old + demand.records[1].min_price_old)/2));
									if(changeDemand != eventData['demand']){
										if (isNaN(changeDemand)) {
											eventData['change_demand']	= 0;
										}else{
											eventData['change_demand']	= Number(changeDemand);
										}
										
									}else{
										eventData['change_demand']	= 0;
									}
									
									if(changeDemand < 0){
										eventData['status']	= 'negative'; 
									}else{
										eventData['status']	= 'positive';
									}
								}else{
									eventData['average_price']	=	demand.records[1].average_price;
									eventData['average_price_old']	=	demand.records[1].average_price_old;
									eventData['demand']	= demand.records[0].average_price;
									changeDemand = 	demand.records[0].average_price - demand.records[0].average_price_old
									if(changeDemand != eventData['demand']){
										if (isNaN(changeDemand)) {
											eventData['change_demand']	= 0;
										}else{
											eventData['change_demand']	= Number(changeDemand);
										}
									}else{
										eventData['change_demand']	= 0;
									}
									if(changeDemand < 0){
										eventData['status']	= 'negative'; 
									}else{
										eventData['status']	= 'positive';
									}
								}	
							}else{
								if(typeof demand.records[1].max_price != "undefined" && typeof demand.records[1].min_price != "undefined"){
									eventData['max_price']	=	demand.records[1].max_price;
									eventData['min_price']	=	demand.records[1].min_price;
									eventData['max_price_old']	=	demand.records[1].max_price_old;
									eventData['min_price_old']	=	demand.records[1].min_price_old;
									eventData['demand']	=  0 - ((demand.records[1].max_price + demand.records[1].min_price)/2);
									changeDemand = eventData['demand']-(0 - ((demand.records[1].max_price_old + demand.records[1].min_price_old)/2));
									if(changeDemand != eventData['demand']){
										if (isNaN(changeDemand)) {
											eventData['change_demand']	= 0;
										}else{
											eventData['change_demand']	= Number(changeDemand);
										}
									}else{
										eventData['change_demand']	= 0;
									}
									if(changeDemand < 0){
										eventData['status']	= 'negative'; 
									}else{
										eventData['status']	= 'positive';
									}
								}else{
									eventData['max_price']	=	0;
									eventData['min_price']	=	0;
									eventData['max_price_old']	=	0;
									eventData['min_price_old']	=	0;
									eventData['average_price']	=	0;
									eventData['average_price_old']	=	0;
									eventData['demand']	= 0;
									eventData['change_demand']	= 0;
									eventData['status']	= 'positive';
								}	
							}
						}
					}else{
						if(demand.records[0].datetime != ""){
							eventData['datetime']	=	moment(demand.records[0].datetime).format("YYYY-MM-DD HH:mm");
						}else{
							eventData['datetime']	=	0;
						}
						
						if(typeof demand.records[0].average_price != "undefined"){
							if(typeof demand.records[0].max_price != "undefined" && typeof demand.records[0].min_price != "undefined"){
								eventData['max_price']	=	demand.records[0].max_price;
								eventData['min_price']	=	demand.records[0].min_price;
								eventData['max_price_old']	=	demand.records[0].max_price_old;
								eventData['min_price_old']	=	demand.records[0].min_price_old;
								eventData['demand']	= demand.records[0].average_price - ((demand.records[0].max_price + demand.records[0].min_price)/2);
								changeDemand = eventData['demand'] - (demand.records[0].average_price_old - ((demand.records[0].max_price_old + demand.records[0].min_price_old)/2));
								if(changeDemand != eventData['demand']){
									if (isNaN(changeDemand)) {
										eventData['change_demand']	= 0;
									}else{
										eventData['change_demand']	= Number(changeDemand);
									}
								}else{
									eventData['change_demand']	= 0;
								}
								if(changeDemand < 0){
									eventData['status']	= 'negative'; 
								}else{
									eventData['status']	= 'positive';
								}
							}else{
								eventData['average_price']	=	demand.records[0].average_price;
								eventData['average_price_old']	=	demand.records[0].average_price_old;
								eventData['demand']	= demand.records[0].average_price;
								changeDemand = demand.records[0].average_price - demand.records[0].average_price_old;
								if(changeDemand != eventData['demand']){
									if (isNaN(changeDemand)) {
										eventData['change_demand']	= 0;
									}else{
										eventData['change_demand']	= Number(changeDemand);
									}
								}else{
									eventData['change_demand']	= 0;
								}
								if(changeDemand < 0){
									eventData['status']	= 'negative'; 
								}else{
									eventData['status']	= 'positive';
								}
							}	
						}else{
							if(typeof demand.records[0].max_price != "undefined" && typeof demand.records[0].min_price != "undefined"){
								eventData['max_price']	=	demand.records[0].max_price;
								eventData['min_price']	=	demand.records[0].min_price;
								eventData['max_price_old']	=	demand.records[0].max_price_old;
								eventData['min_price_old']	=	demand.records[0].min_price_old;
								eventData['demand']	=  0 - ((demand.records[0].max_price + demand.records[0].min_price)/2);
								changeDemand	= eventData['demand']-(0 - ((demand.records[0].max_price_old + demand.records[0].min_price_old)/2));
								if(changeDemand != eventData['demand']){
									if (isNaN(changeDemand)) {
										eventData['change_demand']	= 0;
									}else{
										eventData['change_demand']	= Number(changeDemand);
									}
								}else{
									eventData['change_demand']	= 0;
								}
								if(changeDemand < 0){
									eventData['status']	= 'negative'; 
								}else{
									eventData['status']	= 'positive';
								}
							}else{
								eventData['demand']	= 0;
								eventData['change_demand']	= 0;
								eventData['status']	= 'positive';
							}	
						}
					}		 
					objEvent.push(eventData);
					 var demand = new Demand(eventData);
					demand.save(function(errLog, demandData) {
						console.log(errLog);
				  
					});  
				
			})
		
		}
			
	});
	})
	
	res.redirect('/demands/tickets');	
})

router.get('/syncsports&seedgreek/:league',function(req,res,next){
	var response = {};
	var objEvent	=	[];
	DemandNew.remove({type:req.params.league}).then((sc) => {
	Score.aggregate([{$match:{league : req.params.league}},{
        "$lookup": {
            "from": "ticketprice", 
            "localField": "home_name",
            "foreignField": "team_name",
            "as": "ticketPrice"
        }
    }, {$sort:{"_id.created":1}}]).then((scoreList) => {

		Event.find({event_type:"seedgreek",type:req.params.league}).exec( function (err, eventList) { 
			
			async.forEach(scoreList,function(scoreData) {
				async.forEach(eventList,function(eventLoop) {
						var dateStr	=	scoreData.dateutc;
						var dateObj	=	dateStr.split("+");
						var radarDate	=	moment(dateObj[0]).format("YYYY-MM-DD HH:mm:ss");
						var eveDate = moment(eventLoop.dateutc).format("YYYY-MM-DD HH:mm:ss");
						//console.log(radarDate +"---"+eveDate);
						if(eventLoop.venue_id == scoreData.venue && (new Date(radarDate)-new Date(eveDate))==0){
							console.log(eventLoop.venue_id +"---"+scoreData.venue +"----"+new Date(radarDate)+"--"+new Date(eveDate));
							eventData	=	{};
							eventData['title']	=	eventLoop.title;
							eventData['type']	=	req.params.league;
							eventData['venue']	=	eventLoop.venue_city;
							eventData['venue_location']	=	eventLoop.venue_id;
							eventData['dateutc']	=	eveDate;
							eventData['description']	=	"";
							eventData['seatmap']	=	eventLoop.seatmap;
							eventData['datetime']	=	eveDate;
							eventData['average_price']	=	eventLoop.average_price;
							eventData['average_price_old']	=	eventLoop.average_price_old;

							if((scoreData.ticketPrice).length > 0){
								eventData['max_price']	=	scoreData.ticketPrice[0].points;
								eventData['demand']	= eventLoop.average_price-scoreData.ticketPrice[0].points;
							}else{
								eventData['max_price']	=	0;
								eventData['demand']	= eventLoop.average_price;
							}

							changeDemand = 	 eventData['demand'] - eventLoop.average_price_old;
							if(changeDemand != eventData['demand']){
								if (isNaN(changeDemand)) {
									eventData['change_demand']	= 0;
								}else{
									eventData['change_demand']	= Number(changeDemand);
								}
								
							}else{
								eventData['change_demand']	= 0;
							}
									
							if(changeDemand < 0){
								eventData['status']	= 'negative'; 
							}else{
								eventData['status']	= 'positive';
							}
							
							objEvent.push(eventData);
							/*  var demandnew = new DemandNew(eventData);
							
							demandnew.save(function(errLog, demandData) {
								console.log(errLog);
						  
							});  */
							
						}
						
				})	
			});
			 DemandNew.insertMany(objEvent, function(error, demandData) {
				
				
			});
    		
		
		})	
	}) 
	}) 
	res.redirect('/demands/tickets');
});

router.get('/syncdemandvenue',function(req,res, next){
	DemandNew.aggregate([{
        "$lookup": {
            "from": "venues", 
            "localField": "venue_location",
            "foreignField": "title",
            "as": "VenueLoc"
        }
    }]).exec( function (err, demands) { 
		demands.forEach(function(venue) {
			if((venue.VenueLoc).length>0){
				(venue.VenueLoc).forEach(function(venue_location) {
					if((venue_location.links).length>1){
						linkHref =	venue_location.links[1].href;
					}else{
						linkHref =	venue_location.links[0].href;
					}
					if(venue_location.league=="NBA"){
						
						req.body.venue_image	=	"https://api.sportradar.us/nba-images-t3/getty"+linkHref+"?api_key=s9h4vb8krqv55aemuughuufb";
					}
					if(venue_location.league=="NHL"){
						req.body.venue_image	=	"https://api.sportradar.us/nhl-images-t3/usat"+linkHref+"?api_key=bfw7wd7f29e4rsrntwmgqb2m";
					}
					
				DemandNew.where({ venue_location: venue_location.title,type: venue_location.league}).updateMany({venue_image: req.body.venue_image}).exec((err, updateDemand) => {
								console.log(updateDemand);

						});
			
				})
				
			}
			
		})
	});
	res.redirect('/demands/tickets');	
});

router.get('/syncseatmap/:league',function(req,res, next){
	var response={};
	Event.aggregate([{$match:{type:req.params.league}},{
        "$lookup": {
            "from": "ticketmasters", 
            "localField": "dateutc",
            "foreignField": "datetime",
            "as": "TicketMaster"
        }
    }]).exec( function (err, events) { 
	var ticketScore	=	[];
	async.forEach(events,function(eventLoop){
		
		if((eventLoop.TicketMaster).length>0){
			 async.forEach((eventLoop.TicketMaster),function(ticketmaster){
				 var teamname	=	(eventLoop.title).split(" at ");
				if(ticketmaster.venue_city==eventLoop.venue_city && (ticketmaster.title).indexOf(teamname[1])>=-1){
					
					DemandNew.findOneAndUpdate({title: eventLoop.title }, { $set: { seatmap: ticketmaster.seatmap}}).exec(function(err, scoreDta){
							console.log(err);
							
						})
				}else{
					console.log(eventLoop.title +'=============='+ticketmaster.title+"------------------------NOt--"+teamname[1]+"-----------"+(ticketmaster.title).indexOf(teamname[1]));
				}
			})
			 
		}
			
	})
			
	});
	res.redirect('/demands/tickets');	
});

router.get('/getfddemand/:league',function(req, res){
	var response	=	{};
	if(req.params.league=="NHL"){
		Fddemand.remove({type:req.params.league}).then((sc) => { 
			Score.find({league:req.params.league}).exec( function (err, score) {
				async.forEach(score,function(scoreData) {
					DemandNew.find({ title:{ $regex:scoreData.home_name},datetime:  new Date(scoreData.created)}, function (err, demands) {
						if(demands.length>0){
							var body	=	{};
							//body.title	=	demands[0].title;
							body.home_team	=	scoreData.home_name;
							body.home_id	=	scoreData.home_id;
							body.away_team	=	scoreData.away_name;
							body.away_id	=	scoreData.away_id;
							body.venue	=	demands[0].venue;
							body.venue_location	=	demands[0].venue_location;
							body.demand	=	demands[0].demand;
							body.datetime	=	demands[0].datetime;
							body.dateutc	=	demands[0].dateutc;
							body.type	=	demands[0].type;
							body.change_demand	=	demands[0].change_demand;
							 var fddemand = new Fddemand(body); 
							fddemand.save(function(errLog, demandData) {
								console.log(errLog);
						  
							});
							 
						}
					})
			
				})
			}) 
			res.redirect('/demands/teamfandemand');	
		}) 
	}else{
		Fddemand.remove({type:req.params.league}).then((sc) => { 
			Score.find({league:req.params.league}).exec( function (err, score) {
				async.forEach(score,function(scoreData) {
					Demand.find({ title:{ $regex:scoreData.home_name},datetime:  new Date(scoreData.created)}, function (err, demands) {
						if(demands.length>0){
							var body	=	{};
							//body.title	=	demands[0].title;
							body.home_team	=	scoreData.home_name;
							body.home_id	=	scoreData.home_id;
							body.away_team	=	scoreData.away_name;
							body.away_id	=	scoreData.away_id;
							body.venue	=	demands[0].venue;
							body.venue_location	=	demands[0].venue_location;
							body.demand	=	demands[0].demand;
							body.datetime	=	demands[0].datetime;
							body.dateutc	=	demands[0].dateutc;
							body.type	=	demands[0].type;
							body.change_demand	=	demands[0].change_demand;
							 var fddemand = new Fddemand(body); 
							fddemand.save(function(errLog, demandData) {
								console.log(errLog);
						  
							});
							 
						}
					})
			
				})
			}) 
			res.redirect('/demands/teamfandemand');	
		}) 
	}
	
})
router.get('/view/:id', function(req, res, next) {
	request('https://api.seatgeek.com/2/events/'+req.params.id+'?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ', { json: true }, (err, response, body) => {
	  if (err) { return console.log(err+'ssdaas'); }
	  	console.log(body);
		 res.render('demands/view', { title: 'Demands',demands:body,moment:moment});
	});
	
	
});
router.get('/view_artist/:id', function(req, res, next) {
	request('https://api.seatgeek.com/2/performers/'+req.params.id+'?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ', { json: true }, (err, response, body) => {
	  if (err) { return console.log(err+'ssdaas'); }
	  	console.log(body);
		 res.render('demands/view_artist', { title: 'Demands',demands:body,moment:moment});
	});
	
	
});
router.get('/view_venue/:id', function(req, res, next) {
	request('https://api.seatgeek.com/2/venues/'+req.params.id+'?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ', { json: true }, (err, response, body) => {
	  if (err) { return console.log(err+'ssdaas'); }
	  	console.log(body);
		 res.render('demands/view_venue', { title: 'Demands',demands:body,moment:moment});
	});
	
	
});
router.get('/make_public/:id', function(req, res, next) {
	request('https://api.seatgeek.com/2/events/'+req.params.id+'?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ', { json: true }, (err, response, body) => {
	  	if (err) { 	
	  		return console.log(err+'ssdaas'); 
	  	}else{

	  		var event = new Event(body);
			event.save(function(err, event) {
				if (err) {
					res.render('demands/index',{ errorMsg: err.errors});
				}else{
					req.flash('success', 'You have create category successfully. Thank you');
					res.redirect('/');
				}
			});	
	  	}
	});
	
	
});
module.exports = router;
