var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
smtpTransport = require('nodemailer-smtp-transport');
var Comment = require('../models/comment');
var moment = require('moment');
/* GET home page. */
router.get('/', function(req, res, next) {
	Comment.find().populate('user').exec(function (err, comment) {
		//console.log(comment[0].user);
		res.render('comment/index', { title: 'Comment',comments:comment,moment:moment });
	});	
});


module.exports = router;
