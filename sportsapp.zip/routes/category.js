var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
var Category = require('../models/category');
var formidable = require('formidable');
var fs = require('fs');
var transporter = nodemailer.createTransport(smtpTransport({
    host: "smtp.gmail.com",
    secure: false,
    port: 587,
    auth: {
        user: "rohit08890@gmail.com",
        pass: "missionjob12"
    },
    tls: {
        rejectUnauthorized: false
    }
}));
/* GET home page. */
router.get('/', function(req, res) {
	
	Category.find({}, function (err, category) {
        res.render('category/index', { title: 'Category',categories:category });
    });
  
});
router.get('/add', function(req, res, next) {
	res.render('category/add',{ title: 'Category',errorMsg: ''});
	
});
router.get('/edit/:id', function(req, res, next) {
	Category.findById(req.params.id, function (err, category) {
		res.render('category/edit', { title: 'Category',categorydata:category,errorMsg: ''});
	});	
});
router.post('/save', function(req, res, next) {
	var currentPath = process.cwd();
	var form = new formidable.IncomingForm();
	form.parse(req, function (err, fields, files) {
		
			var oldpath = files.filetoupload.path;
			var newpath = currentPath +"/public/upload/category/"+ files.filetoupload.name;
			
			if(files.filetoupload.name !=''){
				fs.rename(oldpath, newpath, function (err) {
					req.body.filetoupload=files.filetoupload.name;
					req.body.name=fields.name;
					req.body.description=fields.description;
					req.body.status=fields.status;
					var category = new Category(req.body);
					category.save(function(err, category) {
						if (err) {
							res.render('category/add',{ errorMsg: err.errors});
						}else{
							req.flash('success', 'You have create category successfully. Thank you');
							res.redirect('/category');
						}
					});	
				});	
			}else{
				req.body.filetoupload='';
				req.body.name=fields.name;
				req.body.description=fields.description;
				req.body.status=fields.status;
				var category = new Category(req.body);
				category.save(function(err, category) {
					if (err) {
						res.render('category/add',{ errorMsg: err.errors});
					}else{
						req.flash('success', 'You have create category successfully. Thank you');
						res.redirect('/category');
					}
				});	
			}
	
	});
});

router.post('/update/:id', function(req, res, next) {
	var currentPath = process.cwd();
	
	var form = new formidable.IncomingForm();
	form.parse(req, function (err, fields, files) {
		 var oldpath = files.filetoupload.path;
		  var newpath = currentPath +"/public/upload/category/"+ files.filetoupload.name;
			if(files.filetoupload.name !=''){
			  fs.rename(oldpath, newpath, function (err) {
				if (err) throw err;
				req.body.filetoupload=files.filetoupload.name;
				req.body.name=fields.name;
				req.body.description=fields.description;
				req.body.status=fields.status;
				Category.findOneAndUpdate(
					{ _id: req.params.id },
					req.body,
					{ runValidators: true, context: 'query' },
					(err, category) => {
						
						if (err) {
							Category.findById(req.params.id, function (errdata, categoryDetail) {
								res.render('category/edit',{categorydata:categoryDetail, errorMsg: err.errors});
							});
							
						}else{
							req.flash('success', 'You have update category successfully. Thank you');
							res.redirect('/category');
						}
					}
				)
			  });
			}else{
				req.body.name=fields.name;
				req.body.description=fields.description;
				req.body.status=fields.status;
				Category.findOneAndUpdate(
					{ _id: req.params.id },
					req.body,
					{ runValidators: true, context: 'query' },
					(err, category) => {
						if (err) {
						
							Category.findById(req.params.id, function (errdata, categoryDetail) {
								res.render('category/edit',{categorydata:categoryDetail, errorMsg: err.errors});
							});
						}else{
							req.flash('success', 'You have update category successfully. Thank you');
							res.redirect('/category');
						}	
					}
				)	
			}  
	 });
		
});

router.get('/delete/:id', function(req, res, next) {
		
	Category.findOneAndDelete({ _id: req.params.id }, function (err,result) {
			
			if (!result) {
				req.flash('error', 'Invalid Request');
				res.redirect('/category');
			}else{
				req.flash('success', 'Category deleted successfully.');
				res.redirect('/category');
			}	
			
	});

});
module.exports = router;
