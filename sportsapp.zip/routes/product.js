var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
smtpTransport = require('nodemailer-smtp-transport');
var User = require('../models/user');
var Product = require('../models/product');
var Category = require('../models/category');
var formidable = require('formidable');
var fs = require('fs');
var transporter = nodemailer.createTransport(smtpTransport({
    host: "smtp.gmail.com",
    secure: false,
    port: 587,
    auth: {
        user: "rohit08890@gmail.com",
        pass: "missionjob12"
    },
    tls: {
        rejectUnauthorized: false
    }
}));
/* GET home page. */
router.get('/', function(req, res) {
	
	Product.find({}, function (err, product) {
        res.render('product/index', { title: 'Product',products:product });
    });
  
});
router.get('/add', function(req, res, next) {
		Category.find(function (err, category) {
			res.render('product/add',{ title: 'User',categories:category});
		})
			
});
router.get('/edit/:id', function(req, res, next) {
	Product.findById(req.params.id, function (err, product) {
		Category.find(function (err, category) {
			res.render('product/edit', { title: 'Product',productdata:product,categories:category});
		});
		
	});
});
router.post('/save', function(req, res, next) {
	var currentPath = process.cwd();

	req.body.owner=	req.session.user.id;
	var form = new formidable.IncomingForm();
	form.parse(req, function (err, fields, files) {
		
		var oldpath = files.filetoupload.path;
		var newpath = currentPath +"/public/upload/product/"+ files.filetoupload.name;
		
		if(files.filetoupload.name !=''){
			fs.rename(oldpath, newpath, function (err) {
				req.body.filetoupload=files.filetoupload.name;
				req.body.name=fields.name;
				req.body.user=fields.user;
				req.body.group=fields.group;
				req.body.description=fields.description;
				req.body.status=fields.status;
				req.body.type=fields.type;
				req.body.category=fields.category;
				req.body.product_type=fields.product_type;
				var product = new Product(req.body);
				product.save(function(err, product) {
					if (err) throw err;
					productcategory 	=	fields.category;
					Category.findOneAndUpdate(
					   { _id: productcategory }, 
					   { $push: { product: product._id  } },
						function (error, success) {
							if (error) {
								console.log(error);
							} else {
								console.log(success);
							}
						}
					);
					req.flash('success', 'You have created a product successfully. Thank you');
					res.redirect('/product');
				});	
			});	
		}else{
			req.body.filetoupload='';
			req.body.name=fields.name;
			req.body.user=fields.user;
			req.body.group=fields.group;
			req.body.description=fields.description;
			req.body.status=fields.status;
			req.body.type=fields.type;
			req.body.category=fields.category;
			req.body.product_type=fields.product_type;
			var product = new Product(req.body);
			product.save(function(err, product) {
				if (err) throw err;
				productcategory 	=	fields.category;
				Category.findOneAndUpdate(
				   { _id: productcategory }, 
				   { $push: { product: product._id  } },
					function (error, success) {
						if (error) {
							console.log(error);
						} else {
							console.log(success);
						}
					}
				);
				req.flash('success', 'You have create a product successfully. Thank you');
				res.redirect('/product');
			});
		}
		
	
	
	});
});

router.post('/update/:id', function(req, res, next) {
	var currentPath = process.cwd();
	
	var form = new formidable.IncomingForm();
	form.parse(req, function (err, fields, files) {
			var oldpath = files.filetoupload.path;
		  	var newpath = currentPath +"/public/upload/product/"+ files.filetoupload.name;
			if(files.filetoupload.name !=''){
			  fs.rename(oldpath, newpath, function (err) {
				if (err) throw err;
				req.body.filetoupload=files.filetoupload.name;
				req.body.name=fields.name;
				req.body.user=fields.user;
				req.body.group=fields.group;
				req.body.description=fields.description;
				req.body.status=fields.status;
				req.body.type=fields.type;
				req.body.category=fields.category;
				req.body.product_type=fields.product_type;
				Product.findByIdAndUpdate(
					req.params.id,
					req.body,
					{new: true},
					(err, product) => {
						if (err) throw err;
						Category.findOneAndUpdate(
						   { _id: fields.category }, 
						   { $addToSet: { product: req.params.id  } },
							function (error, success) {
								if (error) {
									console.log(error);
								} else {
									console.log(success);
								}
							}
						);
						req.flash('success', 'You have updated product successfully. Thank you');
						res.redirect('/product');
					}
				)
			  });
			}else{
				req.body.name=fields.name;
				req.body.user=fields.user;
				req.body.group=fields.group;
				req.body.description=fields.description;
				req.body.status=fields.status;
				req.body.type=fields.type;
				req.body.category=fields.category;
				req.body.product_type=fields.product_type;
				Product.findByIdAndUpdate(
					req.params.id,
					req.body,
					{new: true},
					(err, product) => {
						if (err) throw err;
							Category.findOneAndUpdate(
							   { _id: fields.category }, 
							   { $addToSet: { product: req.params.id  } },
								function (error, success) {
									if (error) {
										console.log(error);
									} else {
										console.log(success);
									}
								}
							);
						req.flash('success', 'You have updated product successfully. Thank you');
						res.redirect('/product');
					}
				)
			}  
	 });
		
});

router.get('/delete/:id', function(req, res, next) {
		
	Product.findOneAndDelete({ _id: req.params.id }, function (err,result) {
			
			if (!result) {
				req.flash('error', 'Invalid Request');
				res.redirect('/product');
			}else{
				req.flash('success', 'product deleted successfully.');
				res.redirect('/product');
			}	
			
	});

});

module.exports = router;
