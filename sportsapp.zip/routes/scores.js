var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment'),
	Score = require('../models/score');
	FUNC = require('../lib/function');
/* GET Demands page. */
router.get('/', function(req, res) {

	Score.find({}, function (err, score) {
        res.render('score/index', { title: 'Score',scores:score,moment:moment });
    });
});

router.get('/check_scores', function(req, res) {
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1; 
	var yyyy = today.getFullYear();
	if (dd < 10) {
	  dd = '0' + dd;
	}

	if (mm < 10) {
	  mm = '0' + mm;
	}

	today = mm + '-' + dd + '-' + yyyy;	
	Sport.find({}, function (err, sport) {
		var currentDate = moment(today,'M/D/YYYY');
		var sportsDate = moment(sport.updated).format('MM-DD-YYYY');
		var datediff = FUNC.date_diff_indays(sportsDate,currentDate);
       	if(datediff >5){
			Sport.findOneAndDelete({ sport_id: sport.id });
		}
    });
	request('https://api.sportradar.us/content-nfl-t3/ap/news/'+yyyy+'/'+mm+'/'+dd+'/all.json?api_key=qqzd2nkfph43dq5dpxmxje7v', { json: true }, (err, response, body) => {
		if (err) {
			return console.log(err+'ssdaas'); 
		}else{
			(body.items).forEach(function(element) {
				
				req.body.sport_id=element.id;
				req.body.title=element.title;
				req.body.byline=element.byline;
				desc	=	element.content.long;
				req.body.content=desc;
				req.body.created=element.created;
				req.body.updated=element.updated;
				var sport = new Sport(req.body);
				sport.save(function(err, sport) {
					if (err) {
						req.flash('error', 'Invalid Request');
						res.redirect('/sports');
					}else{
						req.flash('success', 'sports imported successfully.');
						res.redirect('/sports');
					}
					
				});	
			 
			});
			
		}
		
	});
});
module.exports = router;