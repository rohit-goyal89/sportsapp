var express = require('express'),
	router = express.Router(),
	request = require('request'),
	moment = require('moment'),
	News = require('../models/news');
	FUNC = require('../lib/function');
	download = require('image-downloader');
	fs = require('fs');
/* GET Demands page. */
router.get('/', function(req, res) {
	res.locals.message = req.flash();
	News.find({}).sort({ updated : -1 }).exec(function (err, news) {
		    res.render('news/index', { title: 'News',newse:news,moment:moment });
    });
});

router.get('/check_news', function(req, res) {
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1; 
	var yyyy = today.getFullYear();
	if (dd < 10) {
	  dd = '0' + dd;
	}

	if (mm < 10) {
	  mm = '0' + mm;
	}

	today = mm + '-' + dd + '-' + yyyy;	
	
	//News.remove({league:'NFL',created:{$lte: new Date(yyyy,mm-1,dd-3)}}).then((news) => {		
		request('https://api.sportradar.us/content-nfl-t3/ap_premium/news/'+yyyy+'/'+mm+'/'+dd+'/all.json?api_key=hxjet32asv2v7wex9uurx5qe', { json: true }, (err, response, body) => {
		
			if (err) {
				return console.log(err+'ssdaas'); 
			}else{
				if(typeof body.items !='undefined' && (body.items).length>0){
					(body.items).forEach(function(element) {
						req.body.sport_id=element.id;
						req.body.title=element.title;
						req.body.byline=element.byline;
						req.body.league='NFL';
						desc	=	element.content.long;
						req.body.content=desc;
						req.body.image_file_url="";
						 if(typeof element.assets != "undefined"){
							if((element.assets[0].links).length > 0){
								req.body.image_file_url= "https://api.sportradar.us/content-nfl-t3/ap_premium"+element.assets[0].links[0].href+"?api_key=hxjet32asv2v7wex9uurx5qe";
							}
						} 
						
						
						req.body.created=element.created;
						req.body.updated=element.updated;
						
						var news = new News(req.body);
						news.save(function(err, news) {
							
							
						});	
					 
					});
					req.flash('success', 'News updated');
				}else{
					req.flash('error', 'News not found');
				}
				
				res.redirect('/news');
			}
		
		});
	//})

});

router.get('/update_nba_news', function(req, res) {
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1; 
	var yyyy = today.getFullYear();
	if (dd < 10) {
	  dd = '0' + dd;
	}
	if (mm < 10) {
	  mm = '0' + mm;
	}
	today = mm + '-' + dd + '-' + yyyy;	
	//News.remove({league:'NBA',created:{$lte: new Date(yyyy,mm-1,dd-3)}}).then((news) => { 
		request('http://api.sportradar.us/content-nba-t3/ap_premium/news/'+yyyy+'/'+mm+'/'+dd+'/all.json?api_key=t9kpg3h2dpf8bahzuwsm7dyt', { json: true }, (err, response, body) => {
		
			if (err) {
				return console.log(err+'ssdaas'); 
			}else{
				console.log(body.items);
				if(typeof body.items !='undefined' && (body.items).length>0){
					(body.items).forEach(function(element) {
						req.body.sport_id=element.id;
						req.body.title=element.title;
						req.body.byline=element.byline;
						req.body.league='NBA';
						desc	=	element.content.long;
						req.body.content=desc;
						req.body.image_file_url="";
						 if(typeof element.assets != "undefined"){
							if((element.assets[0].links).length > 0){
								req.body.image_file_url= "https://api.sportradar.us/content-nba-t3/ap_premium"+element.assets[0].links[0].href+"?api_key=t9kpg3h2dpf8bahzuwsm7dyt";
							}
						} 
						
						
						req.body.created=element.created;
						req.body.updated=element.updated;
						
						var news = new News(req.body);
						news.save(function(err, news) {
							
							
						});	
					 
					});
					req.flash('success', 'News updated');
				}else{
					req.flash('error', 'News not found');
				}
				
				res.redirect('/news');
			}
			
		});
	//})
	
});

router.get('/update_mlb_news', function(req, res) {
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth() + 1; 
	var yyyy = today.getFullYear();
	if (dd < 10) {
	  dd = '0' + dd;
	}

	if (mm < 10) {
	  mm = '0' + mm;
	}

	today = mm + '-' + dd + '-' + yyyy;	 
	//News.remove({league:'MLB',created:{$lte: new Date(yyyy,mm-1,dd-3)}}).then((news) => {
	request('https://api.sportradar.us/content-mlb-t3/ap_premium/news/'+yyyy+'/'+mm+'/'+dd+'/all.json?api_key=pt8nqbb5r53zwtdmy7935v74', { json: true }, (err, response, body) => {
		
		if (err) {
			return console.log(err+'ssdaas'); 
		}else{
			if(typeof body.items !='undefined' && (body.items).length>0){
				(body.items).forEach(function(element) {
					req.body.sport_id=element.id;
					req.body.title=element.title;
					req.body.byline=element.byline;
					req.body.league='MLB';
					desc	=	element.content.long;
					
					req.body.content=desc;
					req.body.image_file_url="";
					 if(typeof element.assets != "undefined"){
						if((element.assets[0].links).length > 0){
							req.body.image_file_url= "https://api.sportradar.us/content-mlb-t3/ap_premium"+element.assets[0].links[0].href+"?api_key=pt8nqbb5r53zwtdmy7935v74";
						}
					} 
					
					
					req.body.created=element.created;
					req.body.updated=element.updated;
					
					var news = new News(req.body);
					news.save(function(err, news) {
						
						if(err){
							console.log(err);
						}
					});	
				 
				});
				req.flash('success', 'News updated');
			}else{
				req.flash('error', 'News not found');
			}
			
			res.redirect('/news');
		}
		
	});
	  //});
});

router.get('/update_nhl_news', function(req, res) {
	var today = new Date();
	var dd = today.getDate() - 1;
	var mm = today.getMonth() + 1; 
	var yyyy = today.getFullYear();
	if (dd < 10) {
	  dd = '0' + dd ;
	}

	if (mm < 10) {
	  mm = '0' + mm;
	}
	today = mm + '-' + dd + '-' + yyyy;	
	//News.remove({league:'NHL',created:{$lte: new Date(yyyy,mm-1,dd-3)}}).then((news) => {  
	request('http://api.sportradar.us/content-nhl-t3/ap_premium/news/'+yyyy+'/'+mm+'/'+dd+'/all.json?api_key=88ndx7zmfdut84at79s6yaxr', { json: true }, (err, response, body) => {
		
		if (err) {
			return console.log(err+'ssdaas'); 
		}else{
			if(typeof body.items !='undefined' && (body.items).length>0){
				(body.items).forEach(function(element) {
					req.body.sport_id=element.id;
					req.body.title=element.title;
					req.body.byline=element.byline;
					req.body.league='NHL';
					desc	=	element.content.long;
					req.body.content=desc;
					req.body.image_file_url="";
					if(typeof element.assets != "undefined"){
						if((element.assets[0].links).length > 0){
							var dir  =  "/var/sports/public/upload/news/nhl/"+element.assets[0].id;
							const options = {
								  url: "https://api.sportradar.us/content-nhl-t3/ap_premium"+element.assets[0].links[0].href+"?api_key=88ndx7zmfdut84at79s6yaxr",
								  dest: dir                  
							}
							if (!fs.existsSync(dir) ) {
								fs.mkdirSync(dir);
								console.log(options); 
								try {
								  const { filename, image } =  download.image(options);
								  req.body.image_file_url= "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/news/nhl/"+element.assets[0].id+"/h1000-max-resize.jpg";
								} catch (e) {
								  console.error("file error: "+e)
								}

							}
							
						}
					} 
					
					
					req.body.created=element.created;
					req.body.updated=element.updated;
					
					var news = new News(req.body);
					news.save(function(err, news) {
						
						if(err){
							console.log(err);
						}
					});	
				 
				});
				req.flash('success', 'News updated');
			}else{
				req.flash('error', 'News not found');
			}
			
			
		}
		
	//});
	res.redirect('/news');
	  });
});

module.exports = router;