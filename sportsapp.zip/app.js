const express = require('express');
var formidable = require('formidable');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const shortid = require('shortid');
const session = require('express-session'); //we're using 'express-session' as 'session' here
const bcrypt = require("bcrypt"); // 
const app = express();
const PORT = 3001; // you can change this if this port number is not available
var contact = require('./routes/contact'),
	moment = require('moment'),
	async = require('async'),
	download = require('image-downloader'),
    dt = require('./lib/function');
	
const request = require('request');
const fs = require('fs');
const path = require('path');
//connect to database
mongoose.connect('mongodb://172.31.14.103:27017/sportsapp', { useNewUrlParser: true,useCreateIndex: true });
mongoose.set('debug', true);
// define database schemas
User = require('./models/user'); 
News = require('./models/news');
Games = require('./models/game');
Score = require('./models/score');
Event = require('./models/event');
Demand = require('./models/demand');
DemandNew = require('./models/demandNew');
ScoreDrives = require('./models/score_drives');
SportsRadarScore = require('./models/sports_radar_score'),
SportsRadarDrive = require('./models/sports_radar_score_drives');
Comment = require('./models/comment');
Post = require('./models/post');
Standing = require('./models/standing');
Venue = require('./models/venue');
Leaders = require('./models/leaders');
Conference = require('./models/conference');
Division = require('./models/division');
Player = require('./models/player');
Venues = require('./models/venue');
NflLeaders = require('./models/nflleaders');
Fddemand = require('./models/fddemand');
Vote = require('./models/vote');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true }));
app.use(
  session({
    secret: "iy98hcbh489n38984y4h498",
    resave: true,
    saveUninitialized: false
  })
);
app.set('siteUrl', 'http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000');
/*
=============
*/
app.get('/', (req, res) => {

  res.send('Welcome to the Home of our APP '+ dt.myDateTime());
})

/*
1. User Sign up
=============
*/
app.post('/signup', function(req, res, next) {
  req.body.role = 2;
  let {username, email,fname,lname,password} = req.body; 
  let userData = {
      username,
      email,
      role:2,
      password, 
      fname,
      lname
    };  
  var user = new User(userData);
   var response = {};
    user.save(function(err, user) {
        if (err) {
           
           if(err.errors.fname){
              response.message  =  err.errors.fname.message; 
           }else if(err.errors.lname){
              response.message  =  err.errors.lname.message; 
           }else if(err.errors.username){
             response.message  =  err.errors.username.message; 
           }else if(err.errors.email){
              response.message  =  err.errors.email.message;
           }else if(err.errors.password){
              response.message  =  err.errors.password.message;
           }
            response.status = false;
           res.status(400).send(JSON.stringify(response));
        }else{
           response.message = "You are signup successfully!";
           response.status = true;
           response.userData = user;
           res.status(200).send(JSON.stringify(response));
        }
    }); 

});


/*
2. User Sign in
=============
*/
app.post('/login', (req, res) => {
  let {username, password} = req.body;
    User.findOne({username: username}, 'username email password', (err, userData) => {
    	if (!err) {
        	let passwordCheck = bcrypt.compareSync(password, userData.password);
          var response = {};
        	if (passwordCheck) { 
                response.message = "You are logged in, Welcome!";
                response.status = true;
                response.userData = userData;
                   
                res.status(200).send(JSON.stringify(response));
            } else {
              response.message = "incorrect password!";
              response.status = false;
            	res.status(400).send(JSON.stringify(response));
            }
        } else {
            response.message = "invalid login credentials!";
            response.status = false;
        	   res.status(400).send(JSON.stringify(response));
        }
    })
})

app.post('/events', (req, res) => {
   var response = {};
    if(req.body.year){
        var startdate = req.body.year+'-01-01';
        var enddate   = req.body.year+'-12-31';
        request('https://api.seatgeek.com/2/events?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ&per_page=300&datetime_utc.gte='+startdate+'&datetime_utc.lte='+enddate+'&sort=datetime_local.desc', { json: true }, (err, response, body) => {
            if (err) {
                response.message = err;
                response.status = false;
                res.status(400).send(JSON.stringify(response));
            }else{
              response.message = "Event Listing";
              response.status = true;
              response.eventData = body.events;
              res.status(200).send(JSON.stringify(response));
            }
              
        });
    }else{
          response.message = "Invalid request";
          response.status = false;
          res.status(400).send(JSON.stringify(response));
    }
    
})

app.get('/categories', (req, res) => {
   var response = {};
  
  request('https://api.seatgeek.com/2/taxonomies?client_id=MTEwOTg0Nzh8MTUyMjc4OTE5Mi4yOQ', { json: true }, (err, response, body) => {
    if (err) {
      response.message = err;
      response.status = false;
      res.status(400).send(JSON.stringify(response));
    }else{
      response.message = "Category Listing";
      response.status = true;
        
      response.taxonomyData = body.taxonomies;
      res.status(200).send(JSON.stringify(response));
    }
      
  });
    
})

app.get('/gamescore/:league', (req, res) => {
	var response = {};
	var dateobj = new Date();
    var yy  =  dateobj.getFullYear(); 
    var mm  = (dateobj.getMonth()+1) ; 
    var dd  = dateobj.getDate();
	if(dd <	10){
			dd	=	"01";
	}
	if(mm < 10){
		mm	=	"0"+mm;
	}
	today =  yy+'-'+mm+'-'+dd ;	
	//console.log(today);
	Score.find({league : req.params.league,created: {$gte: new Date(yy,mm,dd,0,0,0).toISOString() }}).select({"_id": 1,"game_id":1,"home_name": 1,"home_points":1,"away_name":1,"away_points":1,"status":1,"created":1,"away_logo":1,"home_logo":1,"venue_id":1,"venue_logo":1}).sort({created:1}).exec( function (err, gameScores) {  
		objScores	=	[];
		if (gameScores) { 				
			if(gameScores.length>0){
				j=0;
				gameScores.forEach(function(gscore) {
					scoreData	=	{};
					scoreData['game_id']	=	gscore.game_id;
					var home_str = gscore.home_name;
					home_name_index = home_str.lastIndexOf(" ");
					home_str = home_str.substring(0, home_name_index);
					if(home_name_index >0){
						scoreData['home_name']  =  home_str;
					}else{
						scoreData['home_name']	=	gscore.home_name; 
					}
					
					//scoreData['home_name']	=	gscore.home_name; 
					//scoreData['home_name']	=	gscore.home_name; 
					if(typeof gscore.home_points !="undefined"){
					   scoreData['home_points']  =  gscore.home_points;
					}else{
					   scoreData['home_points']  =  0;
					}
					var away_str = gscore.away_name;
					away_name_index = away_str.lastIndexOf(" ");
					away_str = away_str.substring(0, away_name_index);
					if(away_name_index >0){
						scoreData['away_name']  =  away_str;
					}else{
						scoreData['away_name']	=	gscore.away_name; 
					}
					//scoreData['away_name']  =  gscore.away_name;
					if(typeof gscore.away_points !="undefined"){
						scoreData['away_points']  =  gscore.away_points;
					}else{
					   scoreData['away_points']  =  0;
					}
					if(typeof gscore.home_logo !="undefined"){
						scoreData['home_logo']  =  app.get('siteUrl')+gscore.home_logo;
					}else{ 
					   scoreData['home_logo']  =  "";
					}
					if(typeof gscore.away_logo !="undefined"){
						scoreData['away_logo']  =  app.get('siteUrl')+gscore.away_logo;
					}else{
					   scoreData['away_logo']  =  "";
					}
					if(typeof gscore.venue_logo !="undefined"){
						scoreData['venue_logo']  =  gscore.venue_logo;
					}else{
					   scoreData['venue_logo']  =  "";
					}
					scoreData['status']	=	gscore.status;
					scoreData['created']	=	moment(gscore.created).format("YYYY-MM-DD HH:mm");
					objScores.push(scoreData);
					j++;
				})
			} 
			response.scores = objScores;
			response.status = true;
			res.status(200).send(JSON.stringify(response));
		}else{
			response.scores = "No Data!";
			response.status = false;
			res.status(400).send(JSON.stringify(response));
		}		
			
	})
})

app.get('/gamescore_tab/:league', (req, res) => {
    var response = {};
  var dateobj = new Date();
    var yy  =  dateobj.getFullYear(); 
    var mm  = (dateobj.getMonth()) ; 
    var dd  = dateobj.getDate();
  if(dd <  10){
      dd  =  "01";
  }
  if(mm < 10){
    mm  =  "0"+mm;
  }
  today =  yy+'-'+mm+'-'+dd ;  
	if(req.params.league=="NHL"){
		Score.aggregate([ {$match:{league : req.params.league}},
			{"$lookup": {
				"from": "demandnews", 
				"localField": "created",
				"foreignField": "datetime",
				"as": "Demands"
			}
		},{ $group : {_id:{ "day": { $dayOfMonth: "$created" },"month" : { "$month" : "$created"} , "year" : { "$year" : "$created"}},records: { $push: "$$ROOT" } }}, {$sort:{"_id.year":1,"_id.month":1,"_id.day":1}}]).exec( function (err, gameScores) {
			objScores  =  [];
			if (gameScores) {         
			  if(gameScores.length>0){
			   
				 

				gameScores.forEach(function(gscore) {
				  var j=0;
				  //console.log(gscore.records);
				  if(gscore._id.day <  10){
					  gscore._id.day  =  "0"+gscore._id.day;
				  }
				  if(gscore._id.month < 10){
					gscore._id.month  =  "0"+gscore._id.month;
				  }
				  var dateStr  =  gscore._id.day + "-"+ gscore._id.month+ "-"+ gscore._id.year;
				 var scoreDataArr  =  [];
				   if((gscore.records).length>0){
					 (gscore.records).forEach(function(gsr) {
						 if(req.params.league=="NBA"){
							 var  today = new Date("2019-03-01");
						 }else{
							  var  today = new Date("2018-12-31");
						 }
						 
						var dd = "0"+today.getDate();
						var mm = "0"+(today.getMonth()); 
						var yyyy = today.getFullYear();
						 var  scheduledate = new Date(gsr.created);
						var dd1 = scheduledate.getDate();
						var mm1 = scheduledate.getMonth(); 
						var yyyy1 = scheduledate.getFullYear();
						var dateOne = new Date(yyyy1, mm1, dd1);
						var rescheduledate	=	new Date(yyyy, mm, dd); 
						if(dateOne	>=	rescheduledate){
						 var scoreData  =  {};
						 scoreData['matchDate']  =  dateStr; 
						 scoreData['game_id']  =  gsr.game_id; 
						var home_str = gsr.home_name;
						home_name_index = home_str.lastIndexOf(" ");
						home_str = home_str.substring(0, home_name_index);
						if(home_name_index >0){
							scoreData['home_name']  =  home_str;
						}else{
							scoreData['home_name']	=	gsr.home_name; 
						}
						 //scoreData['home_name']  =  gsr.home_name; 
						 if(typeof gsr.home_points !="undefined"){
						   scoreData['home_points']  =  gsr.home_points;
						}else{
						   scoreData['home_points']  =  0;
						}
						var away_str = gsr.away_name;
						away_name_index = away_str.lastIndexOf(" ");
						away_str = away_str.substring(0, away_name_index);
						if(away_name_index >0){
							scoreData['away_name']  =  away_str;
						}else{
							scoreData['away_name']	=	gsr.away_name; 
						}
						if(typeof gsr.away_points !="undefined"){
						  scoreData['away_points']  =  gsr.away_points;
						}else{
						   scoreData['away_points']  =  0;
						}
						if(typeof gsr.home_logo !="undefined"){
						  scoreData['home_logo']  =  app.get('siteUrl')+gsr.home_logo;
						}else{ 
						   scoreData['home_logo']  =  "";
						}
						if(typeof gsr.away_logo !="undefined"){
						  scoreData['away_logo']  =  app.get('siteUrl')+gsr.away_logo;
						}else{
						   scoreData['away_logo']  =  "";
						}
						if(typeof gsr.venue_logo !="undefined"){
						  scoreData['venue_logo']  =  gsr.venue_logo;
						}else{
						   scoreData['venue_logo']  =  "";
						}
						/* if(gsr.game_id=="ad920035-d643-496c-932d-4460264d255c"){
							console.log(gsr);
						} */
						if((gsr.Demands).length >0){
							var flag=0;
							async.forEach(gsr.Demands,function(gsdemand) {
								if ((gsdemand.title).indexOf(gsr.home_name) !=-1) {
									flag=1;
									scoreData['fd_rating']  =  (gsdemand.demand).toFixed(2);
									scoreData['change_demand']  =  (gsdemand.change_demand).toFixed(2);
								}
							})
							if(flag==0){
								scoreData['fd_rating']  =  "-";
								scoreData['change_demand']  =  "-";
							}
						}else{
							scoreData['fd_rating']  =  "-";
							scoreData['change_demand']  =  "-";
						}
					
						scoreData['status']  =  gsr.status;
						scoreData['created']  =  moment(gsr.dateutc).format("YYYY-MM-DD HH:mm");
						(scoreDataArr ).push(scoreData);
						}
					 })
				   }
				  
				  
				  j++;
				  if(scoreDataArr.length>0){
					  scoreDataArr = dt.sortByKey(scoreDataArr,'fd_rating');
					  scoreDataArr = dt.sortByDate(scoreDataArr,'created');
					  (objScores).push(scoreDataArr);
				  }
				  
				})
			  }
			  response.scores = objScores;
			  response.status = true;
			  res.status(200).send(JSON.stringify(response));
			}else{
			  response.scores = "No Data!";
			  response.status = false;
			  res.status(400).send(JSON.stringify(response));
			}    
			  
		})
	}else{
		Score.aggregate([ {$match:{league : req.params.league}},
			{"$lookup": {
				"from": "demands", 
				"localField": "created",
				"foreignField": "datetime",
				"as": "Demands"
			}
		},{ $group : {_id:{ "day": { $dayOfMonth: "$created" },"month" : { "$month" : "$created"} , "year" : { "$year" : "$created"}},records: { $push: "$$ROOT" } }}, {$sort:{"_id.year":1,"_id.month":1,"_id.day":1}}]).exec( function (err, gameScores) {
			objScores  =  [];
			if (gameScores) {         
			  if(gameScores.length>0){
			   
				 

				gameScores.forEach(function(gscore) {
				  var j=0;
				  //console.log(gscore.records);
				  if(gscore._id.day <  10){
					  gscore._id.day  =  "0"+gscore._id.day;
				  }
				  if(gscore._id.month < 10){
					gscore._id.month  =  "0"+gscore._id.month;
				  }
				  var dateStr  =  gscore._id.day + "-"+ gscore._id.month+ "-"+ gscore._id.year;
				 var scoreDataArr  =  [];
				   if((gscore.records).length>0){
					 (gscore.records).forEach(function(gsr) {
						 if(req.params.league=="NBA"){
							 var  today = new Date("2019-03-01");
						 }else{
							  var  today = new Date("2019-01-31");
						 }
						 
						var dd = "0"+today.getDate();
						var mm = "0"+(today.getMonth()); 
						var yyyy = today.getFullYear();
						 var  scheduledate = new Date(gsr.created);
						var dd1 = scheduledate.getDate();
						var mm1 = scheduledate.getMonth(); 
						var yyyy1 = scheduledate.getFullYear();
						var dateOne = new Date(yyyy1, mm1, dd1);
						var rescheduledate	=	new Date(yyyy, mm, dd); 
						if(dateOne	>=	rescheduledate){
						 var scoreData  =  {};
						 scoreData['matchDate']  =  dateStr; 
						 scoreData['game_id']  =  gsr.game_id; 
						var home_str = gsr.home_name;
						home_name_index = home_str.lastIndexOf(" ");
						home_str = home_str.substring(0, home_name_index);
						if(home_name_index >0){
							scoreData['home_name']  =  home_str;
						}else{
							scoreData['home_name']	=	gsr.home_name; 
						}
						 //scoreData['home_name']  =  gsr.home_name; 
						 if(typeof gsr.home_points !="undefined"){
						   scoreData['home_points']  =  gsr.home_points;
						}else{
						   scoreData['home_points']  =  0;
						}
						var away_str = gsr.away_name;
						away_name_index = away_str.lastIndexOf(" ");
						away_str = away_str.substring(0, away_name_index);
						if(away_name_index >0){
							scoreData['away_name']  =  away_str;
						}else{
							scoreData['away_name']	=	gsr.away_name; 
						}
						if(typeof gsr.away_points !="undefined"){
						  scoreData['away_points']  =  gsr.away_points;
						}else{
						   scoreData['away_points']  =  0;
						}
						if(typeof gsr.home_logo !="undefined"){
						  scoreData['home_logo']  =  app.get('siteUrl')+gsr.home_logo;
						}else{ 
						   scoreData['home_logo']  =  "";
						}
						if(typeof gsr.away_logo !="undefined"){
						  scoreData['away_logo']  =  app.get('siteUrl')+gsr.away_logo;
						}else{
						   scoreData['away_logo']  =  "";
						}
						if(typeof gsr.venue_logo !="undefined"){
						  scoreData['venue_logo']  =  gsr.venue_logo;
						}else{
						   scoreData['venue_logo']  =  "";
						}
						if((gsr.Demands).length >0){
							if ((gsr.Demands[0].title).indexOf(gsr.home_name) !=-1) {
								scoreData['fd_rating']  =  (gsr.Demands[0].demand).toFixed(2);
								scoreData['change_demand']  =  (gsr.Demands[0].change_demand).toFixed(2);
							}else{
								scoreData['fd_rating']  =  "-";
								scoreData['change_demand']  =  "-";
							}
						}else{
							scoreData['fd_rating']  =  "-";
							scoreData['change_demand']  =  "-";
						}
					
						scoreData['status']  =  gsr.status;
						scoreData['created']  =  moment(gsr.created).format("YYYY-MM-DD HH:mm");
						(scoreDataArr ).push(scoreData);
						}
					 })
				   }
				  
				  
				  j++;
				  if(scoreDataArr.length>0){
					  scoreDataArr = dt.sortByKey(scoreDataArr,'fd_rating');
					  (objScores).push(scoreDataArr);
				  }
				  
				})
			  }
			  response.scores = objScores;
			  response.status = true;
			  res.status(200).send(JSON.stringify(response));
			}else{
			  response.scores = "No Data!";
			  response.status = false;
			  res.status(400).send(JSON.stringify(response));
			}    
			  
		})
	}

})

app.get('/hubData/:league', (req, res) => {
	var response = {};
	var dateobj = new Date();
    var yy  =  dateobj.getFullYear(); 
    var mm  = (dateobj.getMonth()) ; 
    var dd  = dateobj.getDate();
	if(dd <	10){
			dd	=	"01";
	}
	if(mm < 10){
		mm	=	"0"+mm;
	}
	today =  yy+'-'+mm+'-'+dd ;
console.log(today);
 Score.find({league : req.params.league,created: {$gte: new Date(yy,mm,dd-1,0,0,0).toISOString(),$lte: new Date(yy,mm,dd,0,0,0).toISOString()  }}).select({"_id": 1,"game_id":1,"home_name": 1,"home_color": 1,"home_points":1,"away_name":1,"away_points":1,"away_color": 1,"status":1,"created":1,"away_logo":1,"home_logo":1,"venue_id":1,"venue_logo":1}).sort({created:1}).then((gameScores) => {  
	News.find({league : req.params.league,created: {$gte: new Date(yy,mm,dd-4,0,0,0).toISOString(),$lte: new Date(yy,mm,dd,0,0,0).toISOString()  }}).select({"_id": 1,"title": 1,"content":1,"image_file_url":1}).then((newsData) => {
		if(req.params.league=="NHL"){
			DemandNew.find({ type : req.params.league }).sort({"dateutc":1}).exec( function (err, events) {
				objScores	=	[];
				if (gameScores) { 				
					if(gameScores.length>0){
						j=0;
						gameScores.forEach(function(gscore) {
							scoreData	=	{};
							scoreData['game_id']	=	gscore.game_id;
							var home_str = gscore.home_name;
							home_name_index = home_str.lastIndexOf(" ");
							home_str = home_str.substring(0, home_name_index);
							if(home_name_index >0){
								scoreData['home_name']  =  home_str;
							}else{
								scoreData['home_name']	=	gscore.home_name; 
							}
							
							if(typeof gscore.home_points !="undefined"){
							   scoreData['home_points']  =  gscore.home_points;
							}else{
							   scoreData['home_points']  =  0;
							}
							var away_str = gscore.away_name;
							away_name_index = away_str.lastIndexOf(" ");
							away_str = away_str.substring(0, away_name_index);
							if(away_name_index >0){
								scoreData['away_name']  =  away_str;
							}else{
								scoreData['away_name']  =  gscore.away_name;
							}
							
							if(typeof gscore.away_points !="undefined"){
								scoreData['away_points']  =  gscore.away_points;
							}else{
							   scoreData['away_points']  =  0;
							}
							if(typeof gscore.home_logo !="undefined"){
								scoreData['home_logo']  =  app.get('siteUrl')+gscore.home_logo;
							}else{
							   scoreData['home_logo']  =  "";
							}
							if(typeof gscore.away_logo !="undefined"){
								scoreData['away_logo']  =  app.get('siteUrl')+gscore.away_logo;
							}else{
							   scoreData['away_logo']  =  "";
							}
							if(typeof gscore.home_color != "undefined"){
								scoreData['home_color']  =  gscore.home_color;
							}else{
							   scoreData['home_color']  =  "";
							}
							if(typeof gscore.away_color !="undefined"){
								scoreData['away_color']  =  gscore.away_color;
							}else{
							   scoreData['away_color']  =  "";
							}
							if(typeof gscore.venue_logo !="undefined"){
								scoreData['venue_logo']  =  gscore.venue_logo;
							}else{
							   scoreData['venue_logo']  =  "";
							}
							scoreData['status']	=	gscore.status;
							scoreData['created']	=	moment(gscore.created).format("YYYY-MM-DD HH:mm");
							objScores.push(scoreData);
							j++;
						})
					} 
			   }		
				response.scores = objScores;
				if (newsData) { 
					objNews	=	[];
					newsData.forEach(function(newsList) {
						eventArr	=	{};
						eventArr['_id']	=	newsList._id;
						eventArr['title']	=	newsList.title;
						eventArr['content']	=	newsList.content;
						eventArr['image_file_url']	=	newsList.image_file_url;
						objNews.push(eventArr);
					})
					response.gamenews = objNews;
				} else {
					response.gamenews = "No Data!";
				}
				
			
				if (events) { 
					objEvent	=	[];
					if(events.length>0){
						i=0;
						events.forEach(function(demand) {
							var  today = new Date();
							var dd = today.getDate() - 1;
							
							var mm = today.getMonth(); 
							if(dd <	10){
									dd	=	"0"+dd;
							}
							if(mm < 10){
								mm	=	"0"+mm;
							}
							var yyyy = today.getFullYear();
							 var  scheduledate = new Date(demand.dateutc);
							var dd1 = scheduledate.getDate();
							var mm1 = scheduledate.getMonth(); 
							var yyyy1 = scheduledate.getFullYear();
							var dateOne = new Date(yyyy1, mm1, dd1);
							
							var rescheduledate	=	new Date(yyyy, mm, dd);
						//if((dateOne - rescheduledate)	>=	0){						
							eventData	=	{};
								if((demand.title).indexOf(' at ')!=-1){
									var teamStr = (demand.title).split(" at ");
									
									
									awayTeam	=	teamStr[1].split(" - ");
									if(req.params.league =="NHL" || req.params.league =="MLB"){
									//	hometeam =	(teamStr[0]).replace("Spring Training: ","");
										hometeam =	(teamStr[0]).split(": ");
										if(hometeam.length>1){
											var updateHometeam	=	hometeam[1];
										}else{
											var updateHometeam	=	hometeam[0];
										}
										eventData['home_team']	=	updateHometeam;
										eventData['away_team']	=	awayTeam[0];
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(updateHometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam[0])+'.png';
									}else if(req.params.league =="NFL" || req.params.league =="NBA"){
										//hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
										hometeam =	(teamStr[0]).split(": ");
										if(hometeam.length>1){
											var updateHometeam	=	hometeam[1];
										}else{
											var updateHometeam	=	hometeam[0];
										}
										eventData['home_team']	=	updateHometeam;
										eventData['away_team']	=	awayTeam[0];
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(updateHometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam[0])+'.png';
									}
									
								}else if((demand.title).indexOf(' vs. ')!=-1){
									var teamStr = (demand.title).split(" vs. ");
									hometeam =	(teamStr[0]).replace("Spring Training: ","");
									awayTeam	=	teamStr[1].split(" - ");
									if(req.params.league =="NHL" || req.params.league =="MLB"){
										//hometeam =	(teamStr[0]).replace("Spring Training: ","");
										hometeam =	(teamStr[0]).split(": ");
										if(hometeam.length>1){
											var updateHometeam	=	hometeam[1];
										}else{
											var updateHometeam	=	hometeam[0];
										}
										eventData['home_team']	=	updateHometeam;
										eventData['away_team']	=	awayTeam[0];
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(updateHometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam[0])+'.png';
									}else if(req.params.league =="NFL" || req.params.league =="NBA"){
										//hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
										hometeam =	(teamStr[0]).split(": ");
										if(hometeam.length>1){
											var updateHometeam	=	hometeam[1];
										}else{
											var updateHometeam	=	hometeam[0];
										}
										eventData['home_team']	=	updateHometeam;
										eventData['away_team']	=	awayTeam[0];
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(updateHometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam[0])+'.png';
									}
								}else{
									eventData['home_team']	=	"";
									eventData['away_team']	=	"";
									eventData['home_team_logo']  = "";
									eventData['away_team_logo']  = "";
								}
								eventData['title']	=	demand.title;
								eventData['seatmap']	=	demand.seatmap;
								eventData['venue_location']	=	demand.venue_location;
								eventData['venue']	=	demand.venue;
								eventData['dateutc']	=	moment(demand.dateutc).format("YYYY-MM-DD HH:mm");
								eventData['description']	=	"";
								eventData['venue_image']	=	demand.venue_image;
								changeDemand=0;
								eventData['demand']	= demand.average_price - demand.max_price;
								if(demand.average_price_old ==null){
									changeDemand = 	 0;
								}else{
									changeDemand = 	 demand.average_price - demand.average_price_old;
								}
								/* if(changeDemand == eventData['demand']){
									eventData['change_demand']	= 0;
								}else{
									eventData['change_demand']	= Number(changeDemand);
								} */
								eventData['change_demand']	= Number(changeDemand);
								if(changeDemand < 0){
									eventData['status']	= 'negative'; 
								}else{
									eventData['status']	= 'positive';
								}
								 
								objEvent.push(eventData);
								i++;
						//}	
						})
					}	
					response.fanDemand = dt.sortByKey(objEvent,'demand');
					response.status = true;
					res.status(200).send(JSON.stringify(response));
				} else {
					response.fanDemand = "No Data!";
					response.status = false;
					res.status(400).send(JSON.stringify(response));
				}
			
			});    

		}else{
			Demand.find({ type : req.params.league }).sort({"dateutc":1}).exec( function (err, events) {
				objScores	=	[];
				if (gameScores) { 				
					if(gameScores.length>0){
						j=0;
						gameScores.forEach(function(gscore) {
							scoreData	=	{};
							scoreData['game_id']	=	gscore.game_id;
							var home_str = gscore.home_name;
							home_name_index = home_str.lastIndexOf(" ");
							home_str = home_str.substring(0, home_name_index);
							if(home_name_index >0){
								scoreData['home_name']  =  home_str;
							}else{
								scoreData['home_name']	=	gscore.home_name; 
							}
							
							if(typeof gscore.home_points !="undefined"){
							   scoreData['home_points']  =  gscore.home_points;
							}else{
							   scoreData['home_points']  =  0;
							}
							var away_str = gscore.away_name;
							away_name_index = away_str.lastIndexOf(" ");
							away_str = away_str.substring(0, away_name_index);
							if(away_name_index >0){
								scoreData['away_name']  =  away_str;
							}else{
								scoreData['away_name']  =  gscore.away_name;
							}
							
							if(typeof gscore.away_points !="undefined"){
								scoreData['away_points']  =  gscore.away_points;
							}else{
							   scoreData['away_points']  =  0;
							}
							if(typeof gscore.home_logo !="undefined"){
								scoreData['home_logo']  =  app.get('siteUrl')+gscore.home_logo;
							}else{
							   scoreData['home_logo']  =  "";
							}
							if(typeof gscore.away_logo !="undefined"){
								scoreData['away_logo']  =  app.get('siteUrl')+gscore.away_logo;
							}else{
							   scoreData['away_logo']  =  "";
							}
							if(typeof gscore.home_color != "undefined"){
								scoreData['home_color']  =  gscore.home_color;
							}else{
							   scoreData['home_color']  =  "";
							}
							if(typeof gscore.away_color !="undefined"){
								scoreData['away_color']  =  gscore.away_color;
							}else{
							   scoreData['away_color']  =  "";
							}
							if(typeof gscore.venue_logo !="undefined"){
								scoreData['venue_logo']  =  gscore.venue_logo;
							}else{
							   scoreData['venue_logo']  =  "";
							}
							scoreData['status']	=	gscore.status;
							scoreData['created']	=	moment(gscore.created).format("YYYY-MM-DD HH:mm");
							objScores.push(scoreData);
							j++;
						})
					} 
			   }		
				response.scores = objScores;
				if (newsData) { 
					objNews	=	[];
					newsData.forEach(function(newsList) {
						eventArr	=	{};
						eventArr['_id']	=	newsList._id;
						eventArr['title']	=	newsList.title;
						eventArr['content']	=	newsList.content;
						eventArr['image_file_url']	=	newsList.image_file_url;
						objNews.push(eventArr);
					})
					response.gamenews = objNews;
				} else {
					response.gamenews = "No Data!";
				}
				
			
				if (events) { 
					objEvent	=	[];
					if(events.length>0){
						i=0;
						events.forEach(function(demand) {
							var  today = new Date();
							var dd = today.getDate() - 1;
							
							var mm = today.getMonth(); 
							if(dd <	10){
									dd	=	"0"+dd;
							}
							if(mm < 10){
								mm	=	"0"+mm;
							}
							var yyyy = today.getFullYear();
							 var  scheduledate = new Date(demand.dateutc);
							var dd1 = scheduledate.getDate();
							var mm1 = scheduledate.getMonth(); 
							var yyyy1 = scheduledate.getFullYear();
							var dateOne = new Date(yyyy1, mm1, dd1);
							
							var rescheduledate	=	new Date(yyyy, mm, dd);
						//if((dateOne - rescheduledate)	>=	0){						
							eventData	=	{};
								if((demand.title).indexOf(' at ')!=-1){
									var teamStr = (demand.title).split(" at ");
									
									
									awayTeam	=	teamStr[1];
									if(req.params.league =="NHL" || req.params.league =="MLB"){
										hometeam =	(teamStr[0]).replace("Spring Training: ","");
										eventData['home_team']	=	hometeam;
										eventData['away_team']	=	awayTeam;
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(hometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam)+'.png';
									}else if(req.params.league =="NFL" || req.params.league =="NBA"){
										hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
										eventData['home_team']	=	hometeam;
										eventData['away_team']	=	awayTeam;
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(hometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam)+'.png';
									}
									
								}else if((demand.title).indexOf(' vs. ')!=-1){
									var teamStr = (demand.title).split(" vs. ");
									hometeam =	(teamStr[0]).replace("Spring Training: ","");
									awayTeam	=	teamStr[1];
									if(req.params.league =="NHL" || req.params.league =="MLB"){
										hometeam =	(teamStr[0]).replace("Spring Training: ","");
										eventData['home_team']	=	hometeam;
										eventData['away_team']	=	awayTeam;
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(hometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam)+'.png';
									}else if(req.params.league =="NFL" || req.params.league =="NBA"){
										hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
										eventData['home_team']	=	hometeam;
										eventData['away_team']	=	awayTeam;
										eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(hometeam)+'.png';
										eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam)+'.png';
									}
								}else{
									eventData['home_team']	=	"";
									eventData['away_team']	=	"";
									eventData['home_team_logo']  = "";
									eventData['away_team_logo']  = "";
								}
								eventData['title']	=	demand.title;
								eventData['seatmap']	=	demand.seatmap;
								eventData['venue_location']	=	demand.venue_location;
								eventData['venue']	=	demand.venue;
								eventData['dateutc']	=	moment(demand.dateutc).format("YYYY-MM-DD HH:mm");
								eventData['description']	=	"";
								eventData['venue_image']	=	demand.venue_image;
								changeDemand=0;
								eventData['demand']	= demand.average_price - ((demand.max_price + demand.min_price)/2);
								changeDemand = 	 eventData['demand'] - (demand.average_price_old - ((demand.max_price_old + demand.min_price_old)/2));
								if(changeDemand == eventData['demand']){
									eventData['change_demand']	= 0;
								}else{
									eventData['change_demand']	= Number(changeDemand);
								}
								
								if(changeDemand < 0){
									eventData['status']	= 'negative'; 
								}else{
									eventData['status']	= 'positive';
								}
								 
								objEvent.push(eventData);
								i++;
						//}	
						})
					}	
					response.fanDemand = dt.sortByKey(objEvent,'demand');
					response.status = true;
					res.status(200).send(JSON.stringify(response));
				} else {
					response.fanDemand = "No Data!";
					response.status = false;
					res.status(400).send(JSON.stringify(response));
				}
			
			});    
		}
	});
	});

	
})

app.get('/scoreFandemand/:timeparam/:venue', (req, res) => {
	var response = {};
	Demand.findOne({datetime:req.params.timeparam,venue:req.params.venue}).exec(function(err,demandData){
		if(demandData){
			response.demand = demandData;
			response.status = true;
			res.status(200).send(JSON.stringify(response));
		}else{
			response.demand = [];
			response.status = false;
			res.status(400).send(JSON.stringify(response));
		}
		
	})
})

app.get('/gamesScore/:league', (req, res) => {
	var response = {};
	var dateobj = new Date();
    var yy  =  dateobj.getFullYear(); 
    var mm  = (dateobj.getMonth()+1) ; 
    var dd  = dateobj.getDate();
	if(dd <	10){
			dd	=	"01";
	}
	if(mm < 10){
		mm	=	"0"+mm;
	}
	today =  yy+'-'+mm+'-'+dd ;	
	Score.find({league : req.params.league,created: {$lte: new Date(yy,mm,dd,0,0,0).toISOString() }}).select({"_id": 1,"game_id":1,"home_name": 1,"home_color": 1,"home_points":1,"away_name":1,"away_points":1,"away_color": 1,"status":1,"created":1,"away_logo":1,"home_logo":1,"venue_id":1,"venue_logo":1}).sort({created:1}).exec( function (err, gameScores) {
	 
			objScores	=	[];
			if (gameScores) { 				
				if(gameScores.length>0){
					j=0;
					gameScores.forEach(function(gscore) {
						scoreData	=	{};
						scoreData['game_id']	=	gscore.game_id;
						scoreData['home_name']	=	gscore.home_name; 
						if(typeof gscore.home_points !="undefined"){
						   scoreData['home_points']  =  gscore.home_points;
						}else{
						   scoreData['home_points']  =  0;
						}
						
						scoreData['away_name']  =  gscore.away_name;
						if(typeof gscore.away_points !="undefined"){
							scoreData['away_points']  =  gscore.away_points;
						}else{
						   scoreData['away_points']  =  0;
						}
						if(typeof gscore.home_logo !="undefined"){
							scoreData['home_logo']  =  app.get('siteUrl')+gscore.home_logo;
						}else{
						   scoreData['home_logo']  =  "";
						}
						if(typeof gscore.away_logo !="undefined"){
							scoreData['away_logo']  =  app.get('siteUrl')+gscore.away_logo;
						}else{
						   scoreData['away_logo']  =  "";
						}
						if(typeof gscore.home_color != "undefined"){
							scoreData['home_color']  =  gscore.home_color;
						}else{
						   scoreData['home_color']  =  "";
						}
						if(typeof gscore.away_color !="undefined"){
							scoreData['away_color']  =  gscore.away_color;
						}else{
						   scoreData['away_color']  =  "";
						}
						if(typeof gscore.venue_logo !="undefined"){
							scoreData['venue_logo']  =  gscore.venue_logo;
						}else{
						   scoreData['venue_logo']  =  "";
						}
						scoreData['status']	=	gscore.status;
						scoreData['created']	=	moment(gscore.created).format("YYYY-MM-DD HH:mm");
						objScores.push(scoreData);
						j++;
					})
				} 
				response.scores = objScores;
			
				response.status = true;
				res.status(200).send(JSON.stringify(response));
		   }else{
			   response.scores = [];
			
				response.status = false;
				res.status(400).send(JSON.stringify(response));
		   }		
			
		});  
})

app.get('/gamenews/:league', (req, res) => {
	var response = {};
	News.find({}).select({"_id": 1,"title": 1,"content":1,"image_file_url":1}).exec(function (err, newsData) {
		
		if (newsData) { 
			response.gamenews = newsData;
		} else {
			response.gamenews = "No Data!";
		}
		
		
	});    
});

app.get('/fandemand/:league', (req, res) => {
	var response = {};
	if(req.params.league=="NHL"){
		DemandNew.find({ type : req.params.league }).sort({"dateutc":1}).exec( function (err, events) {
			if (events) { 
				objEvent	=	[];
				if(events.length>0){
					i=0;
					events.forEach(function(demand) {
						eventData	=	{};
							if((demand.title).indexOf(' at ')!=-1){
								var teamStr = (demand.title).split(" at ");
								
								
								awayTeam	=	teamStr[1];
								if(req.params.league =="NHL" || req.params.league =="MLB"){
									hometeam =	(teamStr[0]).replace("Spring Training: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam)+'.png';
								}else if(req.params.league =="NFL" || req.params.league =="NBA"){
									hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam)+'.png';
								}
								
							}else if((demand.title).indexOf(' vs. ')!=-1){
								var teamStr = (demand.title).split(" vs. ");
								hometeam =	(teamStr[0]).replace("Spring Training: ","");
								awayTeam	=	teamStr[1];
								if(req.params.league =="NHL" || req.params.league =="MLB"){
									hometeam =	(teamStr[0]).replace("Spring Training: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam)+'.png';
								}else if(req.params.league =="NFL" || req.params.league =="NBA"){
									hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam)+'.png';
								}
							}else{
								eventData['home_team']	=	"";
								eventData['away_team']	=	"";
								eventData['home_team_logo']  = "";
								eventData['away_team_logo']  = "";
							}
							eventData['title']	=	demand.title;
							eventData['seatmap']	=	demand.seatmap;
							eventData['venue']	=	demand.venue;
							eventData['dateutc']	=	moment(demand.dateutc).format("YYYY-MM-DD HH:mm");
							eventData['description']	=	"";
							eventData['venue_image']	=	demand.venue_image;
							changeDemand=0;
							eventData['demand']	= demand.average_price - demand.max_price;
							changeDemand = 	 demand.average_price - demand.average_price_old;
							eventData['change_demand']	= Number(changeDemand);
							if(changeDemand < 0){
								eventData['status']	= 'negative'; 
							}else{
								eventData['status']	= 'positive';
							}
							 
							objEvent.push(eventData);
							i++;
					})
				}	
				response.fanDemand = dt.sortByKey(objEvent,'demand');
				response.status = true;
				res.status(200).send(JSON.stringify(response));
			} else {
				response.fanDemand = "No Data!";
				response.status = false;
				res.status(400).send(JSON.stringify(response));
			}
		});

	}else{
		Demand.find({ type : req.params.league }).sort({"dateutc":1}).exec( function (err, events) {
			if (events) { 
				objEvent	=	[];
				if(events.length>0){
					i=0;
					events.forEach(function(demand) {
						eventData	=	{};
							if((demand.title).indexOf(' at ')!=-1){
								var teamStr = (demand.title).split(" at ");
								
								
								awayTeam	=	teamStr[1];
								if(req.params.league =="NHL" || req.params.league =="MLB"){
									hometeam =	(teamStr[0]).replace("Spring Training: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam)+'.png';
								}else if(req.params.league =="NFL" || req.params.league =="NBA"){
									hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam)+'.png';
								}
								
							}else if((demand.title).indexOf(' vs. ')!=-1){
								var teamStr = (demand.title).split(" vs. ");
								hometeam =	(teamStr[0]).replace("Spring Training: ","");
								awayTeam	=	teamStr[1];
								if(req.params.league =="NHL" || req.params.league =="MLB"){
									hometeam =	(teamStr[0]).replace("Spring Training: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(awayTeam)+'.png';
								}else if(req.params.league =="NFL" || req.params.league =="NBA"){
									hometeam =	(teamStr[0]).replace("Super Bowl LIII: ","");
									eventData['home_team']	=	hometeam;
									eventData['away_team']	=	awayTeam;
									eventData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(hometeam)+'.png';
									eventData['away_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(awayTeam)+'.png';
								}
							}else{
								eventData['home_team']	=	"";
								eventData['away_team']	=	"";
								eventData['home_team_logo']  = "";
								eventData['away_team_logo']  = "";
							}
							eventData['title']	=	demand.title;
								eventData['seatmap']	=	demand.seatmap;
							eventData['venue']	=	demand.venue;
							eventData['dateutc']	=	moment(demand.dateutc).format("YYYY-MM-DD HH:mm");
							eventData['description']	=	"";
							eventData['venue_image']	=	demand.venue_image;
							changeDemand=0;
							eventData['demand']	= demand.average_price - ((demand.max_price + demand.min_price)/2);
							changeDemand = 	 eventData['demand'] - (demand.average_price_old - ((demand.max_price_old + demand.min_price_old)/2));
							eventData['change_demand']	= Number(changeDemand);
							if(changeDemand < 0){
								eventData['status']	= 'negative'; 
							}else{
								eventData['status']	= 'positive';
							}
							 
							objEvent.push(eventData);
							i++;
					})
				}	
				response.fanDemand = dt.sortByKey(objEvent,'demand');
				response.status = true;
				res.status(200).send(JSON.stringify(response));
			} else {
				response.fanDemand = "No Data!";
				response.status = false;
				res.status(400).send(JSON.stringify(response));
			}
		});
	}	
});

app.get('/news', (req, res) => {
    var response = {};
	var dateobj = new Date();
    var yy  =  dateobj.getFullYear(); 
    var mm  = (dateobj.getMonth()+1) ; 
    var dd  = dateobj.getDate();
	if(dd <	10){
			dd	=	"0"+dd;
	}
	if(mm < 10){
		mm	=	"0"+mm;
	}
    News.find({updated: {"$gte":yy+'-'+mm+'-'+dd+"T00:00:00Z", "$lt" : yy+'-'+mm+'-'+dd+"T23:59:59Z"}}, function (err, news) {
        if (news) { 
              response.message = "News Listing !";
              response.status = true;
              response.newsData = news;
                 
              res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
 
    
})

app.get('/games', (req, res) => {
    var response = {};
    Games.find({}, function (err, game) {
        if (game) { 
              response.message = "Games Listing !";
              response.status = true;
              response.gameData = game;
                 
              res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
  
})

app.get('/game_score/:id', (req, res) => {
    var response = {};
   Score.findOne({game_id:req.params.id}, function (err, scores) {
        if (scores) { 
              response.message = "Score data !";
              response.status = true;
              response.scoreData = scores;
                 
              res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
 
    
});

/* for NFL */
app.get('/score_drives/:id', (req, res) => {
    var response = {};
    var offset=0;
    if(typeof req.query.driverIndex != "undefined" && req.query.driverIndex > 0){
       offset=parseInt(req.query.driverIndex);
    }
    ScoreDrives.aggregate([ {$match:{ game_id:req.params.id }},{ $project: {arr_size: {$size: "$drives"}} }]).then((totalDriver) =>{
      ScoreDrives.findOne({game_id:req.params.id}, { drives: { $slice: [offset,2] } }, function (err, scoreDrive) {
          if (scoreDrive) { 
            response.message = "Score data !";
            response.status = true;
            response.scheduledateutc  = moment(scoreDrive.schedule).format("YYYY-MM-DD HH:mm");
            response.scoreData = scoreDrive;
            response.totalDriver = totalDriver;
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
     })
      
  })
});

app.get('/score_drives_nba/:id',  function(req, res){
    var response = {};
    Score.findOne({game_id:req.params.id}).select({"_id": 1,"game_id":1,"away_logo":1,"home_logo":1}).then((gameScores) => { 
		SportsRadarDrive.findOne({ game_id:req.params.id }).exec(function (err, sportsData) {
        if (sportsData) { 
          gameListData  =  {};
          response.message = "Score data !";
        
          gameListData.home_team_point = sportsData.gameData.home.points;
          gameListData.home_team_name = sportsData.gameData.home.name;
          gameListData.home_team_market = sportsData.gameData.home.market;
          gameListData.home_team_alias = sportsData.gameData.home.alias;
          gameListData.away_team_point = sportsData.gameData.away.points;
          gameListData.away_team_name = sportsData.gameData.away.name;
          gameListData.away_team_market = sportsData.gameData.away.market;
          gameListData.away_team_alias = sportsData.gameData.away.alias;
		  if(typeof gameScores.home_logo !="undefined"){
				gameListData.home_logo  =  gameScores.home_logo;
			}else{
			   gameListData.home_logo  =  "";
			}
			if(typeof gameScores.away_logo !="undefined"){
				  gameListData.away_logo = gameScores.away_logo;
			}else{
			   gameListData.away_logo  =  "";
			}
          gameListData.status = sportsData.status;
          gameListData.scheduledateutc = moment(sportsData.gameData.scheduled).format("YYYY-MM-DD HH:mm");
          gameListData.situtation_clock = sportsData.clock;
          gameListData._id = sportsData._id;
          gameListData.game_id = sportsData.game_id;
          gameListData.scores =  [];
          gameListData.home_leaders =  [];
          gameListData.away_leaders =  [];
          var i=0;
		  if(typeof sportsData.gameData.home.scoring !="undefined"){
			(sportsData.gameData.home.scoring).forEach(function(hscdata) {
				scoreData  =  {};
				scoreData.home_points  =  hscdata.points;
				scoreData.away_points  =  sportsData.gameData.away.scoring[i].points;
				(gameListData.scores).push(scoreData);
				i++;
			  })  
		  }
          
          home={};
          away={};
          home.points  = {};  
          away.points  = {};  
          home.rebounds  = {};  
          away.rebounds  = {};  
          home.assists  = {};  
          away.assists  = {};  
          leader_home_points    =  {};
          leader_away_points    =  {};
          leader_home_rebounds  =  {};
          leader_away_rebounds  =  {};
          leader_home_assists  =  {};
          leader_away_assists  =  {};
           /* start home */
          /* start home points*/
		  if(typeof sportsData.gameData.home.leaders !="undefined"){
			  leader_home_points.fullname  =  sportsData.gameData.home.leaders.points[0].full_name +" ("+ sportsData.gameData.home.leaders.points[0].position +")";
			  leader_home_points.min  =  sportsData.gameData.home.leaders.points[0].statistics.minutes;
			  leader_home_points.fgm_a  =  sportsData.gameData.home.leaders.points[0].statistics.field_goals_made+ "-"+sportsData.gameData.home.leaders.points[0].statistics.field_goals_att;
			  leader_home_points.pm3_a  =  sportsData.gameData.home.leaders.points[0].statistics.three_points_made+ "-"+sportsData.gameData.home.leaders.points[0].statistics.three_points_att;
			  leader_home_points.ftm_a  =  sportsData.gameData.home.leaders.points[0].statistics.free_throws_made+ "-"+sportsData.gameData.home.leaders.points[0].statistics.free_throws_att;
			  leader_home_points.oreb  =  sportsData.gameData.home.leaders.points[0].statistics.offensive_rebounds;
			  leader_home_points.dreb  =  sportsData.gameData.home.leaders.points[0].statistics.defensive_rebounds;
			  leader_home_points.reb  =  sportsData.gameData.home.leaders.points[0].statistics.rebounds;
			  leader_home_points.ast  =  sportsData.gameData.home.leaders.points[0].statistics.assists;
			  leader_home_points.stl  =  sportsData.gameData.home.leaders.points[0].statistics.steals;
			  leader_home_points.blk  =  sportsData.gameData.home.leaders.points[0].statistics.blocks;
			  leader_home_points.to  =  sportsData.gameData.home.leaders.points[0].statistics.turnovers;
			  leader_home_points.pf  =  sportsData.gameData.home.leaders.points[0].statistics.personal_fouls;
			  leader_home_points.pls_min  =  sportsData.gameData.home.leaders.points[0].statistics.pls_min;
			  leader_home_points.points  =  sportsData.gameData.home.leaders.points[0].statistics.points;
			home.points  = leader_home_points;
		
          //(gameListData.home_leaders).push(home);

          /* end home points*/
          /* start home rebounds */
          leader_home_rebounds.fullname  =  sportsData.gameData.home.leaders.rebounds[0].full_name +" ("+ sportsData.gameData.home.leaders.rebounds[0].position +")";
          leader_home_rebounds.min  =  sportsData.gameData.home.leaders.rebounds[0].statistics.minutes;
          leader_home_rebounds.fgm_a  =  sportsData.gameData.home.leaders.rebounds[0].statistics.field_goals_made+ "-"+sportsData.gameData.home.leaders.rebounds[0].statistics.field_goals_att;
          leader_home_rebounds.pm3_a  =  sportsData.gameData.home.leaders.rebounds[0].statistics.three_points_made+ "-"+sportsData.gameData.home.leaders.rebounds[0].statistics.three_points_att;
          leader_home_rebounds.ftm_a  =  sportsData.gameData.home.leaders.rebounds[0].statistics.free_throws_made+ "-"+sportsData.gameData.home.leaders.rebounds[0].statistics.free_throws_att;
          leader_home_rebounds.oreb  =  sportsData.gameData.home.leaders.rebounds[0].statistics.offensive_rebounds;
          leader_home_rebounds.dreb  =  sportsData.gameData.home.leaders.rebounds[0].statistics.defensive_rebounds;
          leader_home_rebounds.reb  =  sportsData.gameData.home.leaders.rebounds[0].statistics.rebounds;
          leader_home_rebounds.ast  =  sportsData.gameData.home.leaders.rebounds[0].statistics.assists;
          leader_home_rebounds.stl  =  sportsData.gameData.home.leaders.rebounds[0].statistics.steals;
          leader_home_rebounds.blk  =  sportsData.gameData.home.leaders.rebounds[0].statistics.blocks;
          leader_home_rebounds.to  =  sportsData.gameData.home.leaders.rebounds[0].statistics.turnovers;
          leader_home_rebounds.pf  =  sportsData.gameData.home.leaders.rebounds[0].statistics.personal_fouls;
          leader_home_rebounds.pls_min  =  sportsData.gameData.home.leaders.rebounds[0].statistics.pls_min;
          leader_home_rebounds.points  =  sportsData.gameData.home.leaders.rebounds[0].statistics.points;
          home.rebounds  =  leader_home_rebounds;
         // (gameListData.home_leaders).push(home);
          /* end home rebounds*/
            /* start home assists */
          leader_home_assists.fullname  =  sportsData.gameData.home.leaders.assists[0].full_name +" ("+ sportsData.gameData.home.leaders.assists[0].position +")";
          leader_home_assists.min  =  sportsData.gameData.home.leaders.assists[0].statistics.minutes;
          leader_home_assists.fgm_a  =  sportsData.gameData.home.leaders.assists[0].statistics.field_goals_made+ "-"+sportsData.gameData.home.leaders.assists[0].statistics.field_goals_att;
          leader_home_assists.pm3_a  =  sportsData.gameData.home.leaders.assists[0].statistics.three_points_made+ "-"+sportsData.gameData.home.leaders.assists[0].statistics.three_points_att;
          leader_home_assists.ftm_a  =  sportsData.gameData.home.leaders.assists[0].statistics.free_throws_made+ "-"+sportsData.gameData.home.leaders.assists[0].statistics.free_throws_att;
          leader_home_assists.oreb  =  sportsData.gameData.home.leaders.assists[0].statistics.offensive_rebounds;
          leader_home_assists.dreb  =  sportsData.gameData.home.leaders.assists[0].statistics.defensive_rebounds;
          leader_home_assists.reb  =  sportsData.gameData.home.leaders.assists[0].statistics.rebounds;
          leader_home_assists.ast  =  sportsData.gameData.home.leaders.assists[0].statistics.assists;
          leader_home_assists.stl  =  sportsData.gameData.home.leaders.assists[0].statistics.steals;
          leader_home_assists.blk  =  sportsData.gameData.home.leaders.assists[0].statistics.blocks;
          leader_home_assists.to  =  sportsData.gameData.home.leaders.assists[0].statistics.turnovers;
          leader_home_assists.pf  =  sportsData.gameData.home.leaders.assists[0].statistics.personal_fouls;
          leader_home_assists.pls_min  =  sportsData.gameData.home.leaders.assists[0].statistics.pls_min;
          leader_home_assists.points  =  sportsData.gameData.home.leaders.assists[0].statistics.points;
          home.assists  =  leader_home_assists;
		}  
          (gameListData.home_leaders).push(home);
          /* end home assists*/
	
         //  (gameListData.home_leaders).push(home);
          /* end home */
          /* start away */
          /* start away points*/
		  if(typeof sportsData.gameData.away.leaders !="undefined"){
          leader_away_points.fullname  =  sportsData.gameData.away.leaders.points[0].full_name +" ("+ sportsData.gameData.away.leaders.points[0].position +")";
          leader_away_points.min  =  sportsData.gameData.away.leaders.points[0].statistics.minutes;
          leader_away_points.fgm_a  =  sportsData.gameData.away.leaders.points[0].statistics.field_goals_made+ "-"+sportsData.gameData.away.leaders.points[0].statistics.field_goals_att;
          leader_away_points.pm3_a  =  sportsData.gameData.away.leaders.points[0].statistics.three_points_made+ "-"+sportsData.gameData.away.leaders.points[0].statistics.three_points_att;
          leader_away_points.ftm_a  =  sportsData.gameData.away.leaders.points[0].statistics.free_throws_made+ "-"+sportsData.gameData.away.leaders.points[0].statistics.free_throws_att;
          leader_away_points.oreb  =  sportsData.gameData.away.leaders.points[0].statistics.offensive_rebounds;
          leader_away_points.dreb  =  sportsData.gameData.away.leaders.points[0].statistics.defensive_rebounds;
          leader_away_points.reb  =  sportsData.gameData.away.leaders.points[0].statistics.rebounds;
          leader_away_points.ast  =  sportsData.gameData.away.leaders.points[0].statistics.assists;
          leader_away_points.stl  =  sportsData.gameData.away.leaders.points[0].statistics.steals;
          leader_away_points.blk  =  sportsData.gameData.away.leaders.points[0].statistics.blocks;
          leader_away_points.to  =  sportsData.gameData.away.leaders.points[0].statistics.turnovers;
          leader_away_points.pf  =  sportsData.gameData.away.leaders.points[0].statistics.personal_fouls;
          leader_away_points.pls_min  =  sportsData.gameData.away.leaders.points[0].statistics.pls_min;
          leader_away_points.points  =  sportsData.gameData.away.leaders.points[0].statistics.points;
          away.points  = leader_away_points;

          /* end away points*/
          /* start away rebounds */
          leader_away_rebounds.fullname  =  sportsData.gameData.away.leaders.rebounds[0].full_name +" ("+ sportsData.gameData.away.leaders.rebounds[0].position +")";
          leader_away_rebounds.min  =  sportsData.gameData.away.leaders.rebounds[0].statistics.minutes;
          leader_away_rebounds.fgm_a  =  sportsData.gameData.away.leaders.rebounds[0].statistics.field_goals_made+ "-"+sportsData.gameData.away.leaders.rebounds[0].statistics.field_goals_att;
          leader_away_rebounds.pm3_a  =  sportsData.gameData.away.leaders.rebounds[0].statistics.three_points_made+ "-"+sportsData.gameData.away.leaders.rebounds[0].statistics.three_points_att;
          leader_away_rebounds.ftm_a  =  sportsData.gameData.away.leaders.rebounds[0].statistics.free_throws_made+ "-"+sportsData.gameData.away.leaders.rebounds[0].statistics.free_throws_att;
          leader_away_rebounds.oreb  =  sportsData.gameData.away.leaders.rebounds[0].statistics.offensive_rebounds;
          leader_away_rebounds.dreb  =  sportsData.gameData.away.leaders.rebounds[0].statistics.defensive_rebounds;
          leader_away_rebounds.reb  =  sportsData.gameData.away.leaders.rebounds[0].statistics.rebounds;
          leader_away_rebounds.ast  =  sportsData.gameData.away.leaders.rebounds[0].statistics.assists;
          leader_away_rebounds.stl  =  sportsData.gameData.away.leaders.rebounds[0].statistics.steals;
          leader_away_rebounds.blk  =  sportsData.gameData.away.leaders.rebounds[0].statistics.blocks;
          leader_away_rebounds.to  =  sportsData.gameData.away.leaders.rebounds[0].statistics.turnovers;
          leader_away_rebounds.pf  =  sportsData.gameData.away.leaders.rebounds[0].statistics.personal_fouls;
          leader_away_rebounds.pls_min  =  sportsData.gameData.away.leaders.rebounds[0].statistics.pls_min;
          leader_away_rebounds.points  =  sportsData.gameData.away.leaders.rebounds[0].statistics.points;
          away.rebounds  = leader_away_rebounds;
          /* end away rebounds*/
            /* start away assists */
          leader_away_assists.fullname  =  sportsData.gameData.away.leaders.assists[0].full_name +" ("+ sportsData.gameData.away.leaders.assists[0].position +")";
          leader_away_assists.min  =  sportsData.gameData.away.leaders.assists[0].statistics.minutes;
          leader_away_assists.fgm_a  =  sportsData.gameData.away.leaders.assists[0].statistics.field_goals_made+ "-"+sportsData.gameData.away.leaders.assists[0].statistics.field_goals_att;
          leader_away_assists.pm3_a  =  sportsData.gameData.away.leaders.assists[0].statistics.three_points_made+ "-"+sportsData.gameData.away.leaders.assists[0].statistics.three_points_att;
          leader_away_assists.ftm_a  =  sportsData.gameData.away.leaders.assists[0].statistics.free_throws_made+ "-"+sportsData.gameData.away.leaders.assists[0].statistics.free_throws_att;
          leader_away_assists.oreb  =  sportsData.gameData.away.leaders.assists[0].statistics.offensive_rebounds;
          leader_away_assists.dreb  =  sportsData.gameData.away.leaders.assists[0].statistics.defensive_rebounds;
          leader_away_assists.reb  =  sportsData.gameData.away.leaders.assists[0].statistics.rebounds;
          leader_away_assists.ast  =  sportsData.gameData.away.leaders.assists[0].statistics.assists;
          leader_away_assists.stl  =  sportsData.gameData.away.leaders.assists[0].statistics.steals;
          leader_away_assists.blk  =  sportsData.gameData.away.leaders.assists[0].statistics.blocks;
          leader_away_assists.to  =  sportsData.gameData.away.leaders.assists[0].statistics.turnovers;
          leader_away_assists.pf  =  sportsData.gameData.away.leaders.assists[0].statistics.personal_fouls;
          leader_away_assists.pls_min  =  sportsData.gameData.away.leaders.assists[0].statistics.pls_min;
          leader_away_assists.points  =  sportsData.gameData.away.leaders.assists[0].statistics.points;
		  }
          away.assists  = leader_away_assists;
          /* end away assists*/
		   (gameListData.away_leaders).push(away);

		//  console.log(Object.keys(myObject).length(gameListData.home_leaders[0].points));
		  if(Object.keys( gameListData.home_leaders[0].points ).length==0 || Object.keys( gameListData.home_leaders[0].rebounds ).length==0 || Object.keys( gameListData.home_leaders[0].assists ).length==0){
			    response.status = false;
				response.gameInfo = gameListData;
				res.status(200).send(JSON.stringify(response));
		  }else{
			    response.status = true;
			  response.gameInfo = gameListData;
				res.status(200).send(JSON.stringify(response));
		  }
        
          
        } else {
          response.message = "No Data!";
          response.status = false;
          res.status(400).send(JSON.stringify(response));
        }    
    }) 
    }) 
});

app.get('/score_drives_nhl/:id',  function(req, res){
    var response = {};
    Score.findOne({game_id:req.params.id}).select({"_id": 1,"game_id":1,"away_logo":1,"home_logo":1}).then((gameScores) => { 
		SportsRadarDrive.findOne({ game_id:req.params.id }).exec(function (err, sportsData) {
        if (sportsData) { 
          gameListData  =  {};
          response.message = "Score data !";
          response.status = true;
          gameListData.home_team_point = sportsData.gameData.home.points;
          gameListData.home_team_name = sportsData.gameData.home.name;
          gameListData.home_team_market = sportsData.gameData.home.market;
          gameListData.home_team_alias = sportsData.gameData.home.alias;
          gameListData.away_team_point = sportsData.gameData.away.points;
          gameListData.away_team_name = sportsData.gameData.away.name;
          gameListData.away_team_market = sportsData.gameData.away.market;
          gameListData.away_team_alias = sportsData.gameData.away.alias;
		  if(typeof gameScores.home_logo !="undefined"){
				gameListData.home_logo  =  gameScores.home_logo;
			}else{
			   gameListData.home_logo  =  "";
			}
			if(typeof gameScores.away_logo !="undefined"){
				  gameListData.away_logo = gameScores.away_logo;
			}else{
			   gameListData.away_logo  =  "";
			}
          gameListData.status = sportsData.status;
          gameListData.scheduledateutc = moment(sportsData.gameData.scheduled).format("YYYY-MM-DD HH:mm");
          gameListData.situtation_clock = sportsData.clock;
          gameListData._id = sportsData._id;
          gameListData.game_id = sportsData.game_id;
          gameListData.scores =  [];
          gameListData.home_leaders =  [];
          gameListData.away_leaders =  [];
          var i=0;
		  
		  if(typeof sportsData.gameData.home.scoring !="undefined"){
			(sportsData.gameData.home.scoring).forEach(function(hscdata) {
				scoreData  =  {};
				scoreData.home_points  =  hscdata.points;
				scoreData.away_points  =  sportsData.gameData.away.scoring[i].points;
				(gameListData.scores).push(scoreData);
				i++;
			  })  
		  }
          
          home={};
          away={};
          home.points  = {};  
          away.points  = {};  
          home.goals  = {};  
          away.goals  = {};  
          home.assists  = {};  
          away.assists  = {};  
          leader_home_points    =  {};
          leader_away_points    =  {};
          leader_home_rebounds  =  {};
          leader_away_rebounds  =  {};
          leader_home_assists  =  {};
          leader_away_assists  =  {};
           /* start home */
          /* start home points*/
		  if(typeof sportsData.gameData.home.leaders !="undefined"){
			  leader_home_points.fullname  =  sportsData.gameData.home.leaders.points[0].full_name +" ("+ sportsData.gameData.home.leaders.points[0].position +")";
			  leader_home_points.goals  =  sportsData.gameData.home.leaders.points[0].statistics.total.goals;
			  leader_home_points.assists  =  sportsData.gameData.home.leaders.points[0].statistics.total.assists;
			  leader_home_points.pts  =  sportsData.gameData.home.leaders.points[0].statistics.total.points;
			  leader_home_points.sog  =  sportsData.gameData.home.leaders.points[0].statistics.total.shots;
			  leader_home_points.ms  =  sportsData.gameData.home.leaders.points[0].statistics.total.missed_shots;
			  leader_home_points.bs  =  sportsData.gameData.home.leaders.points[0].statistics.total.blocked_shots;
			  leader_home_points.pn  =  sportsData.gameData.home.leaders.points[0].statistics.total.penalties;
			  leader_home_points.pim  =  sportsData.gameData.home.leaders.points[0].statistics.total.penalty_minutes;
			  leader_home_points.ht  =  sportsData.gameData.home.leaders.points[0].statistics.total.hits;
			  leader_home_points.tk  =  sportsData.gameData.home.leaders.points[0].statistics.total.takeaways;
			  leader_home_points.gv  =  sportsData.gameData.home.leaders.points[0].statistics.total.giveaways;
			  var tot_shf=0;
			  if(typeof sportsData.gameData.home.leaders.points[0].statistics.periods !="undefined"){
				  (sportsData.gameData.home.leaders.points[0].statistics.periods).forEach(function(periods) {
					  
					  tot_shf += periods.total.number_of_shifts;
				  })
			  }
			  leader_home_points.shf  =  tot_shf;
			  leader_home_points.tot  =  sportsData.gameData.home.leaders.points[0].time_on_ice.total;
			  leader_home_points.pp  =  sportsData.gameData.home.leaders.points[0].time_on_ice.powerplay;
			  leader_home_points.sh  =  sportsData.gameData.home.leaders.points[0].time_on_ice.shorthanded;
			  leader_home_points.ev  =  sportsData.gameData.home.leaders.points[0].time_on_ice.evenstrength;
			  leader_home_points.fw  =  sportsData.gameData.home.leaders.points[0].statistics.total.faceoffs_won;
			  leader_home_points.fl  =  sportsData.gameData.home.leaders.points[0].statistics.total.faceoffs_lost;
			  leader_home_points.percent  =  sportsData.gameData.home.leaders.points[0].statistics.total.faceoff_win_pct;
				home.points  = leader_home_points;
		
          //(gameListData.home_leaders).push(home);

          /* end home points*/
          /* start home goals */
          leader_home_rebounds.fullname  =  sportsData.gameData.home.leaders.goals[0].full_name +" ("+ sportsData.gameData.home.leaders.goals[0].position +")";
          leader_home_rebounds.goals  =  sportsData.gameData.home.leaders.goals[0].statistics.total.goals;
		  leader_home_rebounds.assists  =  sportsData.gameData.home.leaders.goals[0].statistics.total.assists;
		  leader_home_rebounds.pts  =  sportsData.gameData.home.leaders.goals[0].statistics.total.points;
		  leader_home_rebounds.sog  =  sportsData.gameData.home.leaders.goals[0].statistics.total.shots;
		  leader_home_rebounds.ms  =  sportsData.gameData.home.leaders.goals[0].statistics.total.missed_shots;
		  leader_home_rebounds.bs  =  sportsData.gameData.home.leaders.goals[0].statistics.total.blocked_shots;
		  leader_home_rebounds.pn  =  sportsData.gameData.home.leaders.goals[0].statistics.total.penalties;
		  leader_home_rebounds.pim  =  sportsData.gameData.home.leaders.goals[0].statistics.total.penalty_minutes;
		  leader_home_rebounds.ht  =  sportsData.gameData.home.leaders.goals[0].statistics.total.hits;
		  leader_home_rebounds.tk  =  sportsData.gameData.home.leaders.goals[0].statistics.total.takeaways;
		  leader_home_rebounds.gv  =  sportsData.gameData.home.leaders.goals[0].statistics.total.giveaways;
		  var tot_shf=0;
		  if(typeof sportsData.gameData.home.leaders.goals[0].statistics.periods !="undefined"){
			  (sportsData.gameData.home.leaders.goals[0].statistics.periods).forEach(function(periods) {
				  
				  tot_shf += periods.total.number_of_shifts;
			  })
		  }
		  leader_home_rebounds.shf  =  tot_shf;
		  leader_home_rebounds.tot  =  sportsData.gameData.home.leaders.goals[0].time_on_ice.total;
		  leader_home_rebounds.pp  =  sportsData.gameData.home.leaders.goals[0].time_on_ice.powerplay;
		  leader_home_rebounds.sh  =  sportsData.gameData.home.leaders.goals[0].time_on_ice.shorthanded;
		  leader_home_rebounds.ev  =  sportsData.gameData.home.leaders.goals[0].time_on_ice.evenstrength;
		  leader_home_rebounds.fw  =  sportsData.gameData.home.leaders.goals[0].statistics.total.faceoffs_won;
		  leader_home_rebounds.fl  =  sportsData.gameData.home.leaders.goals[0].statistics.total.faceoffs_lost;
		  leader_home_rebounds.percent  =  sportsData.gameData.home.leaders.goals[0].statistics.total.faceoff_win_pct;
          home.goals  =  leader_home_rebounds;
         // (gameListData.home_leaders).push(home);
          /* end home rebounds*/
            /* start home assists */
          leader_home_assists.fullname  =  sportsData.gameData.home.leaders.assists[0].full_name +" ("+ sportsData.gameData.home.leaders.assists[0].position +")";
          leader_home_assists.goals  =  sportsData.gameData.home.leaders.assists[0].statistics.total.goals;
		  leader_home_assists.assists  =  sportsData.gameData.home.leaders.assists[0].statistics.total.assists;
		  leader_home_assists.pts  =  sportsData.gameData.home.leaders.assists[0].statistics.total.points;
		  leader_home_assists.sog  =  sportsData.gameData.home.leaders.assists[0].statistics.total.shots;
		  leader_home_assists.ms  =  sportsData.gameData.home.leaders.assists[0].statistics.total.missed_shots;
		  leader_home_assists.bs  =  sportsData.gameData.home.leaders.assists[0].statistics.total.blocked_shots;
		  leader_home_assists.pn  =  sportsData.gameData.home.leaders.assists[0].statistics.total.penalties;
		  leader_home_assists.pim  =  sportsData.gameData.home.leaders.assists[0].statistics.total.penalty_minutes;
		  leader_home_assists.ht  =  sportsData.gameData.home.leaders.assists[0].statistics.total.hits;
		  leader_home_assists.tk  =  sportsData.gameData.home.leaders.assists[0].statistics.total.takeaways;
		  leader_home_assists.gv  =  sportsData.gameData.home.leaders.assists[0].statistics.total.giveaways;
		  var tot_shf=0;
		  if(typeof sportsData.gameData.home.leaders.assists[0].statistics.periods !="undefined"){
			  (sportsData.gameData.home.leaders.assists[0].statistics.periods).forEach(function(periods) {
				  
				  tot_shf += periods.total.number_of_shifts;
			  })
		  }
		  leader_home_assists.shf  =  tot_shf;
		  leader_home_assists.tot  =  sportsData.gameData.home.leaders.assists[0].time_on_ice.total;
		  leader_home_assists.pp  =  sportsData.gameData.home.leaders.assists[0].time_on_ice.powerplay;
		  leader_home_assists.sh  =  sportsData.gameData.home.leaders.assists[0].time_on_ice.shorthanded;
		  leader_home_assists.ev  =  sportsData.gameData.home.leaders.assists[0].time_on_ice.evenstrength;
		  leader_home_assists.fw  =  sportsData.gameData.home.leaders.assists[0].statistics.total.faceoffs_won;
		  leader_home_assists.fl  =  sportsData.gameData.home.leaders.assists[0].statistics.total.faceoffs_lost;
		  leader_home_assists.percent  =  sportsData.gameData.home.leaders.assists[0].statistics.total.faceoff_win_pct;
          home.assists  =  leader_home_assists;
		}  
          (gameListData.home_leaders).push(home);
          /* end home assists*/
	
         //  (gameListData.home_leaders).push(home);
          /* end home */
          /* start away */
          /* start away points*/
		  if(typeof sportsData.gameData.away.leaders !="undefined"){
          leader_away_points.fullname  =  sportsData.gameData.away.leaders.points[0].full_name +" ("+ sportsData.gameData.away.leaders.points[0].position +")";
          leader_away_points.goals  =  sportsData.gameData.away.leaders.points[0].statistics.total.goals;
		  leader_away_points.assists  =  sportsData.gameData.away.leaders.points[0].statistics.total.assists;
		  leader_away_points.pts  =  sportsData.gameData.away.leaders.points[0].statistics.total.points;
		  leader_away_points.sog  =  sportsData.gameData.away.leaders.points[0].statistics.total.shots;
		  leader_away_points.ms  =  sportsData.gameData.away.leaders.points[0].statistics.total.missed_shots;
		  leader_away_points.bs  =  sportsData.gameData.away.leaders.points[0].statistics.total.blocked_shots;
		  leader_away_points.pn  =  sportsData.gameData.away.leaders.points[0].statistics.total.penalties;
		  leader_away_points.pim  =  sportsData.gameData.away.leaders.points[0].statistics.total.penalty_minutes;
		  leader_away_points.ht  =  sportsData.gameData.away.leaders.points[0].statistics.total.hits;
		  leader_away_points.tk  =  sportsData.gameData.away.leaders.points[0].statistics.total.takeaways;
		  leader_away_points.gv  =  sportsData.gameData.away.leaders.points[0].statistics.total.giveaways;
		  var tot_shf=0;
		  if(typeof sportsData.gameData.away.leaders.points[0].statistics.periods !="undefined"){
			  (sportsData.gameData.away.leaders.points[0].statistics.periods).forEach(function(periods) {
				  
				  tot_shf += periods.total.number_of_shifts;
			  })
		  }
		  leader_away_points.shf  =  tot_shf;
		  leader_away_points.tot  =  sportsData.gameData.away.leaders.points[0].time_on_ice.total;
		  leader_away_points.pp  =  sportsData.gameData.away.leaders.points[0].time_on_ice.powerplay;
		  leader_away_points.sh  =  sportsData.gameData.away.leaders.points[0].time_on_ice.shorthanded;
		  leader_away_points.ev  =  sportsData.gameData.away.leaders.points[0].time_on_ice.evenstrength;
		  leader_away_points.fw  =  sportsData.gameData.away.leaders.points[0].statistics.total.faceoffs_won;
		  leader_away_points.fl  =  sportsData.gameData.away.leaders.points[0].statistics.total.faceoffs_lost;
		  leader_away_points.percent  =  sportsData.gameData.away.leaders.points[0].statistics.total.faceoff_win_pct;
          away.points  = leader_away_points;

          /* end away points*/
          /* start away goals */
          leader_away_rebounds.fullname  =  sportsData.gameData.away.leaders.goals[0].full_name +" ("+ sportsData.gameData.away.leaders.goals[0].position +")";
          leader_away_rebounds.goals  =  sportsData.gameData.away.leaders.goals[0].statistics.total.goals;
		  leader_away_rebounds.assists  =  sportsData.gameData.away.leaders.goals[0].statistics.total.assists;
		  leader_away_rebounds.pts  =  sportsData.gameData.away.leaders.goals[0].statistics.total.points;
		  leader_away_rebounds.sog  =  sportsData.gameData.away.leaders.goals[0].statistics.total.shots;
		  leader_away_rebounds.ms  =  sportsData.gameData.away.leaders.goals[0].statistics.total.missed_shots;
		  leader_away_rebounds.bs  =  sportsData.gameData.away.leaders.goals[0].statistics.total.blocked_shots;
		  leader_away_rebounds.pn  =  sportsData.gameData.away.leaders.goals[0].statistics.total.penalties;
		  leader_away_rebounds.pim  =  sportsData.gameData.away.leaders.goals[0].statistics.total.penalty_minutes;
		  leader_away_rebounds.ht  =  sportsData.gameData.away.leaders.goals[0].statistics.total.hits;
		  leader_away_rebounds.tk  =  sportsData.gameData.away.leaders.goals[0].statistics.total.takeaways;
		  leader_away_rebounds.gv  =  sportsData.gameData.away.leaders.goals[0].statistics.total.giveaways;
		  var tot_shf=0;
		  if(typeof sportsData.gameData.away.leaders.goals[0].statistics.periods !="undefined"){
			  (sportsData.gameData.away.leaders.goals[0].statistics.periods).forEach(function(periods) {
				  
				  tot_shf += periods.total.number_of_shifts;
			  })
		  }
		  leader_away_rebounds.shf  =  tot_shf;
		  leader_away_rebounds.tot  =  sportsData.gameData.away.leaders.goals[0].time_on_ice.total;
		  leader_away_rebounds.pp  =  sportsData.gameData.away.leaders.goals[0].time_on_ice.powerplay;
		  leader_away_rebounds.sh  =  sportsData.gameData.away.leaders.goals[0].time_on_ice.shorthanded;
		  leader_away_rebounds.ev  =  sportsData.gameData.away.leaders.goals[0].time_on_ice.evenstrength;
		  leader_away_rebounds.fw  =  sportsData.gameData.away.leaders.goals[0].statistics.total.faceoffs_won;
		  leader_away_rebounds.fl  =  sportsData.gameData.away.leaders.goals[0].statistics.total.faceoffs_lost;
		  leader_away_rebounds.percent  =  sportsData.gameData.away.leaders.goals[0].statistics.total.faceoff_win_pct;
          away.goals  = leader_away_rebounds;
          /* end away rebounds*/
            /* start away assists */
          leader_away_assists.fullname  =  sportsData.gameData.away.leaders.assists[0].full_name +" ("+ sportsData.gameData.away.leaders.assists[0].position +")";
          leader_away_assists.goals  =  sportsData.gameData.away.leaders.assists[0].statistics.total.goals;
		  leader_away_assists.assists  =  sportsData.gameData.away.leaders.assists[0].statistics.total.assists;
		  leader_away_assists.pts  =  sportsData.gameData.away.leaders.assists[0].statistics.total.points;
		  leader_away_assists.sog  =  sportsData.gameData.away.leaders.assists[0].statistics.total.shots;
		  leader_away_assists.ms  =  sportsData.gameData.away.leaders.assists[0].statistics.total.missed_shots;
		  leader_away_assists.bs  =  sportsData.gameData.away.leaders.assists[0].statistics.total.blocked_shots;
		  leader_away_assists.pn  =  sportsData.gameData.away.leaders.assists[0].statistics.total.penalties;
		  leader_away_assists.pim  =  sportsData.gameData.away.leaders.assists[0].statistics.total.penalty_minutes;
		  leader_away_assists.ht  =  sportsData.gameData.away.leaders.assists[0].statistics.total.hits;
		  leader_away_assists.tk  =  sportsData.gameData.away.leaders.assists[0].statistics.total.takeaways;
		  leader_away_assists.gv  =  sportsData.gameData.away.leaders.assists[0].statistics.total.giveaways;
		  var tot_shf=0;
		  if(typeof sportsData.gameData.away.leaders.assists[0].statistics.periods !="undefined"){
			  (sportsData.gameData.away.leaders.assists[0].statistics.periods).forEach(function(periods) {
				  
				  tot_shf += periods.total.number_of_shifts;
			  })
		  }
		  leader_away_assists.shf  =  tot_shf;
		  leader_away_assists.tot  =  sportsData.gameData.away.leaders.assists[0].time_on_ice.total;
		  leader_away_assists.pp  =  sportsData.gameData.away.leaders.assists[0].time_on_ice.powerplay;
		  leader_away_assists.sh  =  sportsData.gameData.away.leaders.assists[0].time_on_ice.shorthanded;
		  leader_away_assists.ev  =  sportsData.gameData.away.leaders.assists[0].time_on_ice.evenstrength;
		  leader_away_assists.fw  =  sportsData.gameData.away.leaders.assists[0].statistics.total.faceoffs_won;
		  leader_away_assists.fl  =  sportsData.gameData.away.leaders.assists[0].statistics.total.faceoffs_lost;
		  leader_away_assists.percent  =  sportsData.gameData.away.leaders.assists[0].statistics.total.faceoff_win_pct;
		  }
          away.assists  = leader_away_assists;
          /* end away assists*/
		 
         (gameListData.away_leaders).push(away);
          if(Object.keys( gameListData.home_leaders[0].points ).length==0 || Object.keys( gameListData.home_leaders[0].goals ).length==0 || Object.keys( gameListData.home_leaders[0].assists ).length==0){
			    response.status = false;
				response.gameInfo = gameListData;
				res.status(200).send(JSON.stringify(response));
		  }else{ 
			    response.status = true;
			  response.gameInfo = gameListData;
				res.status(200).send(JSON.stringify(response));
		  }
        } else {
          response.message = "No Data!";
          response.status = false;
          res.status(400).send(JSON.stringify(response));
        }    
    }) 
    }) 
});

app.get('/score_drives_mlb/:id',  function(req, res){
    var response = {};
    Score.findOne({game_id:req.params.id}).select({"_id": 1,"game_id":1,"away_logo":1,"home_logo":1}).then((gameScores) => { 
		SportsRadarDrive.findOne({ game_id:req.params.id }).exec(function (err, sportsData) {
        if (sportsData) { 
         	gameListData  =  {};
          	response.message = "Score data !";
          	response.status = true;
          	gameListData.home_team_point = sportsData.gameData.home.runs;
          	gameListData.home_team_name = sportsData.gameData.home.name;
          	gameListData.home_team_market = sportsData.gameData.home.market;
          	gameListData.home_team_alias = sportsData.gameData.home.abbr;
          	gameListData.away_team_point = sportsData.gameData.away.runs;
          	gameListData.away_team_name = sportsData.gameData.away.name;
          	gameListData.away_team_market = sportsData.gameData.away.market;
          	gameListData.away_team_alias = sportsData.gameData.away.abbr;
		  	if(typeof gameScores.home_logo !="undefined"){
				gameListData.home_logo  =  gameScores.home_logo;
			}else{
			   gameListData.home_logo  =  "";
			}
			if(typeof gameScores.away_logo !="undefined"){
			  	gameListData.away_logo = gameScores.away_logo;
			}else{
			   gameListData.away_logo  =  "";
			}
			gameListData.status = sportsData.gameData.status;
          	gameListData.scheduledateutc = moment(sportsData.gameData.scheduled).utc().format("YYYY-MM-DD HH:mm");
          	gameListData.situtation_clock = sportsData.clock;
          	gameListData._id = sportsData._id;
         	gameListData.game_id = sportsData.game_id;
         	gameListData.scores = [];
         	gameListData.run_scored = [];
         	var i=0;
         	if(typeof sportsData.gameData.home.scoring !="undefined"){
				(sportsData.gameData.home.scoring).forEach(function(hscdata) {
					scoreData  =  {};
					if(hscdata.runs && sportsData.gameData.away.scoring[i].runs){
						scoreData.number  =  hscdata.number;
						scoreData.home_points  =  hscdata.runs;
						scoreData.away_points  =  sportsData.gameData.away.scoring[i].runs;
						scoreList	=	[];
						scoreList[i] =	scoreData;
						(gameListData.scores).push(scoreData);
						i++;
					}
				
			 	})  
		  	}
		  	runData  =  {};
			if(sportsData.gameData.home.runs && sportsData.gameData.away.runs){
				runData.number  =   	'R';
				runData.home_points  =   sportsData.gameData.home.runs;
				runData.away_points  =  sportsData.gameData.away.runs;
				(gameListData.scores).push(runData);
			}
			hitData  =  {};
			if(sportsData.gameData.home.hits && sportsData.gameData.away.hits){
				hitData.number  =   	'H';
				hitData.home_points  =   sportsData.gameData.home.hits;
				hitData.away_points  =  sportsData.gameData.away.hits;
				(gameListData.scores).push(hitData);
			}
			errorData  =  {};
			if(sportsData.gameData.home.errors && sportsData.gameData.away.errors){
				errorData.number  =   	'E';
				errorData.home_points  =   sportsData.gameData.home.errors;
				errorData.away_points  =  sportsData.gameData.away.errors;
				(gameListData.scores).push(errorData);
			}
			if(typeof sportsData.gameData.home.events !="undefined"){
				(sportsData.gameData.home.events).forEach(function(eventdata) {
					eventList  =  {};
					eventList.team_name  =  sportsData.gameData.home.market+' '+sportsData.gameData.home.name;
					eventList.inning  =  eventdata.inning;
					eventList.runners  =  "";
					if(eventdata.runners != null){
						eventdata.runners.forEach(function(runner) {
							eventList.runners  += runner.preferred_name +" "+runner.last_name +',';
						})
					}
					eventList.runners  =(eventList.runners).slice(0,-1);
					(gameListData.run_scored).push(eventList);
					i++;
			 	})  
		  	}
		  	if(typeof sportsData.gameData.away.events !="undefined"){
				(sportsData.gameData.away.events).forEach(function(eventdata) {
					eventList  =  {};
					eventList.team_name  =  sportsData.gameData.away.market+' '+sportsData.gameData.away.name;
					eventList.inning  =  eventdata.inning;
					eventList.runners  =  "";
					if(eventdata.runners != null){

						eventdata.runners.forEach(function(runner) {
							eventList.runners  += runner.preferred_name +" "+runner.last_name +',';
						})
					}
					eventList.runners  = (eventList.runners).slice(0,-1);
					(gameListData.run_scored).push(eventList);
					i++;
			 	})  
		  	}
		  	dt.sortByKeyasc(gameListData.run_scored,"inning");
         	response.gameInfo = gameListData;
          	res.status(200).send(JSON.stringify(response));
        } else {
          	response.message = "No Data!";
          	response.status = false;
          	res.status(400).send(JSON.stringify(response));
        }    
    }) 
    }) 
});

app.get('/score_demand/:created/:hometeam/:league',function(req,res){
		var response	=	{};
		if(req.params.league=="NHL"){
			DemandNew.findOne({ title:{ $regex:req.params.hometeam},datetime:  new Date(req.params.created)}, function (err, demands) {
				if(demands){
					body	=	{};
					body.venue_location	=	demands.venue_location;
					body.venue_image	=	demands.venue_image;
					body.seatmap	=	demands.seatmap;
					body.average_price_old	=	demands.average_price_old;
					body.average_price	=	demands.average_price;
					body.min_price	=	0;
					body.max_price	=	demands.max_price;
					body.max_price_old	=	0;
					body.min_price_old	=	0;
					body.demand	=	(demands.demand).toFixed(2);
					body.change_demand	=	(demands.average_price- demands.average_price_old).toFixed(2);
					if(body.change_demand>=0){
						body.status	=	"positive";
					}else{
						body.status	=	"negative";
					}
					
					body._id	=	demands._id;
					body.title	=	demands.title;
					body.type	=	demands.type;
					body.venue	=	demands.venue;
					body.dateutc	=	moment(demands.dateutc).format("YYYY-MM-DD HH:mm");
					body.datetime	=	moment(demands.datetime).format("YYYY-MM-DD HH:mm");
					response.demand = body;
					response.status = true;
					res.status(200).send(JSON.stringify(response));
				}else{
					response.demand = [];
					response.status = false;
					res.status(400).send(JSON.stringify(response));
				}
				
			});
		}else{
			Demand.findOne({ title:{ $regex:req.params.hometeam},datetime:  new Date(req.params.created)}, function (err, demands) {
				if(demands){
					body	=	{};
					body.venue_location	=	demands.venue_location;
					body.venue_image	=	demands.venue_image;
					body.seatmap	=	demands.seatmap;
					body.average_price_old	=	demands.average_price_old;
					body.average_price	=	demands.average_price;
					body.min_price	=	demands.min_price;
					body.max_price	=	demands.max_price;
					body.max_price_old	=	demands.max_price_old;
					body.min_price_old	=	demands.min_price_old;
					body.demand	=	(demands.demand).toFixed(2);
					body.change_demand	=	(demands.change_demand).toFixed(2);
					body.status	=	demands.status;
					body._id	=	demands._id;
					body.title	=	demands.title;
					body.type	=	demands.type;
					body.venue	=	demands.venue;
					body.dateutc	=	moment(demands.dateutc).format("YYYY-MM-DD HH:mm");
					body.datetime	=	moment(demands.datetime).format("YYYY-MM-DD HH:mm");
					response.demand = body;
					response.status = true;
					res.status(200).send(JSON.stringify(response));
				}else{
					response.demand = [];
					response.status = false;
					res.status(400).send(JSON.stringify(response));
				}
				
			});
		}
			
})


app.get('/update_nba_venue',(req,res) =>{
  request("http://api.sportradar.us/nba-images-t3/getty/venues/manifest.json?api_key=s9h4vb8krqv55aemuughuufb", { json: true }, (err, response, venueBody) => {
    if((venueBody.assetlist).length>0){
      i=0;
      (venueBody.assetlist).forEach(function(assest) {
          //req.body.venueData  =  venueBody.assetlist;
          req.body.league='NBA';
          req.body.asset_id=assest.id;
          req.body.title=assest.title;
          req.body.description=assest.description;
          req.body.venue_id=assest.venue_id;
          req.body.links=assest.links;
          req.body.ref=assest.refs;
          
          var venue = new Venue(req.body);
          venue.save(function(err, scores) {
            if(err){
              console.log(err);
              return false;
            }
            
          });

      })
    }      
      
        
  });
});

app.get('/update_nfl_venue',(req,res) =>{
  request("https://api.sportradar.us/nfl-images-t3/ap/venues/manifest.json?api_key=dvmbpwwn5z53sq3rs6d9u32h", { json: true }, (err, response, venueBody) => {
    if((venueBody.assetlist).length>0){
      i=0;
      (venueBody.assetlist).forEach(function(assest) {
          //req.body.venueData  =  venueBody.assetlist;
          req.body.league='NFL';
          req.body.asset_id=assest.id;
          req.body.title=assest.title;
          req.body.description=assest.description;
          req.body.venue_id=assest.venue_id;
          req.body.links=assest.links;
          req.body.ref=assest.refs;
          
          var venue = new Venue(req.body);
          venue.save(function(err, scores) {
            if(err){
              console.log(err);
              return false;
            }
            
          });

      })
    }      
      
        
  });
});

app.get('/get_standing_nba/:season',(req,res) =>{
    var response = {};
    Standing.findOne({season:req.params.season}, function (err, stands) {
		
        if (stands) { 
            response.message = "Standing Data Available !";
            response.status = true;
            response.conference = [];
            var index  = 0;
            (stands.standingData).reverse();
            (stands.standingData).forEach(function(confdata) {
              hometeam =  {};
              awayteam =  {};
              if(index==0){
                  hometeam.name = confdata.name;
                  hometeam.alias = confdata.alias;
                   hometeam.teams = [];
                   if(typeof confdata.divisions !='undefined'){
                      (confdata.divisions).forEach(function(confdividata) {
                          if(typeof confdividata.teams !='undefined'){
							 var serial_no	=	1; 
                            (confdividata.teams).forEach(function(confdiviteamdata) {
								diviteamData  =  {};
								diviteamData['rank']  =  serial_no;
								diviteamData['team_id']  =  confdiviteamdata.id;
                                diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
                                diviteamData['wins']  =  confdiviteamdata.wins;
                                diviteamData['loses']  =  confdiviteamdata.losses;
                                diviteamData['win_pct']  =  confdiviteamdata.win_pct;
                                diviteamData['pf']  =  confdiviteamdata.points_for;
                                diviteamData['pa']  =  confdiviteamdata.points_against;
                                diviteamData['diff']  =  confdiviteamdata.point_diff;
								if(confdiviteamdata.games_behind){
									diviteamData['game_behind_c_f']  =  confdiviteamdata.games_behind.conference +'-'+ confdiviteamdata.games_behind.division;
								}else{
									diviteamData['game_behind_c_f']  =  "";
								}
                                
                                diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
                                if(typeof confdiviteamdata.records !='undefined'){
                                  (confdiviteamdata.records).forEach(function(confdivirecdata) {
                                    if(confdivirecdata.record_type=='home'){
                                        diviteamData['home']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='road'){
                                        diviteamData['road']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='division'){
                                      diviteamData['division']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='conference'){
                                       diviteamData['conference']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='last_10'){
                                        diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='three_points'){
                                       diviteamData['three_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='ten_points'){
                                        diviteamData['ten_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='over_500'){
                                       diviteamData['over_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='below_500'){
                                      diviteamData['below_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='overtime'){
                                      diviteamData['overtime']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }
                                  })
                                }
								serial_no++;
                               (hometeam.teams).push(diviteamData);
                           })
                          }
                      })
                   }
                 
                  (response.conference).push(hometeam);
              }else{
                 awayteam.name = confdata.name;
                awayteam.alias = confdata.alias;
                  awayteam.teams = [];
                   if(typeof confdata.divisions !='undefined'){
                      (confdata.divisions).forEach(function(confdividata) {
                          if(typeof confdividata.teams !='undefined'){
                            (confdividata.teams).forEach(function(confdiviteamdata) {
                                diviteamData  =  {};
                               diviteamData['team_id']  =  confdiviteamdata.id;
                                diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
                                diviteamData['wins']  =  confdiviteamdata.wins;
                                diviteamData['loses']  =  confdiviteamdata.losses;
                                diviteamData['win_pct']  =  confdiviteamdata.win_pct;
                                diviteamData['pf']  =  confdiviteamdata.points_for;
                                diviteamData['pa']  =  confdiviteamdata.points_against;
                                diviteamData['diff']  =  confdiviteamdata.point_diff;
								if(confdiviteamdata.games_behind){
									diviteamData['game_behind_c_f']  =  confdiviteamdata.games_behind.conference +'-'+ confdiviteamdata.games_behind.division;
								}else{
									diviteamData['game_behind_c_f']  =  "";
								}
                                
                                //diviteamData['game_behind_c_f']  =  confdiviteamdata.games_behind.conference +'-'+ confdiviteamdata.games_behind.division;
                                diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
                                if(typeof confdiviteamdata.records !='undefined'){
                                  (confdiviteamdata.records).forEach(function(confdivirecdata) {
                                    if(confdivirecdata.record_type=='home'){
                                        diviteamData['home']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='road'){
                                        diviteamData['road']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='division'){
                                      diviteamData['division']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='conference'){
                                       diviteamData['conference']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='last_10'){
                                        diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='three_points'){
                                       diviteamData['three_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='ten_points'){
                                        diviteamData['ten_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='over_500'){
                                       diviteamData['over_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='below_500'){
                                      diviteamData['below_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }else if(confdivirecdata.record_type=='overtime'){
                                      diviteamData['overtime']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
                                    }
                                  })
                                }
                               (awayteam.teams).push(diviteamData);
                           })
                          }
                      })
                   }
                   (response.conference).push(awayteam);
              } 
               
              index++;
            })
		  
			
			
			res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
});

app.get('/get_standing_nhl/:season',(req,res) =>{
    var response = {};
    Standing.findOne({season:req.params.season,league:"NHL"}).then((stands) =>{
		Fddemand.aggregate([{$match:{ type:"NHL"}},{$group:{ _id: { home_id: "$home_id",home_team: "$home_team"},totalDemand: { $sum: "$demand" }}}]).exec( function (err, fddemand) {
			if (stands) { 
            response.message = "Standing Data Available !";
            response.status = true;
            response.conference = [];
            response.fandemand = [];
			async.forEach(fddemand,function(fddemandData) {
				fditem	=	{};
				fditem.team_id=	fddemandData._id.home_id;
				fditem.team_name=	fddemandData._id.home_team;
				fditem.demand=	(fddemandData.totalDemand).toFixed(2);
			 (response.fandemand).push(fditem);
			})
				
			
			 var index  = 0;
            (stands.standingData).reverse();
            (stands.standingData).forEach(function(confdata) {
              	hometeam =  {};
              	awayteam =  {};
              	if(index==0){
                  	hometeam.name = confdata.name;
                  	hometeam.alias = confdata.alias;
              	 	hometeam.division = [];
                   	if(typeof confdata.divisions !='undefined'){
                      (confdata.divisions).forEach(function(confdividata) {
                      	   divisionData  =  {};
                      	   divisionData.name=confdividata.name;
                      	   divisionData.alias=confdividata.alias;
                      	   divisionData.team=[];
                          	if(typeof confdividata.teams !='undefined'){
							 	var serial_no	=	1; 
	                            (confdividata.teams).forEach(function(confdiviteamdata) {
	                                diviteamData  =  {};
	                                diviteamData['team_id']  =  confdiviteamdata.id;
	                                diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
	                                diviteamData['team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(confdiviteamdata.market+' '+confdiviteamdata.name)+'.png';
	                                diviteamData['gp']  =  confdiviteamdata.games_played;
	                                diviteamData['win']  =  confdiviteamdata.wins;
	                                diviteamData['loss']  =  confdiviteamdata.losses;
	                                diviteamData['otl']  =  confdiviteamdata.overtime_losses;
	                                diviteamData['pts']  =  confdiviteamdata.points;
	                                diviteamData['row']  =  confdiviteamdata.regulation_wins;
	                                diviteamData['sow']  =  confdiviteamdata.shootout_wins;
	                                 diviteamData['sol']  =  confdiviteamdata.shootout_losses;
	                                diviteamData['gf']  =  confdiviteamdata.goals_for;
	                                diviteamData['ga']  =  confdiviteamdata.goals_against;
	                                diviteamData['diff']  =  confdiviteamdata.goal_diff;
	                                diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
	                                if(typeof confdiviteamdata.records !='undefined'){
	                                  (confdiviteamdata.records).forEach(function(confdivirecdata) {
	                                  

	                                    if(confdivirecdata.record_type=='last_10'){
	                                        diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses +'-'+ confdivirecdata.overtime_losses;
	                                    }
	                                  })
	                                }
	                               (divisionData.team).push(diviteamData);
	                            })
                          	}
                           (hometeam.division).push(divisionData);
                      })
                   }
                 
                  (response.conference).push(hometeam);
              }else{
            	awayteam.name = confdata.name;
                awayteam.alias = confdata.alias;
              	awayteam.division = [];
                if(typeof confdata.divisions !='undefined'){
                    (confdata.divisions).forEach(function(confdividata) {
                	 	divisionData  =  {};
                  	   	divisionData.name=confdividata.name;
                  	   	divisionData.alias=confdividata.alias;
              	   		divisionData.team=[];
                        if(typeof confdividata.teams !='undefined'){
                            (confdividata.teams).forEach(function(confdiviteamdata) {
                                diviteamData  =  {};
								diviteamData['team_id']  =  confdiviteamdata.id;
                                diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
								diviteamData['team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(confdiviteamdata.market+' '+confdiviteamdata.name)+'.png';
                                diviteamData['gp']  =  confdiviteamdata.games_played;
                                diviteamData['win']  =  confdiviteamdata.wins;
                                diviteamData['loss']  =  confdiviteamdata.losses;
                                diviteamData['otl']  =  confdiviteamdata.overtime_losses;
                                diviteamData['pts']  =  confdiviteamdata.points;
                                diviteamData['row']  =  confdiviteamdata.regulation_wins;
                                diviteamData['sow']  =  confdiviteamdata.shootout_wins;
                                diviteamData['sol']  =  confdiviteamdata.shootout_losses;
                                diviteamData['gf']  =  confdiviteamdata.goals_for;
                                diviteamData['ga']  =  confdiviteamdata.goals_against;
                                diviteamData['diff']  =  confdiviteamdata.goal_diff;
                                diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
                                if(typeof confdiviteamdata.records !='undefined'){
                                  (confdiviteamdata.records).forEach(function(confdivirecdata) {
                                  

                                    if(confdivirecdata.record_type=='last_10'){
                                        diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses +'-'+ confdivirecdata.overtime_losses;
                                    }
                                  })
                                }
                             	
                               (divisionData.team).push(diviteamData);
                           })
                          }
                           (awayteam.division).push(divisionData);
                      })
                   }
                   (response.conference).push(awayteam);
              }
               
              index++;
            })
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
		})
        
    });
});

app.get('/get_standing_wildcard_nhl/:season',(req,res) =>{
	  var response = {};
    Standing.findOne({season:req.params.season,league:"NHL"}).then((stands) =>{
		Fddemand.aggregate([{$match:{ type:"NHL"}},{$group:{ _id: { home_id: "$home_id",home_team: "$home_team"},totalDemand: { $sum: "$demand" }}}]).exec( function (err, fddemand) {
			if (stands) { 
            response.message = "Standing Wildcard Data Available !";
            response.status = true;
            response.conference = [];
			response.fandemand = [];
			async.forEach(fddemand,function(fddemandData) {
				fditem	=	{};
				fditem.team_id=	fddemandData._id.home_id;
				fditem.team_name=	fddemandData._id.home_team;
				fditem.demand=	(fddemandData.totalDemand).toFixed(2);
			 (response.fandemand).push(fditem);
			})
				
			
			 var index  = 0;
            (stands.standingData).reverse();
            (stands.standingData).forEach(function(confdata) {
              	hometeam =  {};
              	awayteam =  {};
              	if(index==0){	
                  	hometeam.name = confdata.name;
                  	hometeam.alias = confdata.alias;
              	 	hometeam.division = [];
              	 	hometeam.wildcard = [];
                   	if(typeof confdata.divisions !='undefined'){
                      (confdata.divisions).forEach(function(confdividata) {
                      	   divisionData  =  {};
                      	   divisionData.name=confdividata.name;
							divisionData.alias=confdividata.alias;
                      	   divisionData.team=[];
                          	if(typeof confdividata.teams !='undefined'){
							 	var serial_no	=	1; 
	                            (confdividata.teams).forEach(function(confdiviteamdata) {
									if(typeof confdiviteamdata.rank.wildcard == 'undefined'){
										
										diviteamData  =  {};
										diviteamData['team_id']  =  confdiviteamdata.id;
										diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
										diviteamData['team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(confdiviteamdata.market+' '+confdiviteamdata.name)+'.png';
										diviteamData['gp']  =  confdiviteamdata.games_played;
										diviteamData['win']  =  confdiviteamdata.wins;
										diviteamData['loss']  =  confdiviteamdata.losses;
										diviteamData['otl']  =  confdiviteamdata.overtime_losses;
										diviteamData['pts']  =  confdiviteamdata.points;
										diviteamData['row']  =  confdiviteamdata.regulation_wins;
										diviteamData['sow']  =  confdiviteamdata.shootout_wins;
										 diviteamData['sol']  =  confdiviteamdata.shootout_losses;
										diviteamData['gf']  =  confdiviteamdata.goals_for;
										diviteamData['ga']  =  confdiviteamdata.goals_against;
										diviteamData['diff']  =  confdiviteamdata.goal_diff;
										diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
										if(typeof confdiviteamdata.records !='undefined'){
										  (confdiviteamdata.records).forEach(function(confdivirecdata) {
										  

											if(confdivirecdata.record_type=='last_10'){
												diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses +'-'+ confdivirecdata.overtime_losses;
											}
										  })
										}
									   (divisionData.team).push(diviteamData);
									}else{
										diviteamData  =  {};
										diviteamData['team_id']  =  confdiviteamdata.id;
										diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
										diviteamData['team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(confdiviteamdata.market+' '+confdiviteamdata.name)+'.png';
										diviteamData['gp']  =  confdiviteamdata.games_played;
										diviteamData['win']  =  confdiviteamdata.wins;
										diviteamData['loss']  =  confdiviteamdata.losses;
										diviteamData['otl']  =  confdiviteamdata.overtime_losses;
										diviteamData['pts']  =  confdiviteamdata.points;
										diviteamData['row']  =  confdiviteamdata.regulation_wins;
										diviteamData['sow']  =  confdiviteamdata.shootout_wins;
										diviteamData['sol']  =  confdiviteamdata.shootout_losses;
										diviteamData['gf']  =  confdiviteamdata.goals_for;
										diviteamData['ga']  =  confdiviteamdata.goals_against;
										diviteamData['diff']  =  confdiviteamdata.goal_diff;
										diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
										diviteamData['wildcard']  =  confdiviteamdata.rank.wildcard;
										if(typeof confdiviteamdata.records !='undefined'){
										  (confdiviteamdata.records).forEach(function(confdivirecdata) {
										  

											if(confdivirecdata.record_type=='last_10'){
												diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses +'-'+ confdivirecdata.overtime_losses;
											}
										  })
										}
									   (hometeam.wildcard).push(diviteamData);
									}
	                            })
                          	}
                           (hometeam.division).push(divisionData);
                      })
					}
					hometeam.division = dt.sortByKeyasc(hometeam.division,"name");
					hometeam.wildcard = dt.sortByKeyasc(hometeam.wildcard,"wildcard");
					
					(response.conference).push(hometeam);
				}else{
					awayteam.name = confdata.name;
					awayteam.alias = confdata.alias;
					awayteam.division = [];
					awayteam.wildcard = [];
					if(typeof confdata.divisions !='undefined'){
						(confdata.divisions).forEach(function(confdividata) {
							divisionData  =  {};
							divisionData.name=confdividata.name;
							divisionData.alias=confdividata.alias;
							divisionData.team=[];
							if(typeof confdividata.teams !='undefined'){
								(confdividata.teams).forEach(function(confdiviteamdata) {
									if(typeof confdiviteamdata.rank.wildcard == 'undefined'){
										diviteamData  =  {};
										diviteamData['team_id']  =  confdiviteamdata.id;
										diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
										diviteamData['team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(confdiviteamdata.market+' '+confdiviteamdata.name)+'.png';
										diviteamData['gp']  =  confdiviteamdata.games_played;
										diviteamData['win']  =  confdiviteamdata.wins;
										diviteamData['loss']  =  confdiviteamdata.losses;
										diviteamData['otl']  =  confdiviteamdata.overtime_losses;
										diviteamData['pts']  =  confdiviteamdata.points;
										diviteamData['row']  =  confdiviteamdata.regulation_wins;
										diviteamData['sow']  =  confdiviteamdata.shootout_wins;
										diviteamData['sol']  =  confdiviteamdata.shootout_losses;
										diviteamData['gf']  =  confdiviteamdata.goals_for;
										diviteamData['ga']  =  confdiviteamdata.goals_against;
										diviteamData['diff']  =  confdiviteamdata.goal_diff;
										diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
										if(typeof confdiviteamdata.records !='undefined'){
										  (confdiviteamdata.records).forEach(function(confdivirecdata) {
										  

											if(confdivirecdata.record_type=='last_10'){
												diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses +'-'+ confdivirecdata.overtime_losses;
											}
										  })
										}
									
										(divisionData.team).push(diviteamData);
									}else{
										diviteamData  =  {};
										diviteamData['team_id']  =  confdiviteamdata.id;
										diviteamData['team_name']  =  confdiviteamdata.market+' '+confdiviteamdata.name;
										diviteamData['team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(confdiviteamdata.market+' '+confdiviteamdata.name)+'.png';
										diviteamData['gp']  =  confdiviteamdata.games_played;
										diviteamData['win']  =  confdiviteamdata.wins;
										diviteamData['loss']  =  confdiviteamdata.losses;
										diviteamData['otl']  =  confdiviteamdata.overtime_losses;
										diviteamData['pts']  =  confdiviteamdata.points;
										diviteamData['row']  =  confdiviteamdata.regulation_wins;
										diviteamData['sow']  =  confdiviteamdata.shootout_wins;
										diviteamData['sol']  =  confdiviteamdata.shootout_losses;
										diviteamData['gf']  =  confdiviteamdata.goals_for;
										diviteamData['ga']  =  confdiviteamdata.goals_against;
										diviteamData['diff']  =  confdiviteamdata.goal_diff;
										diviteamData['strk']  =  confdiviteamdata.streak.kind +' '+ confdiviteamdata.streak.length;
										diviteamData['wildcard']  =  confdiviteamdata.rank.wildcard;
										if(typeof confdiviteamdata.records !='undefined'){
										  (confdiviteamdata.records).forEach(function(confdivirecdata) {
										  

											if(confdivirecdata.record_type=='last_10'){
												diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses +'-'+ confdivirecdata.overtime_losses;
											}
										  })
										}
									   (awayteam.wildcard).push(diviteamData);
									}
							   })
							}
							   (awayteam.division).push(divisionData);
						})
					}
					awayteam.division = dt.sortByKeyasc(awayteam.division,"name");
					awayteam.wildcard = dt.sortByKeyasc(awayteam.wildcard,"wildcard");
					(response.conference).push(awayteam);
				}
               
              index++;
            })
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
		})
        
    });
	
})

app.get('/get_leaders_dashboard/:season/:league',(req,res) =>{
    var response = {};
	Leaders.aggregate([{$match:{league:req.params.league,rank:1}},{
        "$lookup": {
            "from": "playerimages", 
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    },{ $group : {_id:{categories_type:"$categories_type"},records: { $push:  {  categories_name: "$categories_name",categories_type: "$categories_type",  primary_position: "$primary_position", player_pic: "$player_pic", player_id: "$player_id",team_market: "$team_market" , team_name: "$team_name" ,rank: "$rank" ,  avg_points: "$avg_points" ,player_name: "$player_name" , playerImage:"$playerImage" } }}}]).exec( function (err, leades) {	
        if (leades) {
			var leadersArr	=	[];			
		   (leades).forEach(function(lead) {
			   (lead.records).forEach(function(leadesdata) {
					leadersData	=	{};
				    leadersData['categories_name']  =  dt.camelize((leadesdata.categories_name).split('_').join(' '));
					leadersData['categories_name_slug']  =  leadesdata.categories_name;
					leadersData['categories_type']  =   dt.camelize(leadesdata.categories_type);
					leadersData['categories_type_slug']  =  leadesdata.categories_type;
					leadersData['primary_position']  =  leadesdata.primary_position;
					leadersData['player_id']  =  leadesdata.player_id;
					if(typeof leadesdata.player_id !="undefined"){
					if((leadesdata['playerImage']).length > 0){
						var dir  =  "/var/sports/public/upload/player/nba/"+leadesdata['playerImage'][0]['asset_id']+"/120x120-crop.JPG";
						if (fs.existsSync(dir) ) {
							leadersData['player_pic']  =  app.get('siteUrl')+"/upload/player/nba/"+leadesdata['playerImage'][0]['asset_id']+"/120x120-crop.JPG";
						}else{
							leadersData['player_pic']  =  "";
						}
						
					}else{
						leadersData['player_pic']  =  "";
					}
				 
				 }else{
					 leadersData['player_pic'] =  "";
				 }
				 delete leadersData["playerImage"];
					leadersData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(leadesdata.team_market+"_"+leadesdata.team_name)+'.png';
			   
					leadersData['player_name']  =  leadesdata.player_name;
					leadersData['team_market']  =  leadesdata.team_market;
					leadersData['avg_points']  =  leadesdata.avg_points;
					leadersData['rank']  =  leadesdata.rank;
					(leadersArr).push(leadersData);
				})
			   })
				
            response.leaders = leadersArr;
            response.message = "Leaders Data Available !";
            response.status = true;
			res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
});

app.get('/get_leaders_dashboard_detail/:season/:league/:categories_name/:categories_type',(req,res) =>{
    var response = {};
	Leaders.aggregate([{$match:{season:req.params.season,league:req.params.league,categories_name:req.params.categories_name,categories_type:req.params.categories_type}},{
        "$lookup": {
            "from": "playerimages", 
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    },{ $group : {_id:{rank:"$rank"},records: { $push:  {  categories_name: "$categories_name",categories_type: "$categories_type",  primary_position: "$primary_position", player_pic: "$player_pic", player_id: "$player_id",team_market: "$team_market" ,team_name: "$team_name" , rank: "$rank" ,  avg_points: "$avg_points" ,player_name: "$player_name" , playerImage:"$playerImage" } }}},{$sort:{"_id.rank":1}}]).exec( function (err, leades) {	
        if (leades) {
			var leadersArr	=	[];			
		   (leades).forEach(function(lead) {
			   (lead.records).forEach(function(leadesdata) {
					leadersData	=	{};
				    leadersData['categories_name']  =  dt.camelize((leadesdata.categories_name).split('_').join(' '));
					leadersData['categories_name_slug']  =  leadesdata.categories_name;
					leadersData['categories_type']  =   dt.camelize(leadesdata.categories_type);
					leadersData['categories_type_slug']  =  leadesdata.categories_type;
					leadersData['primary_position']  =  leadesdata.primary_position;
					leadersData['player_id']  =  leadesdata.player_id;
					if(typeof leadesdata.player_id !="undefined"){
					if((leadesdata['playerImage']).length > 0){
						var dir  =  "/var/sports/public/upload/player/nba/"+leadesdata['playerImage'][0]['asset_id']+"/120x120-crop.JPG";
						if (fs.existsSync(dir) ) {
							leadersData['player_pic']  =  app.get('siteUrl')+"/upload/player/nba/"+leadesdata['playerImage'][0]['asset_id']+"/120x120-crop.JPG";
						}else{
							leadersData['player_pic']  =  "";
						}
						
					}else{
						leadersData['player_pic']  =  "";
					}
				 
				 }else{
					 leadersData['player_pic'] =  "";
				 }
				 delete leadersData["playerImage"];
				
					leadersData['home_team_logo']  =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(leadesdata.team_market+"_"+leadesdata.team_name)+'.png';
					leadersData['player_name']  =  leadesdata.player_name;
					leadersData['team_market']  =  leadesdata.team_market;
					leadersData['avg_points']  =  leadesdata.avg_points;
					leadersData['rank']  =  leadesdata.rank;
					(leadersArr).push(leadersData);
				})
			   })
				
            response.leaders = leadersArr;
            response.message = "Leaders Data Available !";
            response.status = true;
			res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });

});

app.get('/get_nhl_leaders',(req,res) =>{
    var response = {};
	Leaders.aggregate([{$match:{league:"NHL"}},{
        "$lookup": {
            "from": "playerimages", 
            "localField": "player_name",
            "foreignField": "player_name",
            "as": "playerImage"
        }
    },{ $group : {_id:{categories_name:"$categories_name",rank:"$rank"},records: { $push:  {  player_name: "$player_name",categories_type: "$categories_type", categories_name: "$categories_name",team_name: "$team_name", team_market: "$team_market",rank: "$rank", player_id: "$player_id", playerImage:"$playerImage",games_played: "$games_played", score: "$score" } }}}, {$sort:{"_id.rank":1}}]).exec( function (err, leaders) {
		     if (leaders) { 

           leadersdata  =  [];
           (leaders).forEach(function(lead){
              leading =  {};
              if(lead.records[0].rank==1){
          			lead.records[0].categories_type_slug  =  lead.records[0].categories_name;
	              	lead.records[0].categories_type  =   lead.records[0].categories_type;
	        
	              	lead.records[0].primary_position  =  lead.records[0].primary_position;
	              	lead.records[0].player_id  =  lead.records[0].player_id;
					if(typeof lead.records[0].player_id !="undefined"){
						
					if((lead.records[0].playerImage).length > 0){
						console.log(lead.records[0].playerImage[0]);
						var dir  =  "/var/sports/public/upload/player/nhl/"+lead.records[0].playerImage[0]['asset_id']+"/180x180-crop.jpg";
						if (fs.existsSync(dir) ) {
							lead.records[0].player_pic  =  app.get('siteUrl')+"/upload/player/nhl/"+lead.records[0].playerImage[0]['asset_id']+"/180x180-crop.jpg";
						}else{
							lead.records[0].player_pic  =  "";
						}
						
					}else{
						lead.records[0].player_pic  =  "";
					}
				 
				 }else{
					 lead.records[0].player_pic =  "";
				 }
				 delete lead.records[0].playerImage;
	              	lead.records[0].player_name  =  lead.records[0].player_name;
	              	lead.records[0].team_name  =  lead.records[0].team_name;
					lead.records[0].home_team_logo  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(lead.records[0].team_market+"-"+lead.records[0].team_name)+'.png';
	              	lead.records[0].team_market  =  lead.records[0].team_market;
	              	lead.records[0].score =  lead.records[0].score;
	              	lead.records[0].rank =  lead.records[0].rank;
	              	lead.records[0].games_played =  lead.records[0].games_played;
	    				
	             	(leadersdata).push(lead.records[0]);
              }
              
           }) 
            response.message = "NHL Leader Available !";
            response.status = true;
            response.leaders = leadersdata;
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
});

app.get('/get_nhl_leaders_details/:categories_type_slug',(req,res) =>{
    var response = {};
	Leaders.aggregate([{$match:{league:"NHL","categories_name":req.params.categories_type_slug}},{
        "$lookup": {
            "from": "playerimages", 
            "localField": "player_name",
            "foreignField": "player_name",
            "as": "playerImage"
        }
    },{ $group : {_id:{rank:"$rank"},records: { $push:  {  season:"$season",player_name: "$player_name",categories_type: "$categories_type", categories_name: "$categories_name",team_name: "$team_name", team_market: "$team_market",rank: "$rank", player_id: "$player_id", playerImage:"$playerImage",games_played: "$games_played", score: "$score" } }}}, {$sort:{"_id.rank":1}}]).exec( function (err, leaders) {
		     if (leaders) { 

           leadersdata  =  [];
           (leaders).forEach(function(lead){
				leading =  {};
				lead.records[0]._id  =  lead.records[0]._id;
				lead.records[0].season  =  lead.records[0].season;
				lead.records[0].categories_name  =  lead.records[0].categories_name;
				lead.records[0].categories_type  =   lead.records[0].categories_type;

				lead.records[0].player_name  =  lead.records[0].player_name;
				lead.records[0].team_name  =  lead.records[0].team_name;
				lead.records[0].team_market  =  lead.records[0].team_market;
				lead.records[0].home_team_logo  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(lead.records[0].team_market+"-"+lead.records[0].team_name)+'.png';
				lead.records[0].score =  lead.records[0].score;
				lead.records[0].rank =  lead.records[0].rank;
				lead.records[0].games_played =  lead.records[0].games_played;
				lead.records[0].avg_minutes =  lead.records[0].avg_minutes;
				if(typeof lead.records[0].player_id !="undefined"){
						
					if((lead.records[0].playerImage).length > 0){
						console.log(lead.records[0].playerImage[0]);
						var dir  =  "/var/sports/public/upload/player/nhl/"+lead.records[0].playerImage[0]['asset_id']+"/180x180-crop.jpg";
						if (fs.existsSync(dir) ) {
							lead.records[0].player_pic  =  app.get('siteUrl')+"/upload/player/nhl/"+lead.records[0].playerImage[0]['asset_id']+"/180x180-crop.jpg";
						}else{
							lead.records[0].player_pic  =  "";
						}
						
					}else{
						lead.records[0].player_pic  =  "";
					}
				 
				}else{
					 lead.records[0].player_pic =  "";
				}
				delete lead.records[0].playerImage;
					
				(leadersdata).push(lead.records[0]);
              
			}) 
            response.message = "NHL Leader Available !";
            response.status = true;
            response.leaders = leadersdata;
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
    /* Leaders.find({league:"NHL","categories_name":req.params.categories_type_slug}).sort({"rank":1}).exec( function (err, leaders) {
     	if(leaders){ 
			leadersdata  =  [];
			(leaders).forEach(function(lead){
				leading =  {};
				leading._id  =  lead._id;
				leading.season  =  lead.season;
				leading.categories_name  =  lead.categories_name;
				leading.categories_type  =   lead.categories_type;
		
				leading.player_pic  =  "";
				leading.player_name  =  lead.player_name;
				leading.team_name  =  lead.team_name;
				leading.team_market  =  lead.team_market;
				leading.score =  lead.score;
				leading.rank =  lead.rank;
				leading.games_played =  lead.games_played;
				leading.avg_minutes =  lead.avg_minutes;
					
				(leadersdata).push(leading);
              
			}) 
			response.message = "NHL Leader Available !";
            response.status = true;
            response.leaders = leadersdata;
            res.status(200).send(JSON.stringify(response));
      	}else{
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
      	}
    }); */
});

app.get('/download_image_player',(req,res) =>{
	 Player.find({}).sort({}).exec(function (err, player) {
        if (player) { 
           (player).forEach(function(playe){
				var options = {
				  url: playe.profile_image_90+"?api_key=s9h4vb8krqv55aemuughuufb",
				  dest: '/var/sports/public/upload/player'                 
				}
				 
				download.image(options)
				  .then(({ filename, image }) => {
					console.log('File saved to', filename)
				  })
				  .catch((err) => {
					console.error(err)
				})
          })
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });

});

app.get('/download_image_venues',(req,res) =>{
	Venues.find({}, function (err, venue) {
			if(venue.length>0){
				
				if(venue[0]['league'] == "NBA"){
					var options = {
					  url: 'https://api.sportradar.us/nba-images-t3/getty'+venue[0]['links'][2]['href']+"?api_key=s9h4vb8krqv55aemuughuufb",
					  dest: '/var/sports/public/upload/venue'                 
					}
					download.image(options)
					  .then(({ filename, image }) => {
						console.log('File saved to', filename)
					  })
					  .catch((err) => {
						console.error(err)
					})
				}else if(venue[0]['league'] == "NFL"){
					var options = {
					  url: 'https://api.sportradar.us/nfl-images-t3/ap'+venue[0]['links'][2]['href']+"?api_key=dvmbpwwn5z53sq3rs6d9u32h",
					  dest: '/var/sports/public/upload/venue'                 
					}
					 
					download.image(options)
					  .then(({ filename, image }) => {
						console.log('File saved to', filename)
					  })
					  .catch((err) => {
						console.error(err)
					})
				}
				
			}
			
		

	})
})

app.get('/leagues', (req, res) => {
	  var response = {};
	leagueResult  = [];

	leagueData = {};
	leagueData['title']  = "NBA";
	leagueData['league_image']  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/leagues/nba.png";
	(leagueResult).push(leagueData);
	leagueData = {};
	leagueData['title']  = "NFL";
	leagueData['league_image']  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/leagues/nfl.png";
	(leagueResult).push(leagueData);
	leagueData = {};
	leagueData['title']  = "NHL";
	leagueData['league_image']  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/leagues/nhl.png";
	(leagueResult).push(leagueData);
	leagueData = {};
	leagueData['title']  = "MLB";
	leagueData['league_image']  =  "http://ec2-13-127-142-209.ap-south-1.compute.amazonaws.com:3000/upload/leagues/mlb.png";
	(leagueResult).push(leagueData);
	response.message = "League  data !";
	response.status = true;
	response.league = leagueResult;
	res.status(200).send(JSON.stringify(response));
})

app.get('/votes', (req, res) => {
  var response = {};
  User.find({_id:mongoose.Types.ObjectId("5c48115fd6b5ee060788e97d")}).populate({path:'post_id',  options: {sort: { _id: -1 }},populate: { path:'likes',path: 'comment_id'}}).exec(function (err, userData) {
      if (userData) { 
          userResult  = [];

          (userData).forEach(function(user) {
            votesData = {};
            votesData['id']  = user._id;
            votesData['fname']  = user.fname;
            votesData['lname']  = user.lname; 
            votesData['post']  =  [];
           posts  =  [];
            if((user.post_id).length > 0){
                var post_count =0;
               (user.post_id).forEach(function(userPost) {
                    posteData  =  {};
                    posteData._id  = userPost._id;
                    posteData.title  = userPost.title;
                    posteData.owner  = userPost.owner;
                   posteData.status  = userPost.status;
                   posteData.comment  = userPost.comment_id;
                   posteData.comment_count  = (userPost.comment_id).length;
                   posteData.like_count  = (userPost.likes).length;
                //  votesData['post'][post_count]['comment_count'] = (userPost.comment_id).length;
                       // votesData['post'][post_count]['like_count'] = (userPost.likes).length;
                        /*(userPost.comment_id).forEach(function(userPostComentcomData) {
                            if((comData.reply).length > 0){
                              var reply_count =0;
                              async.each((comData.reply),function(comreplyData) {
                                  votesData['comment'][comment_count]['reply'][reply_count]['user'] = comreplyData.user;
                                  votesData['comment'][comment_count]['reply'][reply_count]['content'] = comreplyData.content;
                                  reply_count++;
                              })
                            }
                            comment_count++;
                        });*/
                        (votesData['post']).push(posteData);
                        post_count++;
                    
               })
             
            }

             //
            votesData['created']  = moment(user.created_at).format("YYYY-MM-DD HH:mm");
            userResult.push(votesData);
          })
          response.message = "Voting  data !";
          response.status = true;
          response.Vote = userResult;
             
          res.status(200).send(JSON.stringify(response));
      } else {
        response.message = "No Data!";
        response.status = false;
        res.status(400).send(JSON.stringify(response));
      }
  })
});

app.post('/save_post', (req, res) => {
	console.log(req.body);
    let {title, owner} = req.body; 
    let postData = {
      title,
      owner
    };  
  
    var post = new Post(postData);
    var response = {};
    post.save(function(err, post) {
        if (err) {
          response.message = err;
          response.status = false;
          res.status(400).send(JSON.stringify(response));
        }else{
       
			User.findOneAndUpdate({ _id: mongoose.Types.ObjectId(owner) },{ $addToSet: {post_id: post._id } }, function(err, postUpdate) {
				if (err) {
					response.message = err;
					response.status = false;
					res.status(400).send(JSON.stringify(response));
				}else{ 
					response.message = "post saved";
					response.post = post;
					response.status = true;
					res.status(200).send(JSON.stringify(response));
				}
			}) 
         
        }  
    })
});

app.post('/save_demand', (req, res) => {
	var response = {};
	if(req.body && req.body.filename ==""){
		 
		req.body.user_id	=	 mongoose.Types.ObjectId(user_id);
		var voteData = new Vote(req.body);
		voteData.save(function(err, vote) {
			if (err) {
			  response.message = err;
			  response.status = false;
			  res.status(400).send(JSON.stringify(response));
			}else{
				response.message = "demand saved";
			  response.status = true;
			  res.status(200).send(JSON.stringify(response));
			}
		})
	}else{
		var form = new formidable.IncomingForm();
		let demandData = {};
		var file_name ="";
		form.parse(req).on('fileBegin', function(name, file) {
			 extension = path.extname(file.name);
			 file_name = new Date().getTime()+"_votes"+ extension;
			
			 file.path = __dirname + '/public/upload/media/' + file_name;
		}).on('file', function (name, file){
			
			demandData.filepath	=	file_name;
			 console.log('Uploaded ' + file_name);
		 }).on('field', function (name, field){
			 if(name=="user_id"){
				 demandData[name]	=	mongoose.Types.ObjectId(field);
			 }else{
				 demandData[name]	=	field;
			 }
				
			
		 }).on('end', function() {
			var voteData = new Vote(demandData);
				voteData.save(function(err, vote) {
					if (err) {
					  response.message = err;
					  response.status = false;
					  res.status(400).send(JSON.stringify(response));
					}else{
						response.message = "demand saved";
					  response.status = true;
					  res.status(200).send(JSON.stringify(response));
					}
				})
			});
	}
	

});

app.get('/get_demand', (req, res) => {
	var response = {};
	Vote.find({}).populate({path:'user_id'}).sort({_id:-1}).exec(function (err, votes) {
		if(votes){ 
			votesdata  =  [];
			(votes).forEach(function(voting){
				voteRec =  {};
				voteRec.game_id  =  voting.game_id;
				voteRec.type  =  voting.type;
				voteRec.team  =  voting.team;
				voteRec.message  =   voting.message;
		
				voteRec.filepath  =  app.get('siteUrl')+'/upload/media/'+voting.filepath;
				voteRec.demand  =  (voting.demand).toFixed(2);
				voteRec.change_demand  =  (voting.change_demand).toFixed(2);
				voteRec.userInfo  =  voting.user_id.fname+" "+voting.user_id.lname;
				voteRec.created  =  moment(voting.created_at).format("YYYY-MM-DD HH:mm");
				
				(votesdata).push(voteRec);
              
			}) 
			response.message = "Vote Available !";
            response.status = true;
            response.votes = votesdata;
            res.status(200).send(JSON.stringify(response));
      	}else{
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
      	}
	})
	

});

app.post('/post_comment', (req, res) => {
    let {post, comment_body} = req.body; 
    let commentData = {
      post,
      comment_body
    };  
    var comment = new Comment(commentData);
    var response = {};
    comment.save(function(err, comment) {
        if (err) {
          response.message = err;
          response.status = false;
          res.status(400).send(JSON.stringify(response));
        }else{
          

          Post.findOneAndUpdate({ _id: mongoose.Types.ObjectId(post) },{ $addToSet: {comment_id: comment._id } }, function(err, commentUpdate) {
            if (err) {
              response.message = err;
              response.status = false;
              res.status(400).send(JSON.stringify(response));
            }else{
               response.message = "comment saved";
              response.status = true;
              res.status(200).send(JSON.stringify(response));
            }
          })
         
        }  
    })
});

app.post('/post_likes', (req, res) => {
    let {post, user} = req.body; 
    let likeData = {
      post,
      user
    }; 
    var response = {}; 
    Post.findOneAndUpdate({ _id: mongoose.Types.ObjectId(post) },{ $addToSet: {likes: mongoose.Types.ObjectId(user) } }, function(err, commentUpdate) {
        if (err) {
          response.message = err;
          response.status = false;
          res.status(400).send(JSON.stringify(response));
        }else{
           response.message = "Post liked";
          response.status = true;
          res.status(200).send(JSON.stringify(response));
        }
      })
});

app.post('/reply', (req, res) => {
  let {post, comment,content} = req.body; 
  let replyData = {
      user,
      comment,content
    }; 
    var response = {};
    Comment.findOneAndUpdate({ _id: mongoose.Types.ObjectId(comment) },{ $addToSet: {reply:{post: mongoose.Types.ObjectId(post),content:content } }}, function(err, replyData) {
        if (err) {
              response.message = err;
              response.status = false;
              res.status(400).send(JSON.stringify(response));
            }else{
               response.message = "reply saved";
              response.status = true;
              res.status(200).send(JSON.stringify(response));
            }
    })
}); 

app.get('/get_division_nba',(req,res) =>{
    var response = {};
		Conference.find({league:"NBA"}).then((conference) =>{
		Fddemand.aggregate([{$match:{ type:"NBA"}},{$group:{ _id: { home_id: "$home_id",home_team: "$home_team"},totalDemand: { $sum: "$demand" }}}]).exec( function (err, fddemand) {
			if (conference) { 
				response.message = "Conference Data Available !";
				response.status = true;
				response.conference = conference;
				response.fandemand	=	[];
			   async.forEach(fddemand,function(fddemandData) {
					fditem	=	{};
					fditem.team_id=	fddemandData._id.home_id;
					fditem.team_name=	fddemandData._id.home_team;
					fditem.demand=	(fddemandData.totalDemand).toFixed(2);
				 (response.fandemand).push(fditem);
				})
				res.status(200).send(JSON.stringify(response));
			} else {
				response.message = "No Data!";
				response.status = false;
				res.status(400).send(JSON.stringify(response));
			}
		});
    });
});

app.get('/get_conference_nba',(req,res) =>{
    var response = {};
    Division.find({league:"NBA"}).sort({"teams.wins":1}).limit(10).then((division) =>{
		Fddemand.aggregate([{$match:{ type:"NBA"}},{$group:{ _id: { home_id: "$home_id",home_team: "$home_team"},totalDemand: { $sum: "$demand" }}}]).limit(10).exec( function (err, fddemand) {
			if (division) { 
			   divisions  =  [];
			   (division).forEach(function(divi){
				 divisi =  {};
				 divisi._id  =  divi._id;
				 divisi.season  =  divi.season;
				 divisi.league  =  divi.league;
				 divisi.conferences_name  =  divi.conferences_name;
				 divisi.conferences_alias  =  divi.conferences_alias;
				 divisi.teams  =  dt.sortByKey(divi.teams,'wins'); 
				 (divisions ).push(divisi);
			   })
				response.fandemand = [];
				async.forEach(fddemand,function(fddemandData) {
					fditem	=	{};
					fditem.team_id=	fddemandData._id.home_id;
					fditem.team_name=	fddemandData._id.home_team;
					fditem.demand=	(fddemandData.totalDemand).toFixed(2);
				 (response.fandemand).push(fditem);
				})
				response.message = "Division Data Available !";
				response.status = true;
				response.division = divisions;
			  
				res.status(200).send(JSON.stringify(response));
			  } else {
				response.message = "No Data!";
				response.status = false;
				res.status(400).send(JSON.stringify(response));
			  }
		});
    });
});


app.get('/get_mlb_al_leaders',(req,res) =>{
    var response = {};
	Leaders.aggregate([{$match:{league:"MLB","categories_name":"American League"}},{
        "$lookup": {
            "from": "playerimages", 
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    },{ $group : {_id:{categories_type:"$categories_type"},records: { $push:  {  player_name: "$player_name",player_id: "$player_id",  categories_type: "$categories_type", avg_points: "$avg_points", team_name: "$team_name" ,team_market: "$team_market" , rank: "$rank"  , primary_position: "$primary_position" ,playerImage:"$playerImage" } }}}, {$sort:{"_id.categories_type":1,"_id.avg_points":-1}}]).limit(20).exec( function (err, leaders) {
		     if (leaders) { 
           leadersdata  =  [];
           (leaders).forEach(function(lead){
              leading =  {};
              lead.records[0].categories_type_slug  =  lead.records[0].categories_type;
              lead.records[0].categories_type  =   dt.camelizeMlb(lead.records[0].categories_type);
        
              lead.records[0].primary_position  =  lead.records[0].primary_position;
               if(typeof lead.records[0].player_id !="undefined"){
				if((lead.records[0]['playerImage']).length > 0){
					var dir  =  "/var/sports/public/upload/player/mlb/"+lead.records[0]['playerImage'][0]['asset_id']+"/original.jpg";
					if (fs.existsSync(dir) ) {
						lead.records[0].player_pic  =  app.get('siteUrl')+"/upload/player/mlb/"+lead.records[0]['playerImage'][0]['asset_id']+"/original.jpg";
					}else{
						lead.records[0].player_pic  =  "";
					}
					
				}else{
					lead.records[0].player_pic  =  "";
				}
			 
			}else{
				 lead.records[0].player_pic  =  "";
			}
			delete lead.records[0]["playerImage"];
              lead.records[0].player_name  =  lead.records[0].player_name;
              lead.records[0].team_market  =  lead.records[0].team_market;
              lead.records[0].avg_points =  lead.records[0].avg_points;
              lead.records[0].rank =  lead.records[0].rank;
			  lead.records[0].home_team_logo  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(lead.records[0].team_market+"-"+lead.records[0].team_name)+'.png';
    				  if(lead.records[0].categories_type=="batting_average"){
    					 lead.records[0].type="Avg";
  				   }else if(lead.records[0].categories_type=="doubles"){
    					 lead.records[0].type="Double";
    				 }else if(lead.records[0].categories_type=="earned_run_average"){
    					 lead.records[0].type="ERA";
    				 }else if(lead.records[0].categories_type=="games_completed"){
    					 lead.records[0].type="GC";
    				 }else if(lead.records[0].categories_type=="games_saved"){
    					  lead.records[0].type="GS";
    				 }else if(lead.records[0].categories_type=="hits"){
    					  lead.records[0].type="H";
    				 }else if(lead.records[0].categories_type=="home_runs"){
    					  lead.records[0].type="HR";
    				 }else if(lead.records[0].categories_type=="runs_batted_in"){
    					   lead.records[0].type="RBI";
    				 }else if(lead.records[0].categories_type=="runs_scored"){
    					   lead.records[0].type="RS";
    				 }else if(lead.records[0].categories_type=="stolen_bases"){
    					   lead.records[0].type="SB";
    				 }else if(lead.records[0].categories_type=="strikeouts"){
    					   lead.records[0].type="SO";
    				 }else if(lead.records[0].categories_type=="triples"){
    					   lead.records[0].type="Triple";
    				 }else if(lead.records[0].categories_type=="whip"){
    					   lead.records[0].type="WH";
    				 }
             (leadersdata).push(lead.records[0]);
           }) 
            response.message = "American League Leader Available !";
            response.status = true;
            response.leaders = leadersdata;
           response.leagueName = "American League";
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
});

app.get('/get_mlb_al_leaders_details/:categories_type/:primary_position',(req,res) =>{
    var response = {};
	
	//Leaders.find({league:"MLB","categories_name":"American League","categories_type":req.params.categories_type}).sort({"rank":1}).exec( function (err, leaders) { 
	 Leaders.aggregate([ {$match:{league:"MLB",categories_name:"American League",categories_type:req.params.categories_type,primary_position:req.params.primary_position}},{
        "$lookup": {
            "from": "playerimages",
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    }, {$sort:{"rank":1}}]).exec( function (err, leaders) {
		if (leaders) { 
             leadersdata  =  [];
			 rankCounter=1;
           (leaders).forEach(function(lead){ 
               leading =  {};
              leading.categories_type_slug  =  lead.categories_type;
              leading.categories_type  =   dt.camelizeMlb(lead.categories_type);
        
              leading.primary_position  =  lead.primary_position;
              leading.profile_pic  =  "";
			  if(typeof lead.player_id !="undefined"){
				if((lead['playerImage']).length > 0){
					var dir  =  "/var/sports/public/upload/player/mlb/"+lead['playerImage'][0]['asset_id']+"/original.jpg";
					if (fs.existsSync(dir) ) {
						leading.profile_pic  =  app.get('siteUrl')+"/upload/player/mlb/"+lead['playerImage'][0]['asset_id']+"/original.jpg";
					}else{
						leading.profile_pic  =  "";
					}
					
				}else{
					leading.profile_pic  =  "";
				}
			 
			}else{
				 leading.profile_pic  =  "";
			}
			delete leading["playerImage"];
             leading.player_name  =  lead.player_name;
              leading.team_market  =  lead.team_market;
              leading.team_name  =  lead.team_name;
              leading.avg_points =  lead.avg_points;
			   leading.home_team_logo  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(leading.team_market+"-"+leading.team_name)+'.png';
             // leading.rank =  lead.rank;
              leading.rank =  rankCounter;
              if(leading.categories_type=="batting_average"){
              leading.type="Avg";
             }else if(leading.categories_type=="doubles"){
               leading.type="Double";
             }else if(leading.categories_type=="earned_run_average"){
               leading.type="ERA";
             }else if(leading.categories_type=="games_completed"){
               leading.type="GC";
             }else if(leading.categories_type=="games_saved"){
                leading.type="GS";
             }else if(leading.categories_type=="hits"){
                leading.type="H";
             }else if(leading.categories_type=="home_runs"){
                leading.type="HR";
             }else if(leading.categories_type=="runs_batted_in"){
                 leading.type="RBI";
             }else if(leading.categories_type=="runs_scored"){
                 leading.type="RS";
             }else if(leading.categories_type=="stolen_bases"){
                 leading.type="SB";
             }else if(leading.categories_type=="strikeouts"){
                 leading.type="SO";
             }else if(leading.categories_type=="triples"){
                 leading.type="Triple";
             }else if(leading.categories_type=="whip"){
                 leading.type="WH";
             }
             (leadersdata).push(leading);
             rankCounter++;
           }) 
            response.message = "American League Leader Available !";
             response.leagueName = "American League";
            response.status = true;
            response.leaders = leadersdata;
          
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
});

app.get('/get_mlb_nl_leaders',(req,res) =>{
    var response = {};

	Leaders.aggregate([{$match:{league:"MLB","categories_name":"National League"}},{
        "$lookup": {
            "from": "playerimages", 
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    },{ $group : {_id:{categories_type:"$categories_type", rank: "$rank" },records: { $push:  {  player_name: "$player_name",player_id: "$player_id", categories_type: "$categories_type", avg_points: "$avg_points", team_name: "$team_name" ,team_market: "$team_market", rank: "$rank"  , primary_position: "$primary_position",playerImage:"$playerImage" } }}}, {$sort:{"_id.categories_type":1,"_id.avg_points":-1}}]).limit(20).exec( function (err, leaders) {	
        if (leaders) { 
           leadersdata  =  [];
           (leaders).forEach(function(lead){ 
			leading =  {};
              lead.records[0].categories_type_slug  =  lead.records[0].categories_type;
              lead.records[0].categories_type  =   dt.camelizeMlb(lead.records[0].categories_type);
        
              lead.records[0].primary_position  =  lead.records[0].primary_position;
			  if(typeof lead.records[0].player_id !="undefined"){
				if((lead.records[0]['playerImage']).length > 0){
					var dir  =  "/var/sports/public/upload/player/mlb/"+lead.records[0]['playerImage'][0]['asset_id']+"/original.jpg";
					if (fs.existsSync(dir) ) {
						lead.records[0].player_pic  =  app.get('siteUrl')+"/upload/player/mlb/"+lead.records[0]['playerImage'][0]['asset_id']+"/original.jpg";
					}else{
						lead.records[0].player_pic  =  "";
					}
					
				}else{
					lead.records[0].player_pic  =  "";
				}
			 
			}else{
				 lead.records[0].player_pic  =  "";
			}
			delete lead.records[0]["playerImage"];
             // lead.records[0].player_pic  =  "";
              lead.records[0].player_name  =  lead.records[0].player_name;
              lead.records[0].team_market  =  lead.records[0].team_market;
              lead.records[0].avg_points =  lead.records[0].avg_points;
              lead.records[0].rank =  lead.records[0].rank;
			   lead.records[0].home_team_logo  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(lead.records[0].team_market+"-"+lead.records[0].team_name)+'.png';
              if(lead.records[0].categories_type=="batting_average"){
               lead.records[0].type="Avg";
             }else if(lead.records[0].categories_type=="doubles"){
               lead.records[0].type="Double";
             }else if(lead.records[0].categories_type=="earned_run_average"){
               lead.records[0].type="ERA";
             }else if(lead.records[0].categories_type=="games_completed"){
               lead.records[0].type="GC";
             }else if(lead.records[0].categories_type=="games_saved"){
                lead.records[0].type="GS";
             }else if(lead.records[0].categories_type=="hits"){
                lead.records[0].type="H";
             }else if(lead.records[0].categories_type=="home_runs"){
                lead.records[0].type="HR";
             }else if(lead.records[0].categories_type=="runs_batted_in"){
                 lead.records[0].type="RBI";
             }else if(lead.records[0].categories_type=="runs_scored"){
                 lead.records[0].type="RS";
             }else if(lead.records[0].categories_type=="stolen_bases"){
                 lead.records[0].type="SB";
             }else if(lead.records[0].categories_type=="strikeouts"){
                 lead.records[0].type="SO";
             }else if(lead.records[0].categories_type=="triples"){
                 lead.records[0].type="Triple";
             }else if(lead.records[0].categories_type=="whip"){
                 lead.records[0].type="WH";
             }
             (leadersdata).push(lead.records[0]);
             
           }) 
            response.message = "National League Leader Available !";
            response.status = true;
             response.leagueName = "National League";
            response.leaders = leadersdata;
          
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
});

app.get('/get_mlb_nl_leaders_details/:categories_type/:primary_position',(req,res) =>{
    var response = {};
	
	//Leaders.find({league:"MLB","categories_name":"National League","categories_type":req.params.categories_type}).sort({"rank":1}).exec( function (err, leaders) { 
	Leaders.aggregate([ {$match:{league:"MLB",categories_name:"National League",categories_type:req.params.categories_type,primary_position:req.params.primary_position}},{
        "$lookup": {
            "from": "playerimages",
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    }, {$sort:{"rank":1}}]).exec( function (err, leaders) {
		if (leaders) { 
             leadersdata  =  [];
			 rankCounter=1;
           (leaders).forEach(function(lead){ 
               leading =  {};
              leading.categories_type_slug  =  lead.categories_type;
              leading.categories_type  =   dt.camelizeMlb(lead.categories_type);
        
              leading.primary_position  =  lead.primary_position;
              leading.profile_pic  =  "";
			  if(typeof lead.player_id !="undefined"){
				if((lead['playerImage']).length > 0){
					var dir  =  "/var/sports/public/upload/player/mlb/"+lead['playerImage'][0]['asset_id']+"/original.jpg";
					if (fs.existsSync(dir) ) {
						leading.profile_pic  =  app.get('siteUrl')+"/upload/player/mlb/"+lead['playerImage'][0]['asset_id']+"/original.jpg";
					}else{
						leading.profile_pic  =  "";
					}
					
				}else{
					leading.profile_pic  =  "";
				}
			 
			}else{
				 leading.profile_pic  =  "";
			}
			delete leading["playerImage"];
             leading.player_name  =  lead.player_name;
              leading.team_market  =  lead.team_market;
              leading.avg_points =  lead.avg_points;
              //leading.rank =  lead.rank;
			  leading.rank =  rankCounter;
			   leading.team_name  =  lead.team_name;
			   leading.home_team_logo  =  app.get('siteUrl')+"/upload/teams/"+dt.mlbnameUnderscore(leading.team_market+"-"+leading.team_name)+'.png';
              if(leading.categories_type=="batting_average"){
              leading.type="Avg";
             }else if(leading.categories_type=="doubles"){
               leading.type="Double";
             }else if(leading.categories_type=="earned_run_average"){
               leading.type="ERA";
             }else if(leading.categories_type=="games_completed"){
               leading.type="GC";
             }else if(leading.categories_type=="games_saved"){
                leading.type="GS";
             }else if(leading.categories_type=="hits"){
                leading.type="H";
             }else if(leading.categories_type=="home_runs"){
                leading.type="HR";
             }else if(leading.categories_type=="runs_batted_in"){
                 leading.type="RBI";
             }else if(leading.categories_type=="runs_scored"){
                 leading.type="RS";
             }else if(leading.categories_type=="stolen_bases"){
                 leading.type="SB";
             }else if(leading.categories_type=="strikeouts"){
                 leading.type="SO";
             }else if(leading.categories_type=="triples"){
                 leading.type="Triple";
             }else if(leading.categories_type=="whip"){
                 leading.type="WH";
             }
             (leadersdata).push(leading);
             rankCounter++;
           }) 
            response.message = "National League Leader Available !";
            response.status = true;
            response.leaders = leadersdata;
          
             response.leagueName = "National League";
            res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
});

app.get('/get_nfl',(req,res) =>{
    var response = {};
    Conference.find({league:"NFL"}).then((conference) =>{
		Fddemand.aggregate([{$match:{ type:"NFL"}},{$group:{ _id: { home_id: "$home_id",home_team: "$home_team"},totalDemand: { $sum: "$demand" }}}]).exec( function (err, fddemand) {
			
			if (conference) { 
				response.message = "Conference Data Available !";
				response.status = true;
				response.conference = conference;
				response.fandemand	=	[];
				async.forEach(fddemand,function(fddemandData) {
					fditem	=	{};
					fditem.team_id=	fddemandData._id.home_id;
					fditem.team_name=	fddemandData._id.home_team;
					fditem.demand=	(fddemandData.totalDemand).toFixed(2);
					(response.fandemand).push(fditem);
				})
				res.status(200).send(JSON.stringify(response));
				
			} else {
				response.message = "No Data!";
				response.status = false;
				res.status(400).send(JSON.stringify(response));
			}
		});
    });
});

app.get('/get_mlb',(req,res) =>{
    var response = {};
    Division.find({league:"MLB"}).then((conference) =>{
		Fddemand.aggregate([{$match:{ type:"MLB"}},{$group:{ _id: { home_id: "$home_id",home_team: "$home_team"},totalDemand: { $sum: "$demand" }}}]).exec( function (err, fddemand) {
			
        if (conference) { 
            response.message = "Conference Data Available !";
            response.status = true;
            response.conference = conference;
			response.fandemand	=	[];
			async.forEach(fddemand,function(fddemandData) {
				fditem	=	{};
				fditem.team_id=	fddemandData._id.home_id;
				fditem.team_name=	fddemandData._id.home_team;
				fditem.demand=	(fddemandData.totalDemand).toFixed(2);
				(response.fandemand).push(fditem);
			})
			res.status(200).send(JSON.stringify(response));
          } else {
            response.message = "No Data!";
            response.status = false;
            res.status(400).send(JSON.stringify(response));
          }
    });
    });
});

app.get('/update_conference/:league',(req,res) =>{
  if(req.params.league == "NBA"){
    feed_url  =  "http://api.sportradar.us/nba/trial/v5/en/seasons/2018/REG/standings.json?api_key=rxnwvw4myu6xd488basdrenn";
  }else if(req.params.league == "NFL"){
    feed_url  =  "http://api.sportradar.us/nfl/official/trial/v5/en/seasons/2018/standings.json?api_key=cnfswcsaqcvtvs2sxst2s68m";
  }
  request(feed_url, { json: true }, (err, response, divisionBody) => {
      
    if (err) {
      response.status = false;
      res.status(400).send(JSON.stringify(response));
    }else{
		
		if(typeof divisionBody.conferences !="undefined"){
		  (divisionBody.conferences).forEach(function(conference){

			req.body.season  =  divisionBody.season.type;
			req.body.league  =  req.params.league;
			req.body.conferences_name  =  conference.name;
			req.body.conferences_alias  =  conference.alias;
			req.body.divisions  =  [];
			if(typeof conference.divisions !="undefined"){
			  (conference.divisions).forEach(function(divisions){
				division_body  =  {};
				division_body['id']  =  divisions.id;
				division_body['name']  =  divisions.name;
				division_body['alias']  =  divisions.alias;
				division_body['teams']  =  [];
				if(typeof divisions.teams !="undefined"){
					(divisions.teams).forEach(function(teams){
						diviteamData=  {};
						diviteamData['team_id']  =  teams.id;
						if(req.params.league == "NBA"){
							diviteamData['team_name']  =  teams.market+' '+teams.name;
						}else{
							if(teams.clinched){
								diviteamData['team_name']  =  teams.market+' '+teams.name+'-'+teams.clinched;
							}else{
								diviteamData['team_name']  =  teams.market+' '+teams.name;
							}
							
						}
						
						diviteamData['wins']  =  teams.wins;
						diviteamData['loses']  =  teams.losses;
						diviteamData['win_pct']  =  teams.win_pct;
						diviteamData['pf']  =  teams.points_for;
						diviteamData['pa']  =  teams.points_against;
						
						if(req.params.league == "NBA"){
							diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
						  diviteamData['diff']  =  teams.point_diff;
						  diviteamData['game_behind_c_f']  =  teams.games_behind.conference +'-'+ teams.games_behind.division;
						  diviteamData['strk']  =  teams.streak.kind +' '+ teams.streak.length;
						  if(typeof teams.records !='undefined'){
							(teams.records).forEach(function(confdivirecdata) {
							  if(confdivirecdata.record_type=='home'){
								  diviteamData['home']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='road'){
								  diviteamData['road']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='division'){
								diviteamData['division']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='conference'){
								 diviteamData['conference']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='last_10'){
								  diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='three_points'){
								 diviteamData['three_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='ten_points'){
								  diviteamData['ten_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='over_500'){
								 diviteamData['over_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='below_500'){
								diviteamData['below_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }else if(confdivirecdata.record_type=='overtime'){
								diviteamData['overtime']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
							  }
							})
						  }
						}else{
							diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
						   diviteamData['ties']  =  teams.ties;
						   diviteamData['diff']  =  teams.points_for - teams.points_against;
						   diviteamData['strk']  =  teams.streak.desc;
							if(typeof teams.records !='undefined'){
								(teams.records).forEach(function(confdivirecdata) {
								  if(confdivirecdata.record.category=='home'){
									  diviteamData['home']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
								  }else if(confdivirecdata.record.category=='road'){
									  diviteamData['away']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
								  }else if(confdivirecdata.record.category=='division'){
									diviteamData['division']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
								  }else if(confdivirecdata.record.category=='conference'){
									 diviteamData['conference']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
								  }
								})
							}
						}
						

						 (division_body['teams'] ).push(diviteamData);

					})
				}
				 (req.body.divisions).push(division_body);
			  })
			}

			 var conference = new Conference(req.body);
			conference.save(function(err, conferences) {
			  if(err){
				console.log(err);
				return false;
			  }
			  
			});
		  })
		}
		
    }
        
  });
});

app.get('/update_division/:league',(req,res) =>{
  if(req.params.league == "NBA"){
    feed_url  =  "http://api.sportradar.us/nba/trial/v5/en/seasons/2018/REG/standings.json?api_key=rxnwvw4myu6xd488basdrenn";
  }else if(req.params.league == "NFL"){
    feed_url  =  "http://api.sportradar.us/nfl/official/trial/v5/en/seasons/2018/standings.json?api_key=cnfswcsaqcvtvs2sxst2s68m";
  }else if(req.params.league == "MLB"){
    feed_url  =  "http://api.sportradar.us/mlb/trial/v6.5/en/seasons/2019/PRE/standings.json?api_key=3h4d3zjgcw8m53dsxbqphdzk";
  }
  request(feed_url, { json: true }, (err, response, divisionBody) => {
      
    if (err) {
      response.status = false;
      res.status(400).send(JSON.stringify(response));
    }else{
		if(req.params.league == "MLB"){
			console.log(divisionBody.league.season.spring_leagues);
			if(typeof divisionBody.league.season.spring_leagues !="undefined"){
			  (divisionBody.league.season.spring_leagues).forEach(function(sleagues){
				  	req.body.season  =  divisionBody.league.season.type;
					req.body.league  =  req.params.league;
					req.body.conferences_name  =  sleagues.name;
					req.body.conferences_alias  =  sleagues.alias;
					req.body.teams  =  [];
					if(typeof sleagues.teams !="undefined"){
						(sleagues.teams).forEach(function(teams){
							diviteamData=  {};
							diviteamData['team_id']  =  teams.id;
							diviteamData['team_name']  =  teams.market+' '+teams.name;
							diviteamData['wins']  =  teams.win;
							diviteamData['loses']  =  teams.loss;
							diviteamData['win_pct']  =  teams.win_p;
							diviteamData['strk']  =  teams.streak;
							diviteamData['away']  =  teams.away_win+'-'+teams.away_loss;
							diviteamData['last_10']  =  teams.last_10_won+'-'+teams.last_10_lost;
							diviteamData['home']  =  teams.home_win+'-'+teams.home_loss;
							diviteamData['team_logo'] 	=	"/upload/teams/"+dt.mlbnameUnderscore(teams.market+" "+teams.name)+'.png';
						
							(req.body.teams).push(diviteamData);
						})
					}
				var division = new Division(req.body);
				division.save(function(err, divisions) {
				  if(err){
					console.log(err);
					return false;
				  }
				  
				});					
			  });
			  
			}  
		}else{
			if(typeof divisionBody.conferences !="undefined"){
			  (divisionBody.conferences).forEach(function(conference){

				req.body.season  =  divisionBody.season.type;
				req.body.league  =  req.params.league;
				req.body.conferences_name  =  conference.name;
				req.body.conferences_alias  =  conference.alias;
				req.body.teams  =  [];
				if(typeof conference.divisions !="undefined"){
				  (conference.divisions).forEach(function(divisions){
					division_body  =  {};
					if(typeof divisions.teams !="undefined"){
						(divisions.teams).forEach(function(teams){
							diviteamData=  {};
							diviteamData['team_id']  =  teams.id;
							if(req.params.league == "NBA"){
								diviteamData['team_name']  =  teams.market+' '+teams.name;
							}else{
								if(teams.clinched){
									diviteamData['team_name']  =  teams.market+' '+teams.name+'-'+teams.clinched;
								}else{
									diviteamData['team_name']  =  teams.market+' '+teams.name;
								}
							}
							//diviteamData['team_name']  =  teams.market+' '+teams.name;
							diviteamData['wins']  =  teams.wins;
							diviteamData['loses']  =  teams.losses;
							diviteamData['win_pct']  =  teams.win_pct;
							diviteamData['pf']  =  teams.points_for;
							diviteamData['pa']  =  teams.points_against;
							if(req.params.league == "NBA"){
								diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
							  diviteamData['diff']  =  teams.point_diff;
							  diviteamData['game_behind_c_f']  =  teams.games_behind.conference +'-'+ teams.games_behind.division;
							  diviteamData['strk']  =  teams.streak.kind +' '+ teams.streak.length;
							  if(typeof teams.records !='undefined'){
								(teams.records).forEach(function(confdivirecdata) {
								  if(confdivirecdata.record_type=='home'){
									  diviteamData['home']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='road'){
									  diviteamData['road']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='division'){
									diviteamData['division']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='conference'){
									 diviteamData['conference']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='last_10'){
									  diviteamData['last_10']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='three_points'){
									 diviteamData['three_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='ten_points'){
									  diviteamData['ten_points']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='over_500'){
									 diviteamData['over_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='below_500'){
									diviteamData['below_500']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }else if(confdivirecdata.record_type=='overtime'){
									diviteamData['overtime']  =  confdivirecdata.wins +'-'+ confdivirecdata.losses;
								  }
								})
							  }
							}else{
								diviteamData['ties']  =  teams.ties;
								diviteamData['diff']  =  teams.points_for - teams.points_against;
								diviteamData['strk']  =  teams.streak.desc;
								diviteamData['team_logo']  =  "/upload/teams/"+dt.nameUnderscore(teams.market+' '+teams.name)+'.png';
								if(typeof teams.records !='undefined'){
									(teams.records).forEach(function(confdivirecdata) {
									  if(confdivirecdata.record.category=='home'){
										  diviteamData['home']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }else if(confdivirecdata.record.category=='road'){
										  diviteamData['away']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }else if(confdivirecdata.record.category=='division'){
										diviteamData['division']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }else if(confdivirecdata.record.category=='conference'){
										 diviteamData['conference']  =  confdivirecdata.record.wins +'-'+ confdivirecdata.record.losses;
									  }
									})
								}
							}
							

							(req.body.teams).push(diviteamData);

						})
					}
					 
				  })
				}
				
				 var division = new Division(req.body);
				division.save(function(err, divisions) {
				  if(err){
					console.log(err);
					return false;
				  }
				  
				});
			  })
			}
		}	
    }
        
  });
});

app.get('/get_nflleaders',(req,res)=>{
  var response = {};

  NflLeaders.aggregate([ {$project:{week:1,player_name:1,nfl_type:1,nfl_type_slug:1,yds:1,made:1,team_name:1,team_market:1,player_id:1}},{
        "$lookup": {
            "from": "playerimages", /* underlying collection for jobSchema */
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    },{ $group : {_id: {week:"$week",nfl_type: "$nfl_type"},records: { $push: "$$ROOT" } }}, {$sort:{"_id.week":1}}]).exec( function (err, leadersList) {
    var leadersdata  =  [];

      if(leadersList.length>0){
       var j=0;
       leadersdata[0]  =  [];
       leadersdata[1]  =  [];
       leadersdata[2]  =  [];
       leadersdata[3]  =  [];
       leadersdata[4]  =  [];
       leadersdata[5]  =  [];
       leadersdata[6]  =  [];
       leadersdata[7]  =  [];
       leadersdata[8]  =  [];
       leadersdata[9]  =  [];
       leadersdata[10]  =  [];
       leadersdata[11]  =  [];
       leadersdata[12]  =  [];
       leadersdata[13]  =  [];
       leadersdata[14]  =  [];
       leadersdata[15]  =  [];
       leadersdata[16]  =  [];
        leadersList.forEach(function(leadlist) {
			if(typeof leadlist.records[0].player_id !="undefined"){
				if((leadlist.records[0]['playerImage']).length > 0){
					var dir  =  "/var/sports/public/upload/player/"+leadlist.records[0]['playerImage'][0]['asset_id']+"/90x90-crop.jpg";
					if (fs.existsSync(dir) ) {
						leadlist.records[0].profile_pic  =  app.get('siteUrl')+"/upload/player/"+leadlist.records[0]['playerImage'][0]['asset_id']+"/90x90-crop.jpg";
					}else{
						leadlist.records[0].profile_pic  =  "";
					}
					
				}else{
					leadlist.records[0].profile_pic  =  "";
				}
    		 
    		}else{
    			 leadlist.records[0].profile_pic  =  "";
    		}
			leadlist.records[0].home_team_logo =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(leadlist.records[0].team_market+"_"+leadlist.records[0].team_name)+'.png';
			delete leadlist.records[0]["playerImage"];
        	//(leadlist.records[0]).splice('playerImage', 1);
    		if(leadlist._id.week == 1){
           		(leadersdata[0]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 2){
            	(leadersdata[1]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 3){
            	(leadersdata[2]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 4){
            	(leadersdata[3]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 5){
            	(leadersdata[4]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 6){
            	(leadersdata[5]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 7){
            	(leadersdata[6]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 8){
           	 (leadersdata[7]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 9){
	            (leadersdata[8]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 10){
	            (leadersdata[9]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 11){
	            (leadersdata[10]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 12){
	            (leadersdata[11]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 13){
	            (leadersdata[12]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 14){
	            (leadersdata[13]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 15){
	            (leadersdata[14]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 16){
	            (leadersdata[15]).push(leadlist.records[0]);
          	}else if(leadlist._id.week == 17){
	            (leadersdata[16]).push(leadlist.records[0]);
          	}
        })
    	response.message = "NFL Leader Available !";
        response.status = true;
        response.leaders = leadersdata;
        res.status(200).send(JSON.stringify(response));
      }else{
        response.message = "No Data Found !";
        response.status = false;
        res.status(400).send(JSON.stringify(response));
      }
      
     
  
  })
})

app.get('/get_nflleaders_detail/:week/:nfl_type',(req,res)=>{
  var response = {};
    NflLeaders.aggregate([ {$match:{week : parseInt(req.params.week),nfl_type_slug: req.params.nfl_type}},{$project:{week:1,nfl_type:1,player_name:1,yds:1,made:1,team_name:1,team_market:1,player_id:1}},{
        "$lookup": {
            "from": "playerimages", /* underlying collection for jobSchema */
            "localField": "player_id",
            "foreignField": "player_id",
            "as": "playerImage"
        }
    }, {$sort:{"_id.created":1}}]).exec( function (err, leadersList) {

    leadersdata  =  [];
    if(leadersList){

      (leadersList).forEach(function(leadlist){
      	//console.log(leadlist);
		if(typeof leadlist.player_id !="undefined"){
		if((leadlist['playerImage']).length > 0){
			var dir  =  "/var/sports/public/upload/player/"+leadlist['playerImage'][0]['asset_id']+"/90x90-crop.jpg";
			if (fs.existsSync(dir) ) {
				leadlist.profile_pic  =  app.get('siteUrl')+"/upload/player/"+leadlist['playerImage'][0]['asset_id']+"/90x90-crop.jpg";
			}else{
				leadlist.profile_pic  =  "";
			}
			
		}else{
			leadlist.profile_pic  =  "";
		}
	 
	}else{
		 leadlist.profile_pic  =  "";
	}
	leadlist.home_team_logo =  app.get('siteUrl')+"/upload/teams/"+dt.nameUnderscore(leadlist.team_market+"_"+leadlist.team_name)+'.png';
	delete leadlist["playerImage"];
       (leadersdata).push(leadlist);
      })
      response.message = "NFL Leader Available !";
      response.status = true;
      response.leaders = leadersdata;
      res.status(200).send(JSON.stringify(response));
    }else{
      response.message = "NFL Leader Not Available !";
      response.status = false;
      res.status(400).send(JSON.stringify(response));
    }
  })
})
/*
A simple way of implementing authorization is creating a simple middleware for it. Any endpoint that come after the authorization middleware won't pass if user doesn't have a valid session
*/
app.use((req, res, next) => {
  if (req.session.user) {
    next();
  } else {
    res.status(400).send('Authrization failed! Please login');
  }
});

app.get('/protected', (req, res) => {
  res.send('You are seeing this because you have a valid session.Your username is'+req.session.user.username+'and email is '+req.session.user.email+'.'
    )
})


/*
4. Logout
*/
app.all('/logout', (req, res) => {
  delete req.session.user; // any of these works
  	req.session.destroy(); // any of these works
    res.status(200).send('logout successful')
})

/*
We shall be using two endpoints to implement password reset functionality
*/

app.post('/forgot', (req, res) => {
  let {email} = req.body; // same as let email = req.body.email
  User.findOne({email: email}, (err, userData) => {
    if (!err) {
      userData.passResetKey = shortid.generate();
      userData.passKeyExpires = new Date().getTime() + 20 * 60 * 1000 // pass reset key only valid for 20 minutes
      userData.save().then(err => {
          if (!err) {
            let transporter = nodemailer.createTransport({
              service: "gmail",
              port: 465,
              auth: {
                user: '', // your gmail address
                pass: '' // your gmail password
              }
            });
            let mailOptions = {
              subject: 'NodeAuthTuts | Password reset',
              to: email,
              from: 'NodeAuthTuts <yourEmail@gmail.com>',
              html: '<h1>Hi,</h1><h2>Here is your password reset key</h2><h2><code contenteditable="false" style="font-weight:200;font-size:1.5rem;padding:5px 10px; background: #EEEEEE; border:0">${passResetKey}</code></h4><p>Please ignore if you didn`t try to reset your password on our platform</p>',
            };
            try {
              transporter.sendMail(mailOptions, (error, response) => {
                if (error) {
                  console.log("error:\n", error, "\n");
                  res.status(500).send("could not send reset code");
                } else {
                  console.log("email sent:\n", response);
                  res.status(200).send("Reset Code sent");
                }
              });
            } catch (error) {
              console.log(error);
              res.status(500).send("could not sent reset code");
            }
          }
        })
    } else {
      res.status(400).send('email is incorrect');
    }
  })
});

app.post('/resetpass', (req, res) => {
  let {resetKey, newPassword} = req.body
    User.find({passResetKey: resetKey}, (err, userData) => {
    	if (!err) {
        	let now = new Date().getTime();
            let keyExpiration = userDate.passKeyExpires;
            if (keyExpiration > now) {
        userData.password = bcrypt.hashSync(newPassword, 5);
                userData.passResetKey = null; // remove passResetKey from user's records
                userData.keyExpiration = null;
                userData.save().then(err => { // save the new changes
                	if (!err) {
                    	res.status(200).send('Password reset successful')
                    } else {
                    	res.status(500).send('error resetting your password')
                    }
                })
            } else {
            	res.status(400).send('Sorry, pass key has expired. Please initiate the request for a new one');
            }
        } else {
        	res.status(400).send('invalid pass key!');
        }
    })
})

app.listen(PORT, () => {
  console.log('app running port '+PORT);
})